# 2026-10-03 拟合性能评估证据

页面：https://hui950319.github.io/Rnotes/regr/performance-evaluation.html

glm/：60次主拟合、6次交替线程检查、汇总、实际执行脚本、元数据及会话信息。
fgr-mets/：21次主拟合、汇总、数值与行顺序核对、指标后端差值、实际执行脚本、元数据及会话信息。

原始患者数据未包含。两个主脚本均使用 `/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda`，如路径不同须修改。输出目录须先创建。样本通过有放回重复原始病例构造，仅评估计算性能。

Logistic 每格5次；FGR(TRUE)每格1次；FGR(FALSE)与mets每格3次。FGR方法执行顺序未交替。机器非独占，耗时不能作为跨机器的固定门槛。

likelihood-metric-comparison.csv 为切换前使用 mets 的 get_fit_stats 对照，当时的实现可查 https://github.com/HUI950319/RegR/blob/d5084cb/R/msr-fit-stats.R 。当前工作区 get_fit_stats 已改为 FGR(FALSE)，不能将当前函数的结果称为 mets 结果。该补充检查每档仅一次，且两端计时边界略有不同，不用于精确速度比。指标数值以 CSV 为准。

small-variance-check.csv 为发布前2000行核对，比较同一个样本 FGR(TRUE/FALSE) 的似然与指标；不用于增加主基准的重复次数。

plot-fitting-times.R 根据 fit-summary.csv 生成页面SVG，须在证据包根目录执行。

复现主拟合：

```bash
Rscript glm/benchmark-glm.R /absolute/output/glm
Rscript glm/benchmark-glm.R /absolute/output/glm thread-check
Rscript fgr-mets/benchmark-fgr-mets.R /absolute/output/fgr-mets
```
