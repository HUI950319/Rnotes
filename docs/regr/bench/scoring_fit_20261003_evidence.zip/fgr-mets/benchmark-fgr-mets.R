args <- commandArgs(trailingOnly = TRUE)
outdir <- normalizePath(args[[1]], mustWork = TRUE)
setwd(outdir)
options(width = 160, digits = 16)
stopifnot(requireNamespace("callr", quietly = TRUE))
e <- new.env(parent = emptyenv())
data_file <- "/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda"
load(data_file, envir = e)
raw <- as.data.frame(e[["seer_thyroid_mtc_2026"]])
required <- c("time", "event", "Age", "Sex", "Race")
keep <- complete.cases(raw[, required]) & !is.na(raw[["time"]]) & raw[["time"]] > 0
source <- droplevels(raw[keep, required, drop = FALSE])
stopifnot(all(source[["event"]] %in% 0:2))
seed <- 20261003L
set.seed(seed)
big <- source[sample.int(nrow(source), 100000L, replace = TRUE), , drop = FALSE]
rownames(big) <- NULL
budget <- 180
metadata <- list(date = "2026-10-03 Asia/Shanghai", seed = seed,
  source_path = data_file, source_md5 = unname(tools::md5sum(data_file)),
  source_n = nrow(raw), complete_positive_time_n = nrow(source),
  source_event_counts = table(source[["event"]]),
  unique_source_event_times = length(unique(source[["time"]][source[["event"]] == 1])),
  construction = "nested row resampling with replacement; original month times retained without jitter",
  R = R.version.string, cpu = grep("model name", readLines("/proc/cpuinfo"), value = TRUE)[1],
  BLAS = extSoftVersion()[["BLAS"]], blas_threads = 1,
  versions = sapply(c("riskRegression", "cmprsk", "mets", "prodlim", "timereg", "RhpcBLASctl", "callr"), function(x) as.character(packageVersion(x))),
  model_rhs = "Age + Sex + Race (4 coefficients, no intercept)", cause = 1, censoring = 0,
  FGR_controls = formals(cmprsk::crr)[c("gtol", "maxiter", "variance")],
  methods = c("riskRegression::FGR(variance=TRUE)", "riskRegression::FGR(variance=FALSE)", "mets::cifreg(propodds=NULL, stderr=TRUE, cox.prep=FALSE)"),
  repetitions = c(FGR_TRUE = 1, FGR_FALSE = 3, mets = 3), per_fit_budget_s = budget,
  timing = "system.time(model fitting); includes formula/matrix construction and requested SE; excludes package/data loading, GC before call, extraction, prediction, Score, plots",
  loadavg_start = readLines("/proc/loadavg"))
dput(metadata, file = "metadata.R")
capture.output(sessionInfo(), file = "session-info.txt")
worker <- function(d, method, reps, marker, partial_path) {
  options(warn = 1)
  RhpcBLASctl::blas_set_num_threads(1L)
  RhpcBLASctl::omp_set_num_threads(1L)
  stopifnot(RhpcBLASctl::blas_get_num_procs() == 1L)
  requireNamespace("riskRegression", quietly = TRUE)
  requireNamespace("mets", quietly = TRUE)
  Hist <- prodlim::Hist
  Event <- timereg::Event
  fit_one <- function(dd) {
    if (method == "mets") {
      mets::cifreg(Event(time, event) ~ Age + Sex + Race, data = dd,
        cause = 1, cens.code = 0, propodds = NULL, stderr = TRUE, cox.prep = FALSE)
    } else {
      riskRegression::FGR(Hist(time, event) ~ Age + Sex + Race,
        data = dd, cause = 1, variance = method == "FGR_TRUE")
    }
  }
  invisible(fit_one(d[seq_len(min(500L, nrow(d))), , drop = FALSE]))
  rows <- list()
  final <- NULL
  for (rep in seq_len(reps)) {
    gc()
    warnings <- character()
    writeLines(sprintf("%.6f", as.numeric(Sys.time())), marker)
    tt <- system.time(fit <- withCallingHandlers(fit_one(d),
      warning = function(w) { warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning") }))
    unlink(marker)
    if (method == "mets") {
      b <- coef(fit)
      V <- vcov(fit)
      convergence <- NA
      n <- fit[["n"]]
      gradient <- fit[["gradient"]]
      step <- fit[["ihessian"]] %*% gradient
      gradient_max <- max(abs(gradient))
      newton_step_max <- max(abs(step))
      stopifnot(newton_step_max < 1e-5)
      predicted <- NULL
      loglik <- fit[["ploglik"]]
    } else {
      native <- fit[["crrFit"]]
      b <- native[["coef"]]
      V <- native[["var"]]
      convergence <- native[["converged"]]
      n <- native[["n"]]
      gradient_max <- max(abs(native[["score"]]))
      newton_step_max <- if (all(is.finite(native[["inf"]]))) max(abs(solve(native[["inf"]], native[["score"]]))) else NA_real_
      stopifnot(isTRUE(convergence))
      predicted <- riskRegression::predictRisk(fit, newdata = head(d, 50L), times = c(36, 60, 120))
      stopifnot(all(is.finite(predicted)), all(predicted >= 0 & predicted <= 1))
      loglik <- native[["loglik"]]
    }
    stopifnot(n == nrow(d), length(b) == 4L, all(is.finite(b)), is.finite(loglik))
    has_se <- all(is.finite(V)) && all(diag(V) > 0)
    if (method != "FGR_FALSE") stopifnot(has_se)
    if (method == "FGR_FALSE") stopifnot(!has_se)
    se <- if (has_se) sqrt(diag(V)) else rep(NA_real_, length(b))
    coefficients <- data.frame(term = names(b), beta = unname(b), sHR = exp(unname(b)),
      SE = unname(se), lower = exp(unname(b) - qnorm(.975) * se), upper = exp(unname(b) + qnorm(.975) * se))
    rows[[rep]] <- data.frame(n = nrow(d), method = method, replicate = rep,
      elapsed_s = unname(tt[["elapsed"]]), user_s = unname(tt[["user.self"]]),
      system_s = unname(tt[["sys.self"]]), n_parameters = length(b),
      target_events = sum(d[["event"]] == 1), competing_events = sum(d[["event"]] == 2),
      censored = sum(d[["event"]] == 0),
      unique_target_times = length(unique(d[["time"]][d[["event"]] == 1])),
      converged = convergence, max_score = gradient_max, max_newton_step = newton_step_max,
      has_coefficient_SE = has_se, warning_count = length(warnings),
      warnings = paste(unique(warnings), collapse = " | "))
    cat(sprintf("REPLICATE n=%d method=%s rep=%d elapsed=%.3f\n", nrow(d), method, rep, tt[["elapsed"]]))
    final <- list(timings = do.call(rbind, rows), coefficients = coefficients, prediction = predicted)
    saveRDS(final, partial_path)
  }
  final
}
if (length(args) >= 2L && identical(args[[2]], "order-check")) {
  n <- 30000L
  d <- big[seq_len(n), , drop = FALSE]
  set.seed(seed + 1L)
  perm <- sample.int(n)
  checks <- list()
  for (method in c("mets", "FGR_FALSE")) {
    key <- paste(method, n, sep = "-")
    baseline <- readRDS(file.path(outdir, paste0(key, ".rds")))
    marker <- file.path(outdir, paste0(key, "-order.started"))
    partial <- file.path(outdir, paste0(key, "-order.rds"))
    reordered <- worker(d[perm, , drop = FALSE], method, 1L, marker, partial)
    a <- baseline[["coefficients"]]
    b <- reordered[["coefficients"]]
    b <- b[match(a[["term"]], b[["term"]]), ]
    has_se <- all(is.finite(a[["SE"]])) && all(is.finite(b[["SE"]]))
    checks[[method]] <- data.frame(n = n, method = method,
      max_beta_difference = max(abs(a[["beta"]] - b[["beta"]])),
      max_sHR_difference = max(abs(a[["sHR"]] - b[["sHR"]])),
      max_SE_difference = if (has_se) max(abs(a[["SE"]] - b[["SE"]])) else NA_real_)
  }
  write.csv(do.call(rbind, checks), "row-order-check.csv", row.names = FALSE)
  print(do.call(rbind, checks), row.names = FALSE)
  cat("ORDER_CHECK_COMPLETE\n")
  quit(save = "no", status = 0L)
}
all_rows <- list()
all_coef <- list()
statuses <- list()
completed <- list()
cases <- expand.grid(n = c(30000L, 50000L, 100000L),
  method = c("mets", "FGR_FALSE", "FGR_TRUE"), stringsAsFactors = FALSE)
for (i in seq_len(nrow(cases))) {
  n <- cases[["n"]][i]
  method <- cases[["method"]][i]
  reps <- if (method == "FGR_TRUE") 1L else 3L
  key <- paste(method, n, sep = "-")
  marker <- file.path(outdir, paste0(key, ".started"))
  partial_path <- file.path(outdir, paste0(key, ".rds"))
  log <- file.path(outdir, paste0(key, ".log"))
  cat("START ", key, " repetitions=", reps, "\n", sep = "")
  flush(stdout())
  begun <- Sys.time()
  p <- callr::r_bg(worker, args = list(big[seq_len(n), , drop = FALSE], method, reps, marker, partial_path),
    stdout = log, stderr = log, supervise = TRUE,
    env = c(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1"))
  timed_out <- FALSE
  while (p$is_alive()) {
    Sys.sleep(.5)
    if (file.exists(marker)) {
      started <- suppressWarnings(as.numeric(readLines(marker, warn = FALSE)))
      if (length(started) == 1L && is.finite(started) && as.numeric(Sys.time()) - started > budget) {
        p$kill_tree()
        timed_out <- TRUE
        break
      }
    } else if (as.numeric(difftime(Sys.time(), begun, units = "secs")) > 60 && !file.exists(partial_path)) {
      p$kill_tree()
      timed_out <- TRUE
      break
    }
  }
  result <- tryCatch(p$get_result(), error = function(e) e)
  failed <- inherits(result, "error")
  error_message <- if (failed) conditionMessage(result) else NA_character_
  if (failed && file.exists(partial_path)) result <- readRDS(partial_path)
  available <- is.list(result) && !inherits(result, "error") && !is.null(result[["timings"]])
  statuses[[i]] <- data.frame(n = n, method = method,
    status = if (timed_out) "timeout" else if (failed) "failed" else "completed",
    repetitions_requested = reps, repetitions_completed = if (available) nrow(result[["timings"]]) else 0L,
    per_fit_budget_s = budget,
    process_wall_s = as.numeric(difftime(Sys.time(), begun, units = "secs")),
    error = error_message)
  write.csv(do.call(rbind, statuses), "run-status.csv", row.names = FALSE)
  if (available) {
    all_rows[[key]] <- result[["timings"]]
    z <- result[["coefficients"]]
    z[["n"]] <- n
    z[["method"]] <- method
    all_coef[[key]] <- z
    completed[[key]] <- result
    write.csv(do.call(rbind, all_rows), "fit-timings.csv", row.names = FALSE)
    write.csv(do.call(rbind, all_coef), "coefficients.csv", row.names = FALSE)
  }
  cat(if (timed_out) "TIMEOUT " else if (failed) "FAILED " else "DONE ", key, "\n", sep = "")
  if (file.exists(log)) cat(paste(readLines(log, warn = FALSE), collapse = "\n"), "\n")
  flush(stdout())
  if (failed && !timed_out) stop("Failed case: ", key)
}
summaries <- lapply(all_rows, function(z) data.frame(n = z[["n"]][1], method = z[["method"]][1],
  reps = nrow(z), median_s = median(z[["elapsed_s"]]), min_s = min(z[["elapsed_s"]]), max_s = max(z[["elapsed_s"]]),
  n_parameters = z[["n_parameters"]][1], target_events = z[["target_events"]][1],
  competing_events = z[["competing_events"]][1], censored = z[["censored"]][1],
  unique_target_times = z[["unique_target_times"]][1], warnings = sum(z[["warning_count"]])))
write.csv(do.call(rbind, summaries), "fit-summary.csv", row.names = FALSE)
differences <- list()
for (n in c(30000L, 50000L, 100000L)) {
  f0 <- completed[[paste("FGR_FALSE", n, sep = "-")]]
  f1 <- completed[[paste("FGR_TRUE", n, sep = "-")]]
  m <- completed[[paste("mets", n, sep = "-")]]
  compare <- function(a, b, comparison) {
    aa <- a[["coefficients"]]
    bb <- b[["coefficients"]]
    bb <- bb[match(aa[["term"]], bb[["term"]]), ]
    stopifnot(!anyNA(bb[["term"]]))
    se_ok <- all(is.finite(aa[["SE"]])) && all(is.finite(bb[["SE"]]))
    data.frame(n = n, comparison = comparison,
      max_beta_difference = max(abs(aa[["beta"]] - bb[["beta"]])),
      max_sHR_difference = max(abs(aa[["sHR"]] - bb[["sHR"]])),
      max_relative_sHR_difference = max(abs(aa[["sHR"]] / bb[["sHR"]] - 1)),
      max_SE_difference = if (se_ok) max(abs(aa[["SE"]] - bb[["SE"]])) else NA_real_,
      max_relative_SE_difference = if (se_ok) max(abs(aa[["SE"]] / bb[["SE"]] - 1)) else NA_real_,
      max_CI_difference = if (se_ok) max(abs(as.matrix(aa[c("lower", "upper")]) - as.matrix(bb[c("lower", "upper")]))) else NA_real_,
      max_prediction_difference = if (!is.null(a[["prediction"]]) && !is.null(b[["prediction"]])) max(abs(a[["prediction"]] - b[["prediction"]])) else NA_real_)
  }
  if (!is.null(f0) && !is.null(f1)) differences[[length(differences) + 1L]] <- compare(f0, f1, "FGR_FALSE vs FGR_TRUE")
  if (!is.null(f0) && !is.null(m)) differences[[length(differences) + 1L]] <- compare(m, f0, "mets vs FGR_FALSE")
  if (!is.null(f1) && !is.null(m)) differences[[length(differences) + 1L]] <- compare(m, f1, "mets vs FGR_TRUE")
}
if (length(differences)) write.csv(do.call(rbind, differences), "numerical-differences.csv", row.names = FALSE)
print(do.call(rbind, summaries), row.names = FALSE)
if (length(differences)) print(do.call(rbind, differences), row.names = FALSE)
cat("BENCHMARK_COMPLETE\n")