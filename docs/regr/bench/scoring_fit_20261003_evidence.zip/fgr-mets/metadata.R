list(date = "2026-10-03 Asia/Shanghai", seed = 20261003L, source_path = "/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda", 
    source_md5 = "ec0c261afe3b355ebf9324e649901f51", source_n = 4387L, 
    complete_positive_time_n = 4387L, source_event_counts = structure(c(`0` = 3207L, 
    `1` = 597L, `2` = 583L), dim = 3L, dimnames = structure(list(
        c("0", "1", "2")), names = ""), class = "table"), unique_source_event_times = 157L, 
    construction = "nested row resampling with replacement; original month times retained without jitter", 
    R = "R version 4.4.3 (2025-02-28)", cpu = "model name\t: Intel(R) Core(TM) Ultra 9 275HX", 
    BLAS = "/usr/lib/x86_64-linux-gnu/openblas-pthread/libblas.so.3", 
    blas_threads = 1, versions = c(riskRegression = "2026.3.11", 
    cmprsk = "2.2.12", mets = "1.3.13", prodlim = "2026.3.11", 
    timereg = "2.0.5", RhpcBLASctl = "0.23.42", callr = "3.7.6"
    ), model_rhs = "Age + Sex + Race (4 coefficients, no intercept)", 
    cause = 1, censoring = 0, FGR_controls = list(gtol = 1e-06, 
        maxiter = 10, variance = TRUE), methods = c("riskRegression::FGR(variance=TRUE)", 
    "riskRegression::FGR(variance=FALSE)", "mets::cifreg(propodds=NULL, stderr=TRUE, cox.prep=FALSE)"
    ), repetitions = c(FGR_TRUE = 1, FGR_FALSE = 3, mets = 3), 
    per_fit_budget_s = 180, timing = "system.time(model fitting); includes formula/matrix construction and requested SE; excludes package/data loading, GC before call, extraction, prediction, Score, plots", 
    loadavg_start = "1.24 1.09 1.15 2/1231 530755")
