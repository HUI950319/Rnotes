library(ggplot2)
z <- read.csv("fgr-mets/fit-summary.csv")
z$method <- factor(z$method, c("FGR_TRUE", "FGR_FALSE", "mets"),
  c("FGR TRUE (1 run)", "FGR FALSE (median, 3 runs)", "mets + SE (median, 3 runs)"))
p <- ggplot(z, aes(n / 1000, median_s, color = method, shape = method)) +
  geom_line(linewidth = 0.7) +
  geom_errorbar(aes(ymin = min_s, ymax = max_s), width = 1.5, linewidth = 0.6) +
  geom_point(size = 3) +
  scale_x_continuous(breaks = c(30, 50, 100)) +
  scale_y_log10(breaks = c(0.1, 1, 10, 100), labels = c("0.1", "1", "10", "100")) +
  scale_color_manual(values = c("#D55E00", "#0072B2", "#009E73")) +
  labs(x = "Rows (thousands)", y = "Fit time (seconds, log scale)", color = NULL, shape = NULL,
    caption = "WSL / R 4.4.3; Age + Sex + Race; 1 BLAS thread. Bars: observed min-max, not confidence intervals.") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom", legend.text = element_text(size = 10),
    panel.grid.minor = element_blank(), plot.caption = element_text(hjust = 0, size = 9))
ggsave("scoring_fit_20261003.svg", p, width = 9, height = 5, device = grDevices::svg)
