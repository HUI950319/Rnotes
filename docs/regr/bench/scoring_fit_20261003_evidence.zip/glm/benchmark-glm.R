args <- commandArgs(trailingOnly = TRUE)
out_dir <- normalizePath(args[[1]], mustWork = TRUE)
stopifnot(requireNamespace("RhpcBLASctl", quietly = TRUE))
original_threads <- RhpcBLASctl::blas_get_num_procs()
models <- list(
  simple = DSS ~ Age + Sex + Race,
  clinical = DSS ~ Age + Sex + Race + Tum + Nod_4 + M + Sur + Rad + Che
)
seed <- 20261003L
sizes <- c(30000L, 50000L, 100000L)
reps <- 5L
data_file <- "/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda"
e <- new.env(parent = emptyenv())
load(data_file, envir = e)
raw <- as.data.frame(e[["seer_thyroid_mtc_2026"]])
required <- unique(unlist(lapply(models, all.vars), use.names = FALSE))
source <- raw[, required, drop = FALSE]
source <- droplevels(source[complete.cases(source), , drop = FALSE])
stopifnot(all(source[["DSS"]] %in% c(0, 1)), length(unique(source[["DSS"]])) == 2L)
set.seed(seed)
indices <- sample.int(nrow(source), max(sizes), replace = TRUE)
big <- source[indices, , drop = FALSE]
rownames(big) <- NULL
datasets <- lapply(sizes, function(n) big[seq_len(n), , drop = FALSE])
names(datasets) <- as.character(sizes)
meta <- list(date = "2026-10-03 Asia/Shanghai", R = R.version.string,
  os = Sys.info(), BLAS = extSoftVersion()[["BLAS"]],
  original_blas_threads = original_threads,
  RhpcBLASctl = as.character(packageVersion("RhpcBLASctl")),
  cpu = grep("model name", readLines("/proc/cpuinfo"), value = TRUE)[1],
  loadavg_start = readLines("/proc/loadavg"),
  source_path = data_file, source_md5 = unname(tools::md5sum(data_file)),
  source_n_raw = nrow(raw), source_n_complete = nrow(source),
  source_events = sum(source[["DSS"]]), seed = seed, repetitions = reps,
  construction = "nested row resampling with replacement; computational benchmark only",
  models = lapply(models, function(f) paste(deparse(f), collapse = " ")),
  glm_control = formals(stats::glm.control),
  timing = "system.time(glm): formula processing, model matrix, IRLS, result construction; excludes data generation/loading, prediction, Score, bootstrap, plots",
  source_counts = lapply(source, function(x) if (is.factor(x)) table(x, source[["DSS"]]) else summary(x)))
dput(meta, file = file.path(out_dir, "metadata.R"))
capture.output(sessionInfo(), file = file.path(out_dir, "session-info.txt"))
if (length(args) >= 2L && identical(args[[2]], "thread-check")) {
  checks <- list()
  reference_fit <- NULL
  for (i in seq_along(c(1L, original_threads, original_threads, 1L, 1L, original_threads))) {
    threads <- c(1L, original_threads, original_threads, 1L, 1L, original_threads)[i]
    RhpcBLASctl::blas_set_num_threads(threads)
    invisible(glm(models[["clinical"]], data = big[seq_len(5000L), ], family = binomial()))
    gc()
    tt <- system.time(fit <- glm(models[["clinical"]], data = big, family = binomial()))
    stopifnot(isTRUE(fit[["converged"]]), all(is.finite(coef(fit))))
    if (is.null(reference_fit)) reference_fit <- fit
    checks[[i]] <- data.frame(order = i, n = nrow(big), model = "clinical", blas_threads = threads,
      elapsed_s = unname(tt[["elapsed"]]), user_s = unname(tt[["user.self"]]),
      system_s = unname(tt[["sys.self"]]), iterations = fit[["iter"]],
      max_coef_difference = max(abs(coef(fit) - coef(reference_fit))),
      max_prediction_difference = max(abs(fitted(fit) - fitted(reference_fit))),
      deviance_difference = abs(deviance(fit) - deviance(reference_fit)))
    print(checks[[i]], row.names = FALSE)
  }
  write.csv(do.call(rbind, checks), file.path(out_dir, "thread-crosscheck.csv"), row.names = FALSE)
  RhpcBLASctl::blas_set_num_threads(original_threads)
  cat("THREAD_CROSSCHECK_COMPLETE\n")
  quit(save = "no", status = 0L)
}
results <- list()
reference <- list()
for (threads in unique(c(original_threads, 1L))) {
  RhpcBLASctl::blas_set_num_threads(threads)
  actual_threads <- RhpcBLASctl::blas_get_num_procs()
  stopifnot(actual_threads == threads)
  cat("BEGIN threads=", threads, "\n", sep = "")
  for (f in models) invisible(glm(f, data = big[seq_len(5000L), ], family = binomial()))
  set.seed(seed + threads)
  for (rep in seq_len(reps)) {
    cases <- expand.grid(n = sizes, model = names(models), stringsAsFactors = FALSE)
    cases <- cases[sample.int(nrow(cases)), , drop = FALSE]
    for (i in seq_len(nrow(cases))) {
      n <- cases[["n"]][i]
      model <- cases[["model"]][i]
      dd <- datasets[[as.character(n)]]
      warnings <- character()
      gc()
      tt <- system.time(fit <- withCallingHandlers(
        stats::glm(models[[model]], data = dd, family = stats::binomial()),
        warning = function(w) { warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning") }
      ))
      stopifnot(nobs(fit) == n, isTRUE(fit[["converged"]]),
                all(is.finite(coef(fit))), all(is.finite(fitted(fit))))
      key <- paste(n, model, sep = "_")
      coef_diff <- prob_diff <- dev_diff <- 0
      if (is.null(reference[[key]])) {
        reference[[key]] <- list(coef = coef(fit), prob = fitted(fit), deviance = deviance(fit))
      } else {
        coef_diff <- max(abs(coef(fit) - reference[[key]][["coef"]]))
        prob_diff <- max(abs(fitted(fit) - reference[[key]][["prob"]]))
        dev_diff <- abs(deviance(fit) - reference[[key]][["deviance"]])
      }
      results[[length(results) + 1L]] <- data.frame(n = n, model = model,
        blas_threads = threads, replicate = rep, elapsed_s = unname(tt[["elapsed"]]),
        user_s = unname(tt[["user.self"]]), system_s = unname(tt[["sys.self"]]),
        n_parameters = length(coef(fit)), rank = fit[["rank"]], iterations = fit[["iter"]],
        events = sum(dd[["DSS"]]), event_rate = mean(dd[["DSS"]]),
        converged = fit[["converged"]], max_abs_coefficient = max(abs(coef(fit))),
        fit_size_MiB = as.numeric(object.size(fit)) / 1024^2,
        warning_count = length(warnings), warnings = paste(unique(warnings), collapse = " | "),
        max_coef_difference = coef_diff, max_prediction_difference = prob_diff,
        deviance_difference = dev_diff)
      cat(sprintf("threads=%d rep=%d n=%d model=%s p=%d iter=%d elapsed=%.3f warnings=%d\n",
                  threads, rep, n, model, length(coef(fit)), fit[["iter"]], tt[["elapsed"]], length(warnings)))
      write.csv(do.call(rbind, results), file.path(out_dir, "glm-timings.csv"), row.names = FALSE)
      rm(fit)
    }
  }
}
RhpcBLASctl::blas_set_num_threads(original_threads)
r <- do.call(rbind, results)
summaries <- lapply(split(r, interaction(r[["n"]], r[["model"]], r[["blas_threads"]], drop = TRUE)), function(z) {
  data.frame(n = z[["n"]][1], model = z[["model"]][1], blas_threads = z[["blas_threads"]][1],
    n_parameters = z[["n_parameters"]][1], repetitions = nrow(z),
    median_s = median(z[["elapsed_s"]]), min_s = min(z[["elapsed_s"]]), max_s = max(z[["elapsed_s"]]),
    iterations = paste(unique(z[["iterations"]]), collapse = ","), events = z[["events"]][1],
    converged = all(z[["converged"]]), warnings = sum(z[["warning_count"]]),
    max_coef_difference = max(z[["max_coef_difference"]]),
    max_prediction_difference = max(z[["max_prediction_difference"]]),
    max_deviance_difference = max(z[["deviance_difference"]]))
})
s <- do.call(rbind, summaries)
s <- s[order(s[["blas_threads"]], s[["model"]], s[["n"]]), ]
write.csv(s, file.path(out_dir, "glm-summary.csv"), row.names = FALSE)
print(s, row.names = FALSE)
cat("LOADAVG_END ", readLines("/proc/loadavg"), "\n", sep = "")
cat("BENCHMARK_COMPLETE\n")