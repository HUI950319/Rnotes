library(ggplot2)
args <- commandArgs(trailingOnly=TRUE)
base <- if(length(args)) args[[1]] else '.'
a <- read.csv(file.path(base, 'get-score-summary.csv'))
b <- read.csv(file.path(base, 'get-score-bootstrap-summary.csv'))
a$seconds <- a$median_s
a$R <- 'R = 0 | median of 3 calls'
b$seconds <- ifelse(b$status == 'completed', b$elapsed_s, 1800)
b$R <- 'R = 100 | one retained call'
d <- rbind(a[,c('n','mode','config','seconds','R')], b[,c('n','mode','config','seconds','R')])
# Final summary uses 'ok' for completed conditions; validate before drawing.
print(table(b$status))
completed <- b[b$status %in% c('completed','ok','complete','success'), ]
stopifnot(nrow(completed) == 30)
completed$seconds <- completed$elapsed_s
caps <- b[!b$status %in% c('completed','ok','complete','success'), ]
caps$seconds <- 1800
fix <- function(x) {
 x$x <- x$n / 10000
 x$model <- factor(x$mode, levels=c('logistic','cox','finegray'), labels=c('Logistic','Cox','Fine-Gray'))
 x$config <- factor(x$config, levels=c('default','likelihood','all'), labels=c('AUC / BS','AIC / BIC / PVE','All five metrics'))
 x$R <- factor(x$R, levels=c('R = 0 | median of 3 calls', 'R = 100 | one retained call'))
 stopifnot(!anyNA(x$model), !anyNA(x$config))
 x
}
a <- fix(a); completed <- fix(completed); caps <- fix(caps)
caps$x <- caps$x + ifelse(caps$mode == 'cox', -.13, .13)
pts <- rbind(a[,c('x','model','config','seconds','R')],completed[,c('x','model','config','seconds','R')])
p <- ggplot(pts, aes(x,seconds,color=model,group=model)) +
 geom_line(linewidth=.7) +
 geom_errorbar(data=a,aes(ymin=min_s,ymax=max_s),width=.13,linewidth=.45) +
 geom_point(size=2.4) +
 geom_hline(data=data.frame(R=factor('R = 100 | one retained call',levels=levels(a$R))),aes(yintercept=1800),inherit.aes=FALSE,linetype='dashed',color='grey50',linewidth=.4) +
 geom_segment(data=caps,aes(xend=x,yend=2550),arrow=grid::arrow(length=grid::unit(.085,'inches')),linewidth=.55,show.legend=FALSE) +
 geom_point(data=caps,shape=17,size=2.8,show.legend=FALSE) +
 facet_grid(R~config,scales='free_y') +
 scale_color_manual(values=c('Logistic'='#00856a','Cox'='#2568ab','Fine-Gray'='#c64840')) +
 scale_x_continuous(breaks=c(1,3,5,10),limits=c(.6,10.5)) +
 scale_y_log10(breaks=c(.01,.03,.1,.3,1,3,10,30,100,300,1000,1800),labels=c('0.01','0.03','0.1','0.3','1','3','10','30','100','300','1,000','1,800')) +
 labs(x='Rows (10,000)',y='Elapsed time (seconds, log scale)',color=NULL,
 title='get_score: complete-call runtime',
 subtitle='One joint Age + Sex + Race model | survival: 100 time points | 1 thread per call',
 caption='R = 0 bars: observed min-max, not confidence intervals. R = 100 triangles/arrows: stopped after 30 min; lower bounds only.\nLines connect completed conditions only. Independent conditions could run concurrently; these are not strict R = 100 / R = 0 ratios.') +
 theme_bw(base_size=11) + theme(legend.position='top',panel.grid.minor=element_blank(),
 strip.background=element_rect(fill='#eef2f5'),strip.text=element_text(face='bold'),
 plot.title=element_text(face='bold',size=17),plot.caption=element_text(hjust=0,size=9),
 axis.text.x=element_text(size=10),panel.spacing=grid::unit(1,'lines'))
out <- if(length(args) >= 2) args[[2]] else file.path(base, 'get_score_20261003_runtime')
ggsave(paste0(out,'.png'),p,width=12.5,height=8.7,dpi=200)
ggsave(paste0(out,'.pdf'),p,width=12.5,height=8.7,device=cairo_pdf)

