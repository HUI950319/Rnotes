args <- commandArgs(trailingOnly=TRUE)
outdir <- normalizePath(args[[1]],mustWork=TRUE); setwd(outdir)
e <- new.env(); load('/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda',e)
raw <- as.data.frame(e[['seer_thyroid_mtc_2026']]); req <- c('time','DSS','event','Age','Sex','Race')
source <- droplevels(raw[complete.cases(raw[req]) & raw[['time']]>0,req])
set.seed(20261003); big <- source[sample.int(nrow(source),100000L,replace=TRUE),]; rownames(big)<-NULL
old <- dget('get-score-metadata.R')
stopifnot(identical(unname(old[['source_md5']]),unname(tools::md5sum(names(old[['source_md5']])))))
meta <- list(data_seed=20261003L,bootstrap_seed=20261004L,source_n=nrow(source),R=100L,
  model='one joint Age + Sex + Race',timepoint=seq(2,200,2), score_args=list(plots='auto',n_cores=1L),
  mc.cores=1L,BLAS_threads=1L,outer_workers_max=4L,large_groups_max=2L,full_call_repetitions=1L,
  R_version=R.version.string,versions=sapply(c('RegR','riskRegression','survival','cmprsk','prodlim','callr'),function(x)as.character(packageVersion(x))),
  source_commit=system2('git',c('-C','/mnt/e/Rpackage/RegR','rev-parse','HEAD'),stdout=TRUE),
  source_md5=tools::md5sum(names(old[['source_md5']])),installed_RegR=find.package('RegR'),
  data_md5=old[['data_md5']],start_time=as.character(Sys.time()),
  budget_s_per_call=3600L,timing='get_score full wall time; package/data loading, warmup and prior GC excluded; fit and Score traced temporarily in worker process',
  note='Up to four independent conditions run concurrently; each get_score and ordinary-bootstrap call is single-core serial. Two groups maximum once n>=100000; no precise speed ratio against isolated R=0 benchmark.')
dput(meta,'get-score-bootstrap-metadata.R')
worker <- function(d,mode,outdir,progressfile) {
 setwd(outdir); options(warn=1,mc.cores=1L)
 suppressPackageStartupMessages(library(RegR))
 RhpcBLASctl::blas_set_num_threads(1L); RhpcBLASctl::omp_set_num_threads(1L)
 data.table::setDTthreads(1L)
 configs <- list(likelihood=c('AIC','BIC','PVE'),all=c('AUC','BS','AIC','BIC','PVE'),default=c('AUC','BS'))
 run <- function(dd,config,R) {
  warnings<-character(); sink('/dev/null'); on.exit(sink())
  z<-suppressMessages(withCallingHandlers(RegR::get_score(dd,
   vars=list(full=c('Age','Sex','Race')),surv=switch(mode,logistic='DSS',cox=TRUE,finegray=FALSE),
   R=R,metrics=configs[[config]]),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}))
  list(result=z,warnings=warnings)
 }
 invisible(run(d[seq_len(min(nrow(d),1000L)),],'all',2L)); gc()
 .boot_progress <- function() {
  rss <- grep('VmRSS:',readLines('/proc/self/status'),value=TRUE)
  write.csv(data.frame(config=.bb_config,call_start=.bb_call_start,fit_count=.bb_fit_count,
    prediction_sets=.bb_prediction_count,metric_sets=.bb_metric_count,
    elapsed_s=as.numeric(Sys.time())-.bb_call_start,rss_kb=as.numeric(gsub('[^0-9]','',rss))),progressfile,row.names=FALSE)
 }
 assign('.bb_progress',.boot_progress,.GlobalEnv)
 pkg<-switch(mode,logistic='stats',cox='survival',finegray='riskRegression')
 fun<-switch(mode,logistic='glm',cox='coxph',finegray='FGR')
 trace(fun,where=asNamespace(pkg),print=FALSE,
  tracer=quote({.bb_fit_start<<-proc.time()[['elapsed']];.bb_fit_count<<-.bb_fit_count+1L}),
  exit=quote({.bb_fit_rows[[.bb_fit_count]]<<-data.frame(fit=.bb_fit_count,elapsed_s=proc.time()[['elapsed']]-.bb_fit_start);
    if(.bb_fit_count%%10L==0L).bb_progress()}))
 trace('Score',where=asNamespace('riskRegression'),print=FALSE,
  tracer=quote({.bb_score_start<<-proc.time()[['elapsed']]}),
  exit=quote({.bb_score_s<<-proc.time()[['elapsed']]-.bb_score_start}))
 trace('getPerformanceData',where=asNamespace('riskRegression'),print=FALSE,
  exit=quote({.bb_prediction_count<<-.bb_prediction_count+1L;if(.bb_prediction_count%%10L==0L).bb_progress()}))
 trace('computePerformance',where=asNamespace('riskRegression'),print=FALSE,
  exit=quote({.bb_metric_count<<-.bb_metric_count+1L;if(.bb_metric_count%%10L==0L).bb_progress()}))
 rows<-list(); values<-list()
 for(config in names(configs)) {
  assign('.bb_config',config,.GlobalEnv);assign('.bb_call_start',as.numeric(Sys.time()),.GlobalEnv)
  for(name in c('fit_count','prediction_count','metric_count')) assign(paste0('.bb_',name),0L,.GlobalEnv)
  assign('.bb_score_s',0,.GlobalEnv);assign('.bb_fit_rows',list(),.GlobalEnv)
  .boot_progress(); set.seed(20261004L);gc()
  tt<-system.time(z<-run(d,config,100L))
  result<-z[['result']];fits<-do.call(rbind,.bb_fit_rows)
  stopifnot(nrow(fits)==101L,.bb_fit_count==101L)
  validation<-list(); R_success<-NA_integer_
  if(config!='likelihood') {
   stopifnot(result[['split.method']][['B']]==100L,.bb_prediction_count==100L,.bb_metric_count==100L)
   for(metric in c('AUC','Brier')) {
    table<-as.data.frame(result[[metric]][['score']])
    stopifnot(nrow(table)>0,all(is.finite(table[[metric]])),all(is.finite(table[['se']])))
    validation[[metric]]<-table[c(intersect(c('model','times',metric,'se','lower','upper'),names(table)))]
   }
  }
  if(config!='default') {
   fs<-result[['fit.stats']];R_success<-fs[['info']][['R_success']]
   stopifnot(nrow(fs[['boot']])==100L,all(is.finite(fs[['stats']][['estimate']])))
   validation[['point']]<-fs[['stats']][c('metric','estimate')]
   validation[['likelihood_stats']]<-fs[['stats']]
   validation[['boot']]<-fs[['boot']]
  }
  validation[['rng']]<-.Random.seed;values[[config]]<-validation
  rows[[config]]<-data.frame(n=nrow(d),mode=mode,config=config,R=100L,
   bootstrap_method=if(config=='likelihood')'ordinary_subject' else 'bootcv',
   elapsed_s=unname(tt[['elapsed']]),initial_fit_s=fits$elapsed_s[1],boot_fits_s=sum(fits$elapsed_s[-1]),
   score_s=.bb_score_s,fit_count=nrow(fits),prediction_sets=.bb_prediction_count,
   metric_sets=.bb_metric_count,R_success=R_success,
   warning_count=length(z[['warnings']]),warnings=paste(unique(z[['warnings']]),collapse=' | '))
  write.csv(do.call(rbind,rows),paste0('get-score-bootstrap-',mode,'-',nrow(d),'.csv'),row.names=FALSE)
  write.csv(fits,paste0('get-score-bootstrap-fits-',mode,'-',nrow(d),'-',config,'.csv'),row.names=FALSE)
  saveRDS(values,paste0('get-score-bootstrap-values-',mode,'-',nrow(d),'.rds'))
  cat(sprintf('DONE n=%d mode=%s config=%s R=100 total=%.3f initial=%.3f bootfits=%.3f Score=%.3f success=%s warnings=%d\n',
   nrow(d),mode,config,tt[['elapsed']],fits$elapsed_s[1],sum(fits$elapsed_s[-1]),.bb_score_s,R_success,length(z[['warnings']])));flush.console()
  rm(z,result);gc();.boot_progress()
 }
 for(metric in c('AUC','Brier','rng')) stopifnot(isTRUE(all.equal(values[['all']][[metric]],values[['default']][[metric]],tolerance=1e-10)))
 stopifnot(isTRUE(all.equal(values[['all']][['point']],values[['likelihood']][['point']],tolerance=1e-10)))
 cat('BOOTCV_SUBSET_AND_POINT_PARITY_OK\n')
 do.call(rbind,rows)
}
grid<-expand.grid(mode=c('logistic','cox','finegray'),n=c(10000L,30000L,50000L,100000L),stringsAsFactors=FALSE)
queue<-seq_len(nrow(grid));active<-list();status<-list();results<-list();last_print<-0
collect <- function() {
 files<-list.files(outdir,pattern='^get-score-bootstrap-(logistic|cox|finegray)-[0-9]+\\.csv$',full.names=TRUE)
 if(length(files)) {
  tabs<-lapply(files,function(p)tryCatch(read.csv(p),error=function(e)NULL));tabs<-Filter(Negate(is.null),tabs)
  if(length(tabs))write.csv(do.call(rbind,tabs),'get-score-bootstrap-timings.csv',row.names=FALSE)
 }
}
while(length(queue)||length(active)) {
 while(length(queue) && length(active)<4L) {
  id<-queue[1];n<-grid$n[id];mode<-grid$mode[id]
  if(n>=100000L && length(active)>=2L)break
  queue<-queue[-1];key<-paste(n,mode,sep='-')
  progress<-file.path(outdir,paste0('get-score-bootstrap-progress-',key,'.csv'))
  p<-callr::r_bg(worker,args=list(d=big[seq_len(n),],mode=mode,outdir=outdir,progressfile=progress),
   stdout='|',stderr='|',supervise=TRUE,env=c(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))
  active[[key]]<-list(p=p,n=n,mode=mode,progress=progress,start=Sys.time())
  cat('START ',key,' pid=',p$get_pid(),' active=',length(active),'\n');flush.console()
 }
 for(key in names(active)) {
  job<-active[[key]];p<-job$p
  output<-p$read_output_lines();if(length(output)){cat(output,sep='\n');flush.console()}
  errors<-p$read_error_lines();if(length(errors)){cat(errors,sep='\n');flush.console()}
  state<-if(file.exists(job$progress))tryCatch(read.csv(job$progress),error=function(e)NULL)else NULL
  if(!is.null(state)&&nrow(state)==1L&&as.numeric(Sys.time())-state$call_start>3600){p$kill_tree();cat('CALL_TIMEOUT ',key,'\n')}
  if(!p$is_alive()) {
   result<-tryCatch(p$get_result(),error=function(e)e);ok<-is.data.frame(result)
   status[[key]]<-data.frame(n=job$n,mode=job$mode,status=if(ok)'ok' else 'error',error=if(ok)NA_character_ else conditionMessage(result))
   if(ok)results[[key]]<-result
   else cat('GROUP_FAILED ',key,' ',conditionMessage(result),'\n')
   write.csv(do.call(rbind,status),'get-score-bootstrap-status.csv',row.names=FALSE)
   output<-p$read_output_lines();if(length(output))cat(output,sep='\n')
   active[[key]]<-NULL;collect()
  }
 }
 if(as.numeric(Sys.time())-last_print>=45) {
  for(key in names(active)) {
   job<-active[[key]]
   if(file.exists(job$progress)) {
    s<-tryCatch(read.csv(job$progress),error=function(e)NULL)
    if(!is.null(s)&&nrow(s)==1L)cat(sprintf('PROGRESS %s %s fit=%d prediction=%d metrics=%d elapsed=%.0fs rss=%.2fGiB\n',
     key,s$config,s$fit_count,s$prediction_sets,s$metric_sets,as.numeric(Sys.time())-s$call_start,s$rss_kb/1024^2))
   }
  }
  collect();last_print<-as.numeric(Sys.time());flush.console()
 }
 Sys.sleep(.3)
}
collect()
meta[['end_time']]<-as.character(Sys.time());dput(meta,'get-score-bootstrap-metadata.R')
cat('BOOTSTRAP_MATRIX_FINISHED\n')
print(do.call(rbind,status))
