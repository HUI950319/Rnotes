args<-commandArgs(TRUE);outdir<-normalizePath(args[1]);setwd(outdir)
files<-list.files(pattern='^get-score-bootstrap-(logistic|cox|finegray)-[0-9]+\\.csv$')
done<-do.call(rbind,lapply(files,read.csv));done$key<-paste(done$n,done$mode,done$config,sep='-')
stopifnot(!anyDuplicated(done$key),all(done$fit_count==101),all(done$warning_count==0),all(done$R_success[done$config!='default']==100),all(done$prediction_sets[done$config!='likelihood']==100),all(done$metric_sets[done$config!='likelihood']==100))
timeout<-if(file.exists('get-score-bootstrap-timeouts.csv'))read.csv('get-score-bootstrap-timeouts.csv')else data.frame(key=character())
grid<-expand.grid(n=c(10000L,30000L,50000L,100000L),mode=c('logistic','cox','finegray'),config=c('default','likelihood','all'),stringsAsFactors=FALSE)
grid$key<-paste(grid$n,grid$mode,grid$config,sep='-');grid$status<-ifelse(grid$key%in%done$key,'completed',ifelse(grid$key%in%timeout$key,'timeout','pending'))
for(col in c('elapsed_s','initial_fit_s','boot_fits_s','score_s','fit_count','prediction_sets','metric_sets','R_success','warning_count'))grid[[col]]<-done[[col]][match(grid$key,done$key)]
grid$budget_s<-1800L;grid$metric_sets_last_snapshot<-NA_integer_;grid$rss_gib_last_snapshot<-NA_real_
if(nrow(timeout))for(i in which(grid$status=='timeout')){j<-match(grid$key[i],timeout$key);grid$fit_count[i]<-timeout$fit_count[j];grid$prediction_sets[i]<-timeout$prediction_sets[j];grid$metric_sets_last_snapshot[i]<-timeout$metric_sets_last_snapshot[j];grid$rss_gib_last_snapshot[i]<-timeout$rss_gib_last_snapshot[j]}
write.csv(grid,'get-score-bootstrap-summary.csv',row.names=FALSE)
validation<-list();fitrows<-list()
for(mode in c('logistic','cox','finegray'))for(n in c(10000L,30000L,50000L,100000L)){
 key<-paste(n,mode,sep='-');path<-paste0('get-score-bootstrap-values-',mode,'-',n,'.rds');v<-if(file.exists(path))readRDS(path)else list()
 prediction_parity<-if(all(c('all','default')%in%names(v)))all(vapply(c('AUC','Brier','rng'),function(m)isTRUE(all.equal(v$all[[m]],v$default[[m]],tolerance=1e-10)),logical(1)))else NA
 likelihood_parity<-if(all(c('all','likelihood')%in%names(v)))isTRUE(all.equal(v$all$point,v$likelihood$point,tolerance=1e-10))else NA
 stopifnot(is.na(prediction_parity)||prediction_parity,is.na(likelihood_parity)||likelihood_parity)
 validation[[key]]<-data.frame(n=n,mode=mode,prediction_parity=prediction_parity,likelihood_point_parity=likelihood_parity)
}
write.csv(do.call(rbind,validation),'get-score-bootstrap-validation.csv',row.names=FALSE)
for(i in seq_len(nrow(done))){p<-paste0('get-score-bootstrap-fits-',done$mode[i],'-',done$n[i],'-',done$config[i],'.csv');f<-read.csv(p);stopifnot(nrow(f)==101);fitrows[[i]]<-cbind(done[rep(i,nrow(f)),c('n','mode','config'),drop=FALSE],f)}
write.csv(do.call(rbind,fitrows),'get-score-bootstrap-fit-timings.csv',row.names=FALSE)
label<-c(logistic='Logistic',cox='Cox',finegray='Fine–Gray')
config_label<-c(default='默认 AUC/BS',likelihood='仅 AIC/BIC/PVE',all='全部五项')
lines<-c('# get_score：100次 bootstrap 大样本耗时评估','',paste0('生成时间（UTC+08:00）：',format(Sys.time(),tz='Asia/Shanghai',usetz=TRUE)),'',
 '每个条件以 `get_score(R = 100)` 为计时单位，保留一次正式测量。每个条件限时30分钟；超时记录为 `>30分钟`，没有完成的指标不会计作100次完整评估。','',
 '|模型|指标|1万|3万|5万|10万|','|---|---|---:|---:|---:|---:|')
for(mode in names(label))for(config in names(config_label)){
 z<-grid[grid$mode==mode&grid$config==config,];z<-z[match(c(10000L,30000L,50000L,100000L),z$n),]
 value<-ifelse(z$status=='completed',sprintf('%.2f秒 (%.2f分)',z$elapsed_s,z$elapsed_s/60),ifelse(z$status=='timeout','>30分钟','待完成'))
 lines<-c(lines,paste0('|',label[[mode]],'|',config_label[[config]],'|',paste(value,collapse='|'),'|'))
}
lines<-c(lines,'','## 测试口径','',
 '- WSL Ubuntu-22.04，R 4.4.3；Intel Ultra 9 275HX。每个调用内部单核；BLAS、OMP、data.table均为1线程，`mc.cores = 1`。最多4个独立条件同时运行，10万条件最多2个。',
 '- 使用 RegR 自带 SEER 甲状腺髓样癌数据，完整且随访时间大于0的4387行；固定种子20261003有放回抽样至10万，再取嵌套前缀。10万不是10万名独立患者。保留月度时间并列值。',
 '- `vars = list(full = c("Age", "Sex", "Race"))`：一个联合模型。Logistic使用DSS，Cox使用生存结局，Fine–Gray使用FGR且`variance = FALSE`。',
 '- `R = 100`，bootstrap种子20261004；生存预测指标使用100个时间点 `seq(2, 200, 2)`，`score_args = list(plots = "auto", n_cores = 1)`。',
 '- AUC/BS使用bootcv验证集评估；仅AIC/BIC/PVE使用普通受试者bootstrap；全指标调用的似然指标区间来自bootcv训练模型。不同重采样方式的似然区间不应直接当作同一数值结果。',
 '- 计时包括模型拟合、bootstrap、预测、指标及表格/绘图对象构建；不包括加载包/数据、预热、计时前GC及实际绘图渲染。',
 '- 本轮完整100次bootstrap调用每条件实测一次；上一轮R=0是每条件独立运行3次的中位数。本轮存在条件间并发，因此不计算严格的R=100/R=0速度倍数。',
 '- 补测调度曾短暂重复启动5万Fine–Gray默认和10万Cox全指标条件，已立即停止并排除重复调用。原正式进程继续运行；10万Cox全指标期间曾短暂增加并发负载。这一扰动限制了该条件计时/部分进度的精细比较。修正后的驱动检查仍在运行的组合并控制高内存条件总并发不超过2。',
 '- 3万Cox在1000行、R=2的预热阶段发生格式化错误，正式计时未开始；补测改用R=0预热，正式评估仍为R=100。此错误属于已记录的预热结果，包源码未作修改。',
 '- 5万Fine–Gray默认条件限时停止后，补测调度器读取已关闭日志连接时退出，连带中断了尚未超时的10万Cox默认调用。修正日志读取后重新运行10万Cox默认条件；被中断的调用不计入正式计时，表中只保留重新运行的最终状态。','',
 '## 分阶段计时','',
 'Score计时包含其内部100次重拟合，不能与bootstrap拟合耗时相加。似然指标普通bootstrap没有Score阶段。','',
 '|样本量|模型|指标|总秒数|原始拟合秒数|100次重拟合合计秒数|Score秒数|','|---:|---|---|---:|---:|---:|---:|')
for(i in seq_len(nrow(done))){x<-done[i,];lines<-c(lines,sprintf('|%d|%s|%s|%.3f|%.3f|%.3f|%.3f|',x$n,label[[x$mode]],config_label[[x$config]],x$elapsed_s,x$initial_fit_s,x$boot_fits_s,x$score_s))}
if(nrow(timeout)){
 lines<-c(lines,'','## 超时条件与已完成进度','',
 '进度每10次写入一次。验证指标数量是停止前最近一次快照的下界，写作“至少”；拟合和预测全部完成不表示验证指标评估全部完成。','',
 '|样本量|模型|指标|原始+bootstrap拟合|预测集合|已完成验证集合至少|最近RSS GiB|','|---:|---|---|---:|---:|---:|---:|')
 for(i in seq_len(nrow(timeout))){x<-timeout[i,];lines<-c(lines,sprintf('|%d|%s|%s|%d/101|%d/100|%d/100|%.2f|',x$n,label[[x$mode]],config_label[[x$config]],x$fit_count,x$prediction_sets,x$metric_sets_last_snapshot,x$rss_gib_last_snapshot))}
}
v<-do.call(rbind,validation)
lines<-c(lines,'','## 结果核验','',sprintf('- 完成条件：%d/36；30分钟停止条件：%d/36；待完成：%d/36。',sum(grid$status=='completed'),sum(grid$status=='timeout'),sum(grid$status=='pending')),
 '- 每个完成条件确认1次原始拟合+100次bootstrap重拟合。预测条件确认100次预测及100次验证集计算；似然指标确认`R_success = 100`。完成条件未产生警告。',
 sprintf('- 在全指标与默认预测均完成的%d组中，AUC/Brier、SE、CI及最终随机数状态一致（容差1e-10）；全指标与仅似然均完成的%d组，原始AIC/BIC/PVE点估计一致。',sum(!is.na(v$prediction_parity)),sum(!is.na(v$likelihood_point_parity))),
 '- 超时调用不报告最终区间或完整R=100耗时；没有对应完整结果的组，不能验证全指标与默认预测的一致性。','',
 '## 产物','',
 '- `get-score-bootstrap-summary.csv`：36个条件状态、计时和部分进度。',
 '- `get-score-bootstrap-timings.csv`：完成调用的阶段计时。',
 '- `get-score-bootstrap-timeouts.csv`：30分钟停止条件与进度快照（有超时才生成）。',
 '- `get-score-bootstrap-fit-timings.csv`：完成调用的逐次原始/重拟合耗时。',
 '- `get-score-bootstrap-validation.csv`：数值一致性核验。',
 '- 原始分组/补测status文件保留进程日志；分组error包括人为限时终止或预热失败，不等于最终条件失败。最终条件状态以summary.csv为准。',
 '- `get-score-bootstrap-metadata.R`：版本、参数、源码/数据校验。',
 '- `get-score-bootstrap-run.R`：按条件30分钟限制、复用已有完成/超时记录的补测及复现驱动。',
 '- `get-score-bootstrap-benchmark.R`：最初运行脚本；运行中由独立watchdog执行用户追加的30分钟限制。复现应使用`get-score-bootstrap-run.R`。',
 '- `get-score-report.md`：此前R=0评估报告。')
writeLines(enc2utf8(lines),'get-score-bootstrap-report.md',useBytes=TRUE)
print(table(grid$status));print(v)







