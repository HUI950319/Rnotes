# get_score 2026-10-03 performance evidence

R=0: get-score-summary.csv has 36 cells; get-score-timings.csv has 108 calls (three repeats per cell).
R=100: get-score-bootstrap-summary.csv has 36 final statuses (30 completed, 6 stopped at the nominal 1800-second budget); get-score-bootstrap-timeouts.csv records last progress snapshots and actual stop wall time. The observer reserves 10 seconds for pre-timing GC/polling.
get-score-bootstrap-fit-timings.csv has 3030 fit timings from completed calls (original + 100 refits).
Per-group CSV/RDS files preserve resume and numerical validation evidence; values RDS contain aggregate metric/likelihood tables and RNG states, not individual patient data.

Use a fresh existing output directory. Copy get-score-bootstrap-run.R AND get-score-bootstrap-benchmark.R into it, then run:
Rscript /absolute/output/get-score-bootstrap-run.R /absolute/output
The runner extracts the worker from the initial script, uses R=0 warmup, and applies a separate per-cell budget. The original initial script alone used a 3600-second controller; the actual run was externally supervised after the user requested a 30-minute cap.
The scripts use /mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda and installed RegR; adjust the path for another environment. This archive does NOT distribute the patient data. Recorded package versions and source/data hashes are in the metadata files; timing is hardware-specific.

The descriptive report generator includes notes specific to this observed run. Interrupted/duplicate calls were excluded; 30k Cox was retried after a tiny R=2 warmup error; 100k Cox default was rerun after a closed-log scheduler interruption. Final timeouts are not completed 100-bootstrap assessments.
R=0 isolated three-repeat medians and R=100 concurrent single retained calls do not support a precise speedup ratio. Bootstrap prediction metrics use bootcv, while likelihood-only intervals use ordinary subject bootstrap.
SHA256SUMS lists the packaged evidence files. The archive excludes all .rda and individual-level input records.

Recreate the figure from the two summary CSVs: Rscript get-score-runtime-plot.R /absolute/evidence /absolute/output/get_score_20261003_runtime (ggplot2 required).
