# Standalone per-condition runner. R=100, fixed seeds; completed/time-limited cells are skipped.
# Run: Rscript get-score-bootstrap-run.R /absolute/output/directory
# For a fresh run, copy this file and get-score-bootstrap-benchmark.R into an empty output directory.
# Nominal budget is 1800 s; the watcher permits 10 s for pre-timing GC and polling overhead.
# Maximum four independent calls, maximum two calls with n >= 50000; each call uses one core.
args <- commandArgs(TRUE)
outdir <- normalizePath(args[1]); setwd(outdir)
expr <- parse('get-score-bootstrap-benchmark.R')
assignment <- Filter(function(x)is.call(x)&&identical(x[[1]],as.name('<-'))&&identical(x[[2]],as.name('worker')),as.list(expr))
eval(assignment[[1]])
b <- paste(deparse(body(worker),width.cutoff=500),collapse='\n')
b <- sub('invisible(run(d[seq_len(min(nrow(d), 1000L)), ], "all", 2L))','invisible(run(d[seq_len(min(nrow(d), 1000L)), ], "all", 0L))',b,fixed=TRUE)
b <- sub('rows <- list()', 'donefile <- paste0("get-score-bootstrap-", mode, "-", nrow(d), ".csv"); rows <- if(file.exists(donefile)) {tab <- read.csv(donefile); setNames(lapply(seq_len(nrow(tab)), function(i)tab[i,,drop=FALSE]),tab$config)} else list()', b,fixed=TRUE)
b <- sub('values <- list()', 'valuefile <- paste0("get-score-bootstrap-values-", mode, "-", nrow(d), ".rds"); values <- if(file.exists(valuefile))readRDS(valuefile)else list()',b,fixed=TRUE)
b <- sub('for (config in names(configs))', 'for (config in target_config)',b,fixed=TRUE)
b <- sub('for (metric in c("AUC", "Brier", "rng"))', 'if(all(c("all","default","likelihood") %in% names(values))) { for (metric in c("AUC", "Brier", "rng"))',b,fixed=TRUE)
b <- sub('cat("BOOTCV_SUBSET_AND_POINT_PARITY_OK\\n")','cat("BOOTCV_SUBSET_AND_POINT_PARITY_OK\\n") }',b,fixed=TRUE)
formals(worker)<-c(formals(worker),alist(target_config=))
body(worker)<-parse(text=b)[[1]]
e <- new.env();load('/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda',e)
raw<-as.data.frame(e[['seer_thyroid_mtc_2026']]);req<-c('time','DSS','event','Age','Sex','Race')
source<-droplevels(raw[complete.cases(raw[req]) & raw[['time']]>0,req]);set.seed(20261003)
big<-source[sample.int(nrow(source),100000L,replace=TRUE),];rownames(big)<-NULL
meta_created <- !file.exists('get-score-bootstrap-metadata.R')
if(meta_created) {
 meta<-list(data_seed=20261003L,bootstrap_seed=20261004L,source_n=nrow(source),R=100L,
 model='one joint Age + Sex + Race',timepoint=seq(2,200,2),score_args=list(plots='auto',n_cores=1L),
 mc.cores=1L,BLAS_threads=1L,outer_workers_max=4L,large_groups_max=2L,full_call_repetitions=1L,
 R_version=R.version.string,versions=sapply(c('RegR','riskRegression','survival','cmprsk','prodlim','callr'),function(x)as.character(packageVersion(x))),
 source_commit=system2('git',c('-C','/mnt/e/Rpackage/RegR','rev-parse','HEAD'),stdout=TRUE),
 source_md5=tools::md5sum(c('/mnt/e/Rpackage/RegR/R/msr-riskRegression.R','/mnt/e/Rpackage/RegR/R/msr-fit-stats.R')),
 data_md5=unname(tools::md5sum('/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda')),
 installed_RegR=find.package('RegR'),start_time=as.character(Sys.time()),timestamp_timezone=Sys.timezone(),
 budget_s_per_call=1800L,pre_timing_gc_grace_s=10L,warmup_R=0L,
 timing='full get_score call wall time; loading, warmup and pre-timing GC excluded; each condition measured once',
 note='Up to four independent calls; at most two n>=50000 calls; each call internally single-core.')
 dput(meta,'get-score-bootstrap-metadata.R')
}
queue <- if(length(args)>1)expand.grid(n=30000L,mode='cox',config=c('likelihood','all','default'),stringsAsFactors=FALSE)else expand.grid(config=c('likelihood','all','default'),mode=c('logistic','cox','finegray'),n=c(10000L,30000L,50000L,100000L),stringsAsFactors=FALSE)
active<-list();status<-list();last_print<-0
completed <- function(n,mode,config) {
 file<-paste0('get-score-bootstrap-',mode,'-',n,'.csv');ledger<-'get-score-bootstrap-timeouts.csv'
 (file.exists(file)&&config%in%read.csv(file)$config)||(file.exists(ledger)&&paste(n,mode,config,sep='-')%in%read.csv(ledger)$key)
}
collect<-function(){files<-list.files(pattern='^get-score-bootstrap-(logistic|cox|finegray)-[0-9]+\\.csv$');if(length(files))write.csv(do.call(rbind,lapply(files,read.csv)),'get-score-bootstrap-timings.csv',row.names=FALSE)}
while(nrow(queue)||length(active)) {
 external <- character()
 for(i in if(nrow(queue))rev(seq_len(nrow(queue)))else integer())if(completed(queue$n[i],queue$mode[i],queue$config[i]))queue<-queue[-i,,drop=FALSE]
 while(nrow(queue)&&length(active)+length(external)<if(length(args)>1)1L else 4L) {
  busy<-c(external,vapply(active,function(x)x$group,character(1)))
  large_count<-sum(as.integer(sub('-.*','',busy))>=50000L)
  eligible<-which(!paste(queue$n,queue$mode,sep='-')%in%busy & (queue$n<50000L|large_count<2L))
  if(!length(eligible))break
  i<-eligible[1];cell<-queue[i,,drop=FALSE];queue<-queue[-i,,drop=FALSE];group<-paste(cell$n,cell$mode,sep='-');key<-paste(group,cell$config,sep='-')
  progress<-file.path(outdir,paste0('get-score-bootstrap-progress-',group,'.csv'));if(file.exists(progress))unlink(progress)
  p<-callr::r_bg(worker,args=list(d=big[seq_len(cell$n),],mode=cell$mode,outdir=outdir,progressfile=progress,target_config=cell$config),stdout='|',stderr='|',supervise=TRUE,env=c(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))
  active[[key]]<-list(p=p,cell=cell,group=group,progress=progress,timedout=FALSE);cat('SUPPLEMENT_START ',key,' pid=',p$get_pid(),'\n');flush.console()
 }
 for(key in names(active)) {
  job<-active[[key]];p<-job$p
  lines<-c(tryCatch(p$read_output_lines(),error=function(e)character()),tryCatch(p$read_error_lines(),error=function(e)character()));if(length(lines))cat(lines,sep='\n')
  s<-if(file.exists(job$progress))tryCatch(read.csv(job$progress),error=function(e)NULL)else NULL
  if(!is.null(s)&&nrow(s)==1L&&as.numeric(Sys.time())-s$call_start>=1810&&!completed(job$cell$n,job$cell$mode,job$cell$config)) {
   ledger<-'get-score-bootstrap-timeouts.csv';old<-if(file.exists(ledger))read.csv(ledger)else data.frame()
   row<-data.frame(key=key,n=job$cell$n,mode=job$cell$mode,config=job$cell$config,status='timeout',budget_s=1800L,stopped_elapsed_wall_s=as.numeric(Sys.time())-s$call_start,fit_count=s$fit_count,prediction_sets=s$prediction_sets,metric_sets_last_snapshot=s$metric_sets,rss_gib_last_snapshot=s$rss_kb/1024^2,pid=p$get_pid())
   write.csv(rbind(old,row),ledger,row.names=FALSE);p$kill_tree();job$timedout<-TRUE;active[[key]]<-job;cat('SUPPLEMENT_USER_BUDGET_STOP ',key,' metrics>=',s$metric_sets,'\n')
  }
  if(!p$is_alive()) {
   result<-tryCatch(p$get_result(),error=function(e)e);ok<-is.data.frame(result)
   status[[key]]<-data.frame(key=key,n=job$cell$n,mode=job$cell$mode,config=job$cell$config,status=if(job$timedout)'timeout' else if(ok)'ok' else 'error',error=if(ok)NA_character_ else conditionMessage(result))
   if(!ok&&!job$timedout)cat('SUPPLEMENT_ERROR ',key,' ',conditionMessage(result),'\n')
   write.csv(do.call(rbind,status),if(length(args)>1)'get-score-bootstrap-supplement-cox-status.csv'else 'get-score-bootstrap-supplement-status.csv',row.names=FALSE)
   active[[key]]<-NULL;collect()
  }
 }
 if(as.numeric(Sys.time())-last_print>45){for(key in names(active)){s<-tryCatch(read.csv(active[[key]]$progress),error=function(e)NULL);if(!is.null(s)&&nrow(s)==1L)cat(sprintf('SUPPLEMENT_PROGRESS %s fit=%d prediction=%d metrics=%d elapsed=%.0fs rss=%.2fGiB\n',key,s$fit_count,s$prediction_sets,s$metric_sets,as.numeric(Sys.time())-s$call_start,s$rss_kb/1024^2))};last_print<-as.numeric(Sys.time());collect();flush.console()}
 Sys.sleep(.3)
}
collect();cat('SUPPLEMENT_FINISHED\n')







if(meta_created) {
 meta[['end_time']]<-as.character(Sys.time());dput(meta,'get-score-bootstrap-metadata.R')
}
