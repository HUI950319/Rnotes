args <- commandArgs(trailingOnly=TRUE)
outdir <- normalizePath(args[[1]], mustWork=TRUE)
setwd(outdir)
Sys.setenv(OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1, MKL_NUM_THREADS=1)
e <- new.env(); load('/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda', e)
raw <- as.data.frame(e[['seer_thyroid_mtc_2026']])
required <- c('time','DSS','event','Age','Sex','Race')
source <- droplevels(raw[complete.cases(raw[required]) & raw[['time']] > 0, required])
set.seed(20261003)
big <- source[sample.int(nrow(source), 100000L, replace=TRUE), ]; rownames(big) <- NULL
metadata <- list(seed=20261003, source_n=nrow(raw), complete_n=nrow(source),
 data_md5=unname(tools::md5sum('/mnt/e/Rpackage/RegR/data/seer_thyroid_mtc_2026.rda')),
 construction='nested resampling with replacement; original integer-month times retained',
 model='one joint model: Age + Sex + Race', R=0L, timepoint=seq(2,200,2),
 score_args=list(plots='auto', n_cores=1L), repetitions=3L, threads=1L,
 source_commit=system2('git', c('-C','/mnt/e/Rpackage/RegR','rev-parse','HEAD'), stdout=TRUE),
 source_md5=tools::md5sum(file.path('/mnt/e/Rpackage/RegR/R', c('msr-riskRegression.R','msr-fit-stats.R'))),
 R_version=R.version.string, cpu=grep('model name', readLines('/proc/cpuinfo'), value=TRUE)[1],
 versions=sapply(c('RegR','riskRegression','cmprsk','survival','prodlim','callr'), function(x) as.character(packageVersion(x))),
 installed_RegR=find.package('RegR'), loadavg_start=readLines('/proc/loadavg'),
 timing='system.time(get_score): includes fitting, Score, tables and plot object construction; excludes package/data loading, prior GC and plot rendering',
 per_call_budget_s=180)
dput(metadata, 'get-score-metadata.R')
capture.output(sessionInfo(), file='get-score-session.txt')
worker <- function(d, mode, outdir, marker) {
  setwd(outdir); options(warn=1, mc.cores=1L)
  suppressPackageStartupMessages(library(RegR))
  RhpcBLASctl::blas_set_num_threads(1); RhpcBLASctl::omp_set_num_threads(1)
  configs <- list(default=c('AUC','BS'), likelihood=c('AIC','BIC','PVE'), all=c('AUC','BS','AIC','BIC','PVE'))
  run <- function(dd, metrics) {
    warnings <- character()
    sink('/dev/null'); on.exit(sink())
    result <- suppressMessages(withCallingHandlers(RegR::get_score(dd,
      vars=list(full=c('Age','Sex','Race')), surv=switch(mode, logistic='DSS', cox=TRUE, finegray=FALSE),
      metrics=metrics, R=0L), warning=function(w) {
        warnings <<- c(warnings, conditionMessage(w)); invokeRestart('muffleWarning')
      }))
    list(result=result, warnings=warnings)
  }
  invisible(run(d[seq_len(min(1000L,nrow(d))), ], configs[['all']]))
  pkg <- switch(mode, logistic='stats', cox='survival', finegray='riskRegression')
  fun <- switch(mode, logistic='glm', cox='coxph', finegray='FGR')
  trace(fun, where=asNamespace(pkg), print=FALSE,
    tracer=quote({.scorebench_fit_start <<- proc.time()[['elapsed']]; .scorebench_fit_count <<- .scorebench_fit_count+1L}),
    exit=quote({.scorebench_fit_s <<- .scorebench_fit_s+proc.time()[['elapsed']]-.scorebench_fit_start}))
  trace('Score', where=asNamespace('riskRegression'), print=FALSE,
    tracer=quote({.scorebench_score_start <<- proc.time()[['elapsed']]}),
    exit=quote({.scorebench_score_s <<- .scorebench_score_s+proc.time()[['elapsed']]-.scorebench_score_start}))
  path <- paste0('get-score-', mode, '-', nrow(d), '.csv')
  rows <- list(); metrics_out <- list(); checks <- list()
  for (rep in 1:3) for (config in names(configs)[((0:2+rep-1L) %% 3L)+1L]) {
    assign('.scorebench_fit_s',0,.GlobalEnv); assign('.scorebench_score_s',0,.GlobalEnv)
    assign('.scorebench_fit_count',0L,.GlobalEnv)
    gc()
    writeLines(sprintf('%.6f', as.numeric(Sys.time())), marker)
    tt <- system.time(z <- run(d, configs[[config]]))
    unlink(marker)
    stopifnot(.scorebench_fit_count==1L)
    result <- z[['result']]
    if (config != 'likelihood') {
      for (metric in c('AUC','Brier')) {
        table <- as.data.frame(result[[metric]][['score']])
        stopifnot(nrow(table)>0, all(is.finite(table[[metric]])))
        metrics_out[[paste(rep,config,metric)]] <- table[c(intersect(c('model','times',metric,'se','lower','upper'), names(table)))]
      }
    }
    if (config != 'default') {
      fs <- result[['fit.stats']]
      stopifnot(all(is.finite(fs[['stats']][['estimate']])), fs[['info']][['n']]==nrow(d))
      if (mode=='finegray') stopifnot(inherits(fs[['obj']][[1]],'FGR'), isTRUE(fs[['obj']][[1]][['crrFit']][['converged']]))
      metrics_out[[paste(rep,config,'likelihood')]] <- fs[['stats']][c('metric','estimate')]
    }
    rows[[length(rows)+1L]] <- data.frame(n=nrow(d), mode=mode, config=config, replicate=rep,
      elapsed_s=unname(tt[['elapsed']]), fit_s=.scorebench_fit_s, score_s=.scorebench_score_s,
      other_s=unname(tt[['elapsed']])-.scorebench_fit_s-.scorebench_score_s,
      user_s=unname(tt[['user.self']]), system_s=unname(tt[['sys.self']]),
      fit_count=.scorebench_fit_count, target_events=sum(d[['event']]==1),
      warning_count=length(z[['warnings']]), warnings=paste(unique(z[['warnings']]),collapse=' | '))
    write.csv(do.call(rbind,rows),path,row.names=FALSE)
    cat(sprintf('DONE n=%d mode=%s config=%s rep=%d total=%.3f fit=%.3f Score=%.3f\n',
      nrow(d),mode,config,rep,tt[['elapsed']],.scorebench_fit_s,.scorebench_score_s)); flush.console()
    rm(z,result); gc()
  }
  for (rep in 1:3) {
    for (metric in c('AUC','Brier')) {
      stopifnot(isTRUE(all.equal(metrics_out[[paste(rep,'default',metric)]],metrics_out[[paste(rep,'all',metric)]],tolerance=1e-10)))
    }
    stopifnot(isTRUE(all.equal(metrics_out[[paste(rep,'likelihood','likelihood')]],metrics_out[[paste(rep,'all','likelihood')]],tolerance=1e-10)))
  }
  cat('METRIC_PARITY_OK\n')
  do.call(rbind,rows)
}
all <- list(); status <- list()
for (n in c(10000L,30000L,50000L,100000L)) for (mode in c('logistic','cox','finegray')) {
  key <- paste(n,mode,sep='-'); cat('START ',key,'\n'); flush.console()
  marker <- file.path(outdir,paste0('get-score-',key,'.started'))
  p <- callr::r_bg(worker, args=list(d=big[seq_len(n), ],mode=mode,outdir=outdir,marker=marker),
    stdout='|',stderr='|',supervise=TRUE, env=c(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))
  started <- Sys.time(); timed_out <- FALSE
  while (p$is_alive()) {
    output <- p$read_output_lines(); errors <- p$read_error_lines()
    if(length(output)) {cat(output,sep='\n'); flush.console()}
    if(length(errors)) {cat(errors,sep='\n'); flush.console()}
    if (file.exists(marker)) {
      at <- suppressWarnings(as.numeric(readLines(marker,warn=FALSE)))
      if(length(at)==1L && is.finite(at) && as.numeric(Sys.time())-at>180) {timed_out<-TRUE; p$kill_tree(); break}
    } else if(as.numeric(difftime(Sys.time(),started,units='secs'))>1800) {timed_out<-TRUE; p$kill_tree(); break}
    Sys.sleep(.2)
  }
  result <- tryCatch(p$get_result(),error=function(e)e)
  output <- p$read_output_lines(); if(length(output)) cat(output,sep='\n')
  errors <- p$read_error_lines(); if(length(errors)) cat(errors,sep='\n')
  ok <- is.data.frame(result)
  status[[key]] <- data.frame(n=n,mode=mode,status=if(ok)'ok' else if(timed_out)'timeout' else 'error',
    error=if(ok)NA_character_ else conditionMessage(result))
  write.csv(do.call(rbind,status),'get-score-status.csv',row.names=FALSE)
  if(ok) all[[key]] <- result
  else cat('GROUP_FAILED ',key,' ',conditionMessage(result),'\n')
  if(length(all)) write.csv(do.call(rbind,all),'get-score-timings.csv',row.names=FALSE)
  flush.console()
}
if (length(all)) {
 timings <- do.call(rbind,all)
 groups <- split(timings,interaction(timings$n,timings$mode,timings$config,drop=TRUE))
 summary <- do.call(rbind,lapply(groups,function(x) data.frame(n=x$n[1],mode=x$mode[1],config=x$config[1],reps=nrow(x),
   median_s=median(x$elapsed_s),min_s=min(x$elapsed_s),max_s=max(x$elapsed_s),
   median_fit_s=median(x$fit_s),median_score_s=median(x$score_s),median_other_s=median(x$other_s),warnings=sum(x$warning_count))))
 summary <- summary[order(summary$mode,summary$config,summary$n), ]; rownames(summary)<-NULL
 write.csv(summary,'get-score-summary.csv',row.names=FALSE)
 print(summary)
}
cat('BENCHMARK_FINISHED\n')

