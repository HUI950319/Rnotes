args <- commandArgs(TRUE)
suppressPackageStartupMessages(library(RegR))
options(mc.cores = 2L)
data.table::setDTthreads(1)
e <- new.env(parent = asNamespace("RegR"))
sys.source("/mnt/e/Rpackage/RegR/R/msr-riskRegression.R", e)
sys.source("/mnt/e/Rpackage/RegR/R/utils-parallel.R", e)
for (f in c("get_score", ".score_by_model", ".score_foreach_backend", "oo_pblapply"))
  stopifnot(identical(body(get(f, e)), body(get(f, asNamespace("RegR")))))
d <- readRDS(file.path(args[[1L]], "input.rds"))[1:300, ]
run <- function(k) {
  set.seed(20261008)
  invisible(capture.output(z <- suppressMessages(get_score(d, list(full = c("Age", "Sex", "Race")),
    timepoint = c(24, 60), R = 4L, score_args = list(n_cores = k)))))
  list(AUC = z$AUC$score, Brier = z$Brier$score, table = z$AUC.BS.AIC, seed = .Random.seed)
}
stopifnot(isTRUE(all.equal(run(1L), run(2L), tolerance = 1e-12)))
cat("INSTALLED_SMOKE_PASS", find.package("RegR"), "\n")
