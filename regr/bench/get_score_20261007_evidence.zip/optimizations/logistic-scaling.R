args <- commandArgs(TRUE)
outdir <- args[[1L]]
Sys.setenv(OPENBLAS_NUM_THREADS = 1, OMP_NUM_THREADS = 1, R_DATATABLE_NUM_THREADS = 1)
suppressPackageStartupMessages(library(RegR))
RhpcBLASctl::blas_set_num_threads(1)
RhpcBLASctl::omp_set_num_threads(1)
data.table::setDTthreads(1)
pbapply::pboptions(type = "none")
options(mc.cores = 4L)
d <- readRDS(file.path(outdir, "input.rds"))
run <- function(n, cores, reps = 100L) {
  set.seed(20261008)
  con <- file(nullfile(), "wt")
  sink(con)
  on.exit({sink(); close(con)})
  z <- suppressMessages(get_score(d[seq_len(n), ], list(full = c("Age", "Sex", "Race")),
                                  surv = "DSS", R = reps, score_args = list(n_cores = cores)))
  list(AUC = as.data.frame(z$AUC$score), Brier = as.data.frame(z$Brier$score),
       summary = z$AUC.BS.AIC, rng = .Random.seed)
}
for (k in c(1L, 2L, 4L)) invisible(run(300L, k, 3L))
rows <- list()
for (n in c(1000L, 10000L)) {
  reference <- NULL
  for (i in 1:3) for (k in if (i %% 2L) c(1L, 2L, 4L) else c(4L, 2L, 1L)) {
    invisible(gc())
    tm <- system.time(z <- run(n, k))[["elapsed"]]
    if (is.null(reference)) reference <- z else stopifnot(isTRUE(all.equal(z, reference, tolerance = 1e-10)))
    rows[[length(rows) + 1L]] <- data.frame(n, R = 100L, cores = k, rep = i, elapsed = tm)
    write.csv(do.call(rbind, rows), file.path(outdir, "step2-logistic-scaling.csv"), row.names = FALSE)
    cat(n, k, i, tm, "PARITY_OK\n")
  }
}
print(aggregate(elapsed ~ n + cores, do.call(rbind, rows), function(x) c(median = median(x), min = min(x), max = max(x))))
