args <- commandArgs(TRUE)
outdir <- args[[1L]]
root <- if (.Platform$OS.type == "windows") "E:/Rpackage/RegR" else "/mnt/e/Rpackage/RegR"
suppressPackageStartupMessages(library(RegR))
data.table::setDTthreads(1)
options(mc.cores = 2L)
versions <- lapply(c("before", "after"), function(v) {
  e <- new.env(parent = asNamespace("RegR"))
  sys.source(if (v == "before") file.path(outdir, "step3-before-msr-riskRegression.R") else
               file.path(root, "R/msr-riskRegression.R"), e)
  e
})
d <- readRDS(file.path(outdir, "input.rds"))[1:6000, ]
d$time <- d$time + 100
cases <- list(early = list(timepoint = c(seq(1, 99, length.out = 90), seq(110, 200, 10))),
              brier = list(timepoint = seq(2, 200, 2), metrics = "BS_score"),
              extra = list(timepoint = seq(2, 200, 2), times = c("Extra" = 55.5)))
for (nm in names(cases)) for (mode in c(TRUE, FALSE)) {
  run <- function(e) {
    set.seed(42)
    warnings <- character()
    invisible(capture.output(z <- withCallingHandlers(suppressMessages(do.call(e$get_score,
      c(list(data = d, vars = list(full = c("Age", "Sex", "Race")), surv = mode,
             score_args = list(n_cores = 1L)), cases[[nm]]))), warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")
      })))
    list(obj = z$obj, table = z$AUC.BS.AIC, seed = .Random.seed, warnings = warnings)
  }
  eq <- all.equal(run(versions[[1]]), run(versions[[2]]), tolerance = 1e-12)
  if (!isTRUE(eq)) {print(eq); stop(nm, " boundary parity failed")}
  cat(nm, mode, "FULL_PARITY_OK\n")
}
