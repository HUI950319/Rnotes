args <- commandArgs(TRUE)
outdir <- args[[1L]]
suppressPackageStartupMessages(library(RegR))
options(mc.cores = 2L)
data.table::setDTthreads(1)
d <- readRDS(file.path(outdir, "input.rds"))[1:1000, ]
rows <- list()
for (v in c("before", "after")) {
  e <- new.env(parent = asNamespace("RegR"))
  for (f in c("msr-riskRegression.R", "msr-fit-stats.R", "utils-parallel.R", "utils-resolve.R")) {
    old <- file.path(outdir, paste0("step5-before-", f))
    sys.source(if (v == "before" && file.exists(old)) old else file.path("/mnt/e/Rpackage/RegR/R", f), e)
  }
  recorder <- new.env(parent = baseenv())
  recorder$bytes <- numeric()
  recorder$apply <- e$oo_pblapply
  e$oo_pblapply <- function(X, FUN, ...) {
    bytes <<- c(bytes, length(serialize(FUN, NULL)))
    apply(X, FUN, ...)
  }
  environment(e$oo_pblapply) <- recorder
  set.seed(20261008)
  invisible(capture.output(z <- suppressMessages(e$get_score(
    d, list(full = c("Age", "Sex", "Race")), R = 4L, score_args = list(n_cores = 2L)))))
  rows[[v]] <- data.frame(version = v, bytes = recorder$bytes)
}
write.csv(do.call(rbind, rows), file.path(outdir, "step5-payload.csv"), row.names = FALSE)
print(do.call(rbind, rows))
