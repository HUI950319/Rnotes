# get_score() 进一步优化评估

评估日期：2026-10-07。对象：`RegR::get_score()`，当前源码提交 `1bda763`。本次仅做源码检查、阶段计时和剖析，没有修改、安装或提交包代码。

结论：优先消除重复的直接指标计算；主要性能空间在 `riskRegression::Score()` 的数据展开、排序、合并及 bootstrap 数据流。Windows 并行应针对函数环境分发和 worker 初始化成本，不能把问题简单归为创建进程慢。

本次沿用上一轮相同输入、种子、指标和单线程数值库设置。上一轮完整基准在提交 `0af26ef`，当前提交对本次所用 named-list 模型路径没有逻辑改变。输入来自包内 SEER 数据；10,000 行用于非 bootstrap 测试，前 1,000 行用于 R=100 测试。依赖环境记录见 `env-wsl.txt` / `env-windows.txt`，正式跨系统结果见 `report.md`。

阶段计时是带 trace / Rprof 的单次诊断，用于定位成本，不能替代正式三次重复的基准。混合指标路径还受 trace 后首次编译影响，应主要看调用次数。嵌套阶段时间存在重叠，不能相加；Rprof 的采样区间也不等同于端到端计时区间。

## 当前证据

| 诊断配置 | 总耗时 | 主要阶段 | 含义 |
|---|---:|---|---|
| WSL，Cox，n=10,000，R=0，1核 | 6.114 s | Score 5.366 s；直接指标补算 0.642 s；拟合 0.017 s；表格 0.030 s | Score 约占 88%，补算平均指标 CI 约占 10.5% |
| WSL，Cox，n=1,000，R=100，1核 | 10.557 s | Score 10.463 s；101次 Cox 拟合合计 0.356 s | 拟合只占约 3.4%，更换拟合器收益有限 |
| WSL，Fine–Gray，n=1,000，R=100，1核 | 10.933 s | Score 10.838 s；101次 FGR 拟合合计 2.023 s | 拟合占约 18.5%，但整理评分数据仍值得先处理 |
| WSL，Logistic，n=1,000，R=100，1核 | 0.971 s | Score 0.908 s；101次 glm 拟合合计 0.248 s | 拟合占比更高，但绝对成本很小 |
| Windows，Cox，n=1,000，R=100，4核 | 33.240 s | 两次 clusterCall 合计 17.820 s；两次 makeCluster 合计 0.470 s | 大量成本在发送函数/环境并使其在 worker 可用的阶段，不能只优化建群 |

WSL Cox R=0 的 Rprof 中，`[.data.table`、`forderv`、`factor` 的 self time 分别为 2.03、0.81、0.69 秒；排序、分组、合并、复制是明确热点。此证据支持优化数据表示及重复整理，不能推导出某个替代实现的实际加速倍数。

## 建议及实施顺序

### 1. 复用直接 AUC/BS 结果与公共预处理：先做，风险较低

同时请求 `AUC_score/BS_score` 和直接 `AUC/BS` 时，`fitted` 已计算直接指标及其 SE，随后 `pred_of()` 又为 Score 平均指标区间计算一遍。实测两个 Cox 模型调用 `.fit_pred_stats()` 4次、`.fit_pred_prepare()` 3次。

建议：相同分析样本、时间网格和 SE 要求下，直接复用已有 `value/se`；仅计算缺失的指标，跨模型共享 ordering / censoring 准备。该 fixture 有机会将直接评分调用从4次减至2次，准备从3次减至1次。没有混合请求时，也可让 `pred_of()` 的模型共用一次准备。

边界：不能仅按指标名称复用；要核对样本、网格、模型及 SE 条件，保留 AUC 不可定义时 BS 的独立回退，并保留 Score 与直接均值不一致时不展示该区间的逻辑。新抽样必须更新准备，不能跨 bootstrap 错用缓存。尚未实现，端到端收益待测。

源码：[首次直接评分](E:/Rpackage/RegR/R/msr-riskRegression.R:552)、[重复补算](E:/Rpackage/RegR/R/msr-riskRegression.R:612)、[已有共享准备](E:/Rpackage/RegR/R/msr-fit-stats.R:299)。

### 2. 改善轻量任务的自动并行阈值：成本较低、收益有边界

上一轮正式基准中，WSL Logistic，n=1,000、R=100，1核中位数1.031秒，4核1.150秒，增加约12%的耗时。当前自动选择按 n×R×模型数×时间点数量估算工作量，这一配置恰好达到 WSL 并行阈值，未体现不同模型的任务成本。

建议：先对 Logistic 这类轻量任务收紧自动并行条件，保持用户显式 n_cores 的优先权。后续只测受影响配置的1/2/4核及代表规模，不从单个测点推出通用阈值。Windows bootstrap 默认串行已有实测依据，应保留。

源码：[bootstrap 核数选择](E:/Rpackage/RegR/R/msr-riskRegression.R:640)、[通用阈值](E:/Rpackage/RegR/R/utils-parallel.R:217)。

### 3. 减少 Score 内的长表展开和重复排序：默认路径的主要空间，工作量较大

Score 在 Cox n=10,000 的诊断中占约88%；当前 AUC/Brier 内部多次展开、排序、factor 分组和合并。建议先评估共用风险矩阵、时间索引、删失权重，使用紧凑矩阵或按时间处理，避免反复复制个体×时间×模型长表。优先限定已验证的 Cox / 常系数 Fine–Gray 情形，保留原生回退。

默认 R=0 还为平均 AUC/BS 的 CI 多跑一次直接评分，诊断成本0.642秒。可以评估从同一次原生 Score 的 influence function 推导平均指标 SE，但 `keep="iid"` 会增加内存及数据整理成本，不能预先认定更快。

正确性关键：平均指标 CI 必须基于跨时间 influence function 的协方差；不能简单平均逐时间 SE。必须保持 ties、删失与竞争事件处理、边界时间点、点估计、SE/CI 和返回 Score 对象合同。大部分热点在依赖包内部，替代路径存在维护成本。没有实现，不给出预计倍数。

源码：[原生 Score 调用](E:/Rpackage/RegR/R/msr-riskRegression.R:595)、[直接指标及 influence function](E:/Rpackage/RegR/R/msr-fit-stats.R:362)。

### 4. 把 bootstrap 的拟合、预测、评分放在同一次任务内：潜力较大，统计验证要求高

当前 riskRegression bootcv 先产生每个重复的预测，再汇总为大的 DT.B，之后第二轮循环切片并评分。这带来长表内存、排序、拆分与跨进程传输成本。

建议探索：每个重复在一个 worker 内完成“拟合→预测→评分”，只返回每时间点紧凑指标、需要的拟合统计和失败状态；保留最后的原生汇总语义。此方向可同时减少内存和 Windows 传输量，但当前仅为依据剖析提出的候选。

必须保持原生训练/OOB划分、删失权重估计样本、模型间配对、失败重复的共同剔除、百分位 CI、有效重复数及最终 RNG 状态。直接 AUC/BS 训练样本指标与 Score 的 OOB 指标必须继续分开。不能只因为结果数值接近就替换 bootcv 算法。

源码入口：[bootcv 调用及结果汇总](E:/Rpackage/RegR/R/msr-riskRegression.R:665)。依赖当前实现已在项目外保存供核对；dump 含 trace 包装，不可作为可执行替代源码。

### 5. Windows 复用 worker 并缩小闭包：结合上一项实施

诊断的两次 clusterCall 共17.82秒，包含函数/环境序列化、传输、反序列化及可能的依赖命名空间加载，本次没有将这些子项进一步拆开。两次 makeCluster 仅0.47秒，单纯省掉建群不可能解释主要差距。

建议在单次 get_score 调用内复用同一 worker 池和已加载依赖，将任务函数与静态输入显式隔离；避免第一轮闭包携带不必要的 Score 环境。第二轮已有预测块分区优化，不应把它当作新功能。与 bootstrap 紧凑数据流一起评估，禁止用全局常驻集群引入会话副作用。

源码：[建群](E:/Rpackage/RegR/R/utils-parallel.R:150)、[发送函数及环境](E:/Rpackage/RegR/R/utils-parallel.R:166)、[Score foreach 适配](E:/Rpackage/RegR/R/msr-riskRegression.R:38)。实际收益仍需实施后测量。

## 不应优先投入的方向

- **仅关闭 ROC 辅助数据：** 三次交替对照 `plots="auto"` 中位数3.658秒（3.370–5.189），`plots="none"` 3.773秒（3.303–3.974），没有稳定提速；完整结果的 object.size 约从59.55 MiB降至56.64 MiB。这是返回对象逻辑大小，不能等同于峰值内存或实际常驻内存。指标、SE/CI及格式化摘要对照通过，ROC辅助字段按选项改变。
- **优化表格生成：** 诊断约0.026–0.050秒，远小于生存评分。
- **只替换 Cox 拟合器：** R100 的101次拟合只占约3.4%；收益上限很小。Fine–Gray 拟合占比更高，但 variance=FALSE 与常系数 CIF 向量化已存在。
- **关闭 bootstrap 每次 SE：** 原生 bootcv 每个重复已 se.fit=FALSE；这不是新的机会。
- **减少 R、时间点或置信区间：** 会改变计算要求，不能当作等价优化。

实施建议：先完成第1项，再做第2项的窄范围核数对照；若目标是显著缩短生存模型 R100 的耗时，优先联合评估第4、5项。若主要使用 R=0，则第3项更相关。每项均须先验证结果、SE/CI、有效重复、返回字段与 RNG 一致，再预热后交替重复至少3次报告中位数和范围。

## 证据文件

- `optimization-audit.R`：本次隔离子进程诊断脚本。
- `audit-*-stages.csv`：阶段调用数和嵌套墙钟时间。
- `audit-*-self.csv` / `audit-*-total.csv` / `audit-*.Rprof`：串行采样剖析。
- `audit-wsl-cox-10000-0-1-plots.csv`：plots选项三次交替计时。
- `summary.csv`：上一轮正式三次重复的端到端中位数与范围。
- `optimization-source-sha256.csv`：本次审阅源码与诊断脚本哈希。

图谱索引为2026-10-03，覆盖检查提示相关文件 metadata_changed；涉及结论均回到当前源码核对，没有重建索引。
