args <- commandArgs(TRUE)
outdir <- args[[1L]]
Sys.setenv(OPENBLAS_NUM_THREADS = 1, OMP_NUM_THREADS = 1)
suppressPackageStartupMessages(library(RegR))
RhpcBLASctl::blas_set_num_threads(1); RhpcBLASctl::omp_set_num_threads(1); data.table::setDTthreads(1)
d <- readRDS(file.path(outdir, "input.rds"))
Surv <- survival::Surv
f <- survival::coxph(Surv(time, DSS) ~ Age + Sex + Race, d, x = TRUE, y = TRUE)
run_grid <- function(times) riskRegression::Score(list(full = f), Surv(time, DSS) ~ 1, data = d,
  times = times, null.model = FALSE, contrasts = FALSE, plots = "ROC", progress.bar = NULL)
run <- function(size) {
  times <- seq(2, 200, 2)
  parts <- lapply(split(times, ceiling(seq_along(times) / size)), run_grid)
  out <- parts[[1L]]
  if (length(parts) == 1L) return(out)
  for (m in c("AUC", "Brier")) {
    key <- data.table::key(out[[m]]$score)
    out[[m]]$score <- data.table::rbindlist(lapply(parts, function(p) p[[m]]$score))
    if (length(key)) data.table::setkeyv(out[[m]]$score, key)
  }
  out$ROC$plotframe <- data.table::rbindlist(lapply(parts, function(p) p$ROC$plotframe))
  out$times <- unname(unlist(lapply(parts, `[[`, "times")))
  out
}
invisible(run(100)); invisible(run(10)); invisible(run(25))
reference <- NULL; rows <- list()
for (i in 1:3) for (size in if (i %% 2L) c(100, 10, 25) else c(25, 10, 100)) {
  invisible(gc())
  set.seed(20261008)
  tm <- system.time(z <- run(size))[["elapsed"]]
  z <- list(score = z, seed = .Random.seed)
  if (is.null(reference)) reference <- z else {
    eq <- all.equal(reference, z, tolerance = 1e-12)
    if (!isTRUE(eq)) {print(eq); stop("Chunk parity failed")}
  }
  rows[[length(rows) + 1L]] <- data.frame(rep = i, size, elapsed = tm)
  write.csv(do.call(rbind, rows), file.path(outdir, "step3-chunks-probe.csv"), row.names = FALSE)
  cat(size, i, tm, "FULL_OBJECT_PARITY_OK\n")
}
