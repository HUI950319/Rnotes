# =============================================================================
# utils-parallel.R -- RegR's shared parallel backend
#
#   oo_pblapply(X, FUN, ...)    serial lapply or pbapply::pblapply
#     |                           (Windows: PSOCK cluster, Unix: fork)
#     +-- oo_cores()             one worker policy: CPU quota, mc.cores budget,
#                                 nested-worker guard, adaptive default,
#                                 workload threshold, task cap
# =============================================================================

#' Parallel `lapply` with RegR's worker policy
#'
#' `oo_pblapply()` is the backend RegR's own functions use for strata, models
#' and bootstrap replicates. Below `min_n` tasks, or when fewer than two
#' workers are available, it runs [base::lapply()] in the current session.
#' Otherwise it runs [pbapply::pblapply()] on a PSOCK cluster (Windows) or
#' forked workers (Unix). `oo_cores()` returns the worker count it would use.
#'
#' Each worker draws on its own null device and discards its standard output,
#' so a `FUN` that plots or prints cannot corrupt the caller's device or
#' console; those plots and printed lines are only shown on the sequential
#' path. Calls made from inside an `oo_pblapply()` worker run serially, so
#' nested RegR functions never multiply the worker count. A failed task is
#' rethrown as an error naming the task.
#'
#' The adaptive worker count is eight when at least sixteen cores are
#' available and four otherwise. Available CPUs (including quotas when
#' parallelly is installed), `getOption("mc.cores")` and the number of tasks
#' cap both adaptive and explicit requests. When `n_cores` is `NULL` and
#' `work` is below 100,000 on Unix or 1,000,000 on Windows (where starting a
#' PSOCK cluster costs more), the call runs serially.
#'
#' With `seed = TRUE`, one seed per task is drawn from the caller's random
#' stream before any work starts, and each task calls [set.seed()] with its
#' own seed under the caller's [RNGkind()]. Results are then identical for any
#' worker count, and the caller's generator ends exactly one
#' `sample.int(.Machine$integer.max, length(X))` further on.
#'
#' @param X A vector or list to iterate over.
#' @param FUN Function applied to each element of `X`.
#' @param ... Further arguments passed to `FUN`.
#' @param n_cores `NULL` or a single non-negative number. `NULL` (default)
#'   picks the adaptive worker count. A number is an upper bound; values
#'   below 2 run serially.
#' @param min_n Single number. Fewer tasks than this run serially. Default
#'   `4L`.
#' @param work `NULL` or a single non-negative number estimating the total
#'   workload, such as `nrow(data) * R * n_models`. Only used when `n_cores`
#'   is `NULL`. Default `NULL` (no threshold).
#' @param seed Logical. `TRUE` gives each task its own seed so results do not
#'   depend on the worker count. Default `FALSE` leaves the random state to
#'   `FUN`.
#' @param n_tasks Single non-negative number of tasks; the worker count never
#'   exceeds it. Default `Inf`.
#'
#' @return `oo_pblapply()`: a list of `FUN(X[[i]], ...)`, named like
#'   [base::lapply()]. `oo_cores()`: a single integer, at least 1.
#'
#' @examples
#' oo_cores()
#' oo_cores(n_tasks = 10, work = 5e4)
#'
#' # Fewer than `min_n` tasks run in this session.
#' oo_pblapply(1:3, function(x) x^2)
#'
#' \donttest{
#' boot_mean <- function(b) mean(sample(mtcars$mpg, replace = TRUE))
#' set.seed(1)
#' two <- oo_pblapply(1:20, boot_mean, n_cores = 2L, seed = TRUE)
#' set.seed(1)
#' one <- oo_pblapply(1:20, boot_mean, n_cores = 1L, seed = TRUE)
#' identical(two, one)
#' }
#' @export
oo_pblapply <- function(X, FUN, ..., n_cores = NULL, min_n = 4L, work = NULL,
                        seed = FALSE) {
  FUN <- match.fun(FUN)
  if (!is.numeric(min_n) || length(min_n) != 1L || is.na(min_n)) {
    stop("`min_n` must be a single number.", call. = FALSE)
  }
  if (!isTRUE(seed) && !isFALSE(seed)) {
    stop("`seed` must be TRUE or FALSE.", call. = FALSE)
  }
  ncores <- oo_cores(length(X), n_cores = n_cores, work = work)

  if (seed && length(X)) {
    seeds <- sample.int(.Machine$integer.max, length(X))
    rng <- get(".Random.seed", envir = globalenv())
    on.exit(assign(".Random.seed", rng, envir = globalenv()), add = TRUE)
    kind <- RNGkind()
    xs <- as.list(X)
    X <- stats::setNames(lapply(seq_along(xs), function(i) {
      list(x = xs[[i]], seed = seeds[[i]])
    }), names(xs))
    rm(xs)
    fun <- FUN
    FUN <- function(task, ...) {
      set.seed(task$seed, kind = kind[1L], normal.kind = kind[2L],
               sample.kind = kind[3L])
      fun(task$x, ...)
    }
    # workers receive this wrapper; it must not carry X and the seeds along
    environment(FUN) <- list2env(list(fun = fun, kind = kind),
                                 parent = environment(oo_pblapply))
  }

  if (length(X) < min_n || ncores < 2L) return(lapply(X, FUN, ...))

  # Workers must not draw on the device they inherited from the parent.
  # `.get.obj()` prints a diagnostic curve per fit, so under a Unix fork every
  # worker writes into the one device open when the fork happened; two of them
  # interleaving in a file-backed (or RStudio) device corrupts its stream
  # ("internal read error in PDF_endpage"), and `.get.obj()`'s tryCatch reads
  # that as a failed fit -- walking its whole direct -> iptw -> psm -> unadj
  # fallback chain, so a stratum either errors out or silently changes method.
  # Give each worker its own null device instead; the sequential branch above
  # keeps printing to the caller's device as before.
  # The same reasoning applies to the console stream. `.cat_line()` banners and
  # `.get.obj()`'s per-fit diagnostics are written by every worker into the one
  # stdout inherited from the fork; two of them interleaving can cut a line in
  # the middle of a multi-byte character, and whatever captures that output
  # then aborts on the malformed bytes -- knitr reports "embedded nul in
  # string" or "input string 1 is invalid". It is intermittent because it
  # depends on worker timing, and only shows up once `length(X) >= min_n`
  # sends the work down this branch. Discard worker stdout; the parent keeps
  # printing its own banners and the sequential branch above is untouched.
  # Messages, warnings and errors travel on stderr and are still surfaced by
  # the try-error check below.
  quiet_FUN <- function(...) {
    worker_options <- options(.RegR.parallel_worker = TRUE)
    on.exit(options(worker_options), add = TRUE)
    grDevices::pdf(NULL)
    on.exit(grDevices::dev.off(), add = TRUE)
    null_con <- file(nullfile(), open = "wt")
    sink(null_con)
    on.exit({ sink(); close(null_con) }, add = TRUE, after = FALSE)
    # A PSOCK cluster raises a worker error where mclapply returns a
    # try-error; return one here too, so both reach the rethrow below.
    tryCatch(FUN(...), error = function(e) {
      structure(conditionMessage(e), class = "try-error", condition = e)
    })
  }
  # PSOCK serializes the closure. Its frame must not retain X or the caller's
  # intermediate tables in addition to the individual tasks sent to workers.
  environment(quiet_FUN) <- list2env(list(FUN = FUN),
                                    parent = environment(oo_pblapply))

  # The internal option .RegR.psock runs the PSOCK branch on Unix (tests).
  if (.Platform$OS.type == "windows" || isTRUE(getOption(".RegR.psock"))) {
    cl <- parallel::makeCluster(ncores)
    on.exit(parallel::stopCluster(cl), add = TRUE)
    # With a progress bar (RStudio), pblapply() calls parLapply() once per
    # chunk of length(cl) tasks, serializing FUN with all its closure holds,
    # and `...`, again for every chunk: 200 tasks over a 20 MB closure took
    # 19 s on 4 workers. Place both on each worker once; pblapply() then
    # sends only a stub and the tasks.
    place <- function(fun, args) {
      assign(".RegR_oo_task", list(fun = fun, args = args), envir = globalenv())
      NULL
    }
    stub <- function(x) {
      task <- get(".RegR_oo_task", envir = globalenv())
      do.call(task$fun, c(list(x), task$args))
    }
    environment(place) <- environment(stub) <- baseenv()
    parallel::clusterCall(cl, place, quiet_FUN, list(...))
    res <- pbapply::pblapply(X, stub, cl = cl)
  } else {
    res <- pbapply::pblapply(X, quiet_FUN, ..., cl = ncores)
  }

  # Surface worker errors: mclapply (Unix fork) silently returns
  # `try-error` objects for failed jobs, which downstream bind_rows then
  # drops -- producing confusing "column doesn't exist" errors instead of
  # the real cause. Detect and rethrow with the worker's message.
  bad <- vapply(res, function(x) inherits(x, "try-error"), logical(1))
  if (any(bad)) {
    idx     <- which(bad)
    nms     <- names(X) %||% as.character(seq_along(X))
    msgs    <- vapply(res[idx], function(e) {
      m <- attr(e, "condition")
      if (!is.null(m)) conditionMessage(m) else as.character(e)
    }, character(1))
    stop(sprintf(
      "oo_pblapply: %d/%d worker job(s) errored. First failure (%s): %s",
      length(idx), length(res), nms[idx[1]], msgs[1]),
      call. = FALSE)
  }
  res
}

#' @rdname oo_pblapply
#' @export
oo_cores <- function(n_tasks = Inf, n_cores = NULL, work = NULL) {
  bad_number <- function(x) {
    !is.numeric(x) || length(x) != 1L || is.na(x) || x < 0
  }
  if (bad_number(n_tasks)) {
    stop("`n_tasks` must be a single non-negative number.", call. = FALSE)
  }
  if (!is.null(n_cores) && bad_number(n_cores)) {
    stop("`n_cores` must be NULL or a single non-negative number.", call. = FALSE)
  }
  if (!is.null(work) && bad_number(work)) {
    stop("`work` must be NULL or a single non-negative number.", call. = FALSE)
  }

  if (isTRUE(getOption(".RegR.parallel_worker"))) return(1L)
  available <- if (requireNamespace("parallelly", quietly = TRUE))
    parallelly::availableCores() else parallel::detectCores(logical = TRUE)
  budget <- getOption("mc.cores", available)
  if (length(available) != 1L || !is.finite(available) || available < 1 ||
      !is.numeric(budget) || length(budget) != 1L || !is.finite(budget) ||
      budget < 1 || budget != floor(budget)) return(1L)
  budget <- min(available, budget)

  if (is.null(n_cores)) {
    threshold <- if (.Platform$OS.type == "windows") 1e6 else 1e5
    n_cores <- if (!is.null(work) && work < threshold) 1L
               else if (budget >= 16L) 8L
               else 4L
  }
  max(1L, as.integer(min(n_cores, budget, n_tasks)))
}
