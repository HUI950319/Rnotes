args <- commandArgs(TRUE)
outdir <- args[[1L]]
root <- "/mnt/e/Rpackage/RegR"
options(mc.cores = 2L)
suppressPackageStartupMessages(pkgload::load_all(root, quiet = TRUE))
data.table::setDTthreads(1)
ns <- asNamespace("RegR")
old <- new.env(parent = ns)
sys.source(file.path(outdir, "step1-before-msr-riskRegression.R"), old)
sys.source(file.path(outdir, "step5-before-utils-parallel.R"), old)
for (name in ls(old, all.names = TRUE)) {
  value <- old[[name]]
  if (!is.function(value)) next
  environment(value) <- ns
  locked <- bindingIsLocked(name, ns)
  if (locked) unlockBinding(name, ns)
  assign(name, value, ns)
  if (locked) lockBinding(name, ns)
  attached <- as.environment("package:RegR")
  if (exists(name, attached, inherits = FALSE)) {
    locked <- bindingIsLocked(name, attached)
    if (locked) unlockBinding(name, attached)
    assign(name, value, attached)
    if (locked) lockBinding(name, attached)
  }
}
setwd(file.path(root, "tests/testthat"))
r <- testthat::test_dir(".", filter = "^(get-eff-helpers|get-rpa-mp1|get-score-stage)$",
  load_package = "none", package = "RegR", reporter = "summary", stop_on_failure = FALSE)
tab <- as.data.frame(r)
tab <- tab[intersect(c("file", "test", "failed", "error", "warning", "passed", "skipped"), names(tab))]
write.csv(tab, file.path(outdir, "pre-optimization-baseline-failures.csv"), row.names = FALSE)
print(tab[tab$failed > 0 | tab$error, ])
