args <- commandArgs(TRUE)
outdir <- args[[1L]]
Sys.setenv(OPENBLAS_NUM_THREADS = 1, OMP_NUM_THREADS = 1)
suppressPackageStartupMessages(library(RegR))
RhpcBLASctl::blas_set_num_threads(1); RhpcBLASctl::omp_set_num_threads(1); data.table::setDTthreads(1)
d <- readRDS(file.path(outdir, "input.rds"))
Surv <- survival::Surv
f <- survival::coxph(survival::Surv(time, DSS) ~ Age + Sex + Race, d, x = TRUE, y = TRUE)
run <- function(keep) {
  z <- riskRegression::Score(list(full = f), Surv(time, DSS) ~ 1, data = d,
                             times = seq(2, 200, 2), null.model = FALSE, contrasts = FALSE,
                             plots = "ROC", keep = keep, progress.bar = NULL)
  if (is.null(keep)) {
    avg <- RegR:::.fit_pred_stats(f, d, "cox", "DSS", seq(2, 200, 2), se = TRUE)
  } else {
    avg <- list(value = numeric(), se = numeric())
    for (m in c("AUC", "Brier")) {
      tab <- z[[m]]$iid.decomp
      sc <- z[[m]]$score
      good <- sc$times[is.finite(sc[[m]])]
      tab <- tab[tab$times %in% good, ]
      stopifnot(identical(tab$riskRegression_ID, rep(seq_len(nrow(d)), length(good))))
      x <- matrix(tab[[paste0("IF.", m)]], nrow = nrow(d))
      label <- if (m == "Brier") "BS" else m
      avg$value[label] <- mean(sc[[m]][is.finite(sc[[m]])])
      avg$se[label] <- sd(rowMeans(x)) / sqrt(nrow(d))
      z[[m]]$iid.decomp <- NULL
    }
  }
  list(score = z, avg = avg)
}
invisible(run(NULL)); invisible(run("iid"))
rows <- list(); reference <- NULL
for (i in 1:3) for (v in if(i %% 2L) c("direct", "iid") else c("iid", "direct")) {
  invisible(gc())
  tm <- system.time(z <- run(if(v == "iid") "iid" else NULL))[["elapsed"]]
  if (is.null(reference)) reference <- z else print(all.equal(reference, z, tolerance = 1e-10))
  rows[[length(rows) + 1L]] <- data.frame(rep = i, version = v, elapsed = tm)
  write.csv(do.call(rbind, rows), file.path(outdir, "step3-iid-probe.csv"), row.names = FALSE)
  cat(v, i, tm, "\n")
}
