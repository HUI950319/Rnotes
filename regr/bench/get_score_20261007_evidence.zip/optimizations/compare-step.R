args <- commandArgs(TRUE)
outdir <- args[[1L]]
step <- args[[2L]]
mode <- args[[3L]]
n <- as.integer(args[[4L]])
reps <- as.integer(args[[5L]])
cores <- if (args[[6L]] == "auto") NULL else as.integer(args[[6L]])
mixed <- args[[7L]] == "mixed"
fullwarm <- length(args) > 7L && args[[8L]] == "full"
os <- if (.Platform$OS.type == "windows") "windows" else "wsl"
root <- if (os == "windows") "E:/Rpackage/RegR" else "/mnt/e/Rpackage/RegR"
if (os == "windows") invisible(Sys.setlocale("LC_CTYPE", "English_United States.utf8"))
Sys.setenv(OPENBLAS_NUM_THREADS = 1, OMP_NUM_THREADS = 1, MKL_NUM_THREADS = 1,
           R_DATATABLE_NUM_THREADS = 1)
suppressPackageStartupMessages(library(RegR))
options(mc.cores = 4L)
RhpcBLASctl::blas_set_num_threads(1)
RhpcBLASctl::omp_set_num_threads(1)
data.table::setDTthreads(1)
pbapply::pboptions(type = "none")
versions <- lapply(c("before", "after"), function(v) {
  e <- new.env(parent = asNamespace("RegR"))
  for (f in c("msr-riskRegression.R", "msr-fit-stats.R", "utils-parallel.R", "utils-resolve.R")) {
    old <- file.path(outdir, paste0(step, "-before-", f))
    sys.source(if (v == "before" && file.exists(old)) old else file.path(root, "R", f), e)
  }
  e
})
names(versions) <- c("before", "after")
d <- readRDS(file.path(outdir, "input.rds"))[seq_len(n), ]
models <- if (mixed) list(base = c("Age", "Sex"), full = c("Age", "Sex", "Race")) else
  list(full = c("Age", "Sex", "Race"))
metrics <- c("AUC_score", "BS_score", if (mixed) c("AUC", "BS", "AIC", "BIC", "PVE"))
run <- function(v, x, r, nc) {
  con <- file(nullfile(), "wt")
  sink(con)
  on.exit({sink(); close(con)})
  set.seed(20261008)
  warnings <- character()
  z <- withCallingHandlers(suppressMessages(versions[[v]]$get_score(
    x, vars = !!models, surv = switch(mode, logistic = "DSS", cox = TRUE, finegray = FALSE),
    R = r, metrics = metrics, score_args = list(plots = "auto", n_cores = nc))),
    warning = function(w) {warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")})
  list(native = if (step == "step3") z$obj,
       scores = lapply(z[c("AUC", "Brier")], function(s) as.data.frame(s$score)),
       summary = z$AUC.BS.AIC, stats = z$fit.stats$stats, boot = z$fit.stats$boot,
       info = z$fit.stats$info, rng = .Random.seed, fields = names(z),
       class = class(z), warnings = warnings)
}
for (v in names(versions)) invisible(run(v, if (fullwarm) d else d[seq_len(min(n, 300L)), ],
                                        if (fullwarm) reps else if (reps > 1L) 4L else 0L, cores))
rows <- list()
reference <- NULL
key <- paste(step, os, mode, n, reps, args[[6L]], args[[7L]], sep = "-")
if (fullwarm) key <- paste0(key, "-fullwarm")
saveRDS(list(source = tools::md5sum(file.path(root, "R", c("msr-riskRegression.R", "msr-fit-stats.R", "utils-parallel.R"))),
             input = tools::md5sum(file.path(outdir, "input.rds")), session = sessionInfo()),
        file.path(outdir, paste0(key, "-metadata.rds")))
for (i in 1:3) for (v in if (i %% 2L) names(versions) else rev(names(versions))) {
  invisible(gc())
  setTimeLimit(elapsed = 180, transient = TRUE)
  tm <- system.time(z <- run(v, d, reps, cores))[["elapsed"]]
  setTimeLimit(cpu = Inf, elapsed = Inf, transient = FALSE)
  if (is.null(reference)) reference <- z else stopifnot(isTRUE(all.equal(z, reference, tolerance = 1e-10)))
  rows[[length(rows) + 1L]] <- data.frame(step, os, mode, n, R = reps,
                                        cores = args[[6L]], rep = i, version = v, elapsed = tm)
  write.csv(do.call(rbind, rows), file.path(outdir, paste0(key, "-timings.csv")), row.names = FALSE)
  cat(key, v, i, tm, "PARITY_OK\n")
}
saveRDS(reference, file.path(outdir, paste0(key, "-values.rds")))
print(aggregate(elapsed ~ version, do.call(rbind, rows), function(x) c(median = median(x), min = min(x), max = max(x))))
