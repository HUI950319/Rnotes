# =============================================================================
# msr-riskRegression.R -- riskRegression metric module
# =============================================================================
#
# Alternative metric backend to the mlr3 path in msr-get.R.
#
# Originally ported from the FeatureAnalysis/R/get.msr.R sub-block:
#   .get.score          -> get_score          [export]
#   .get.score.summary  -> get_score_summary  [export]
#   .plt.score          -> plt_score          [export]
#
# Architecture (1 layer of file-level peer functions):
#   get_score(data, vars, surv, timepoint, times, R, metrics, score_args)
#     +-- R = c(0, n): recursive R = n and R = 0 calls -> starred table + ft
#     +-- .score_ft(): AUC.BS.AIC -> get_inter-style flextable (1 or 2 panels)
#     +-- one cox/FGR/glm fit per model and bootstrap training sample
#     +-- riskRegression::Score(...) on fit list (AUC_score / BS_score)
#     +-- shared fit metrics (AUC/BS/AIC/BIC/PVE, msr-fit-stats.R),
#         summary and plot results
#     +-- AUC_mlr / BS_mlr: get_msr's mlr3 engines (msr-get.R), own fits
#   get_score_summary(res.Score)        # 2 branches: sur ('times' col) / log
#   plt_score(res.Score)                # 2 branches: sur 2-curve / log ROC
#     +-- nested .fmt.plot (axis + CI clip helper, sur path only)
#
# Source faithfulness:
#   - summary/plot legacy paths retained; get_score adds shared-fit metrics
#   - library() inside functions removed; namespace prefixes used
#   - `print(formula)` debug call replaced by RegR's `.cat_formula`
#   - .fmt_ci(digits=N) replaced by direct sprintf("%.Nf (%.Nf, %.Nf)") inline
#   - lancet_palette -> UtilsR::pal_lancet
#   - my_theme -> UtilsR::theme_my
#   - .fmt_plot / .fmt_strip / .fmt_axis / .fmt_legend -> UtilsR equivalents
# =============================================================================

# Score's two foreach loops retain their native evaluation and aggregation.
# Return captured likelihood rows explicitly: child-process assignments cannot
# update the caller's bootstrap store. The serial fallback follows the same path.
.score_foreach_backend <- function(obj, expr, envir, data) {
  # Force caller-dependent promises before PSOCK serializes the worker.
  force(expr)
  force(envir)
  it <- iterators::iter(obj)
  accumulator <- foreach::makeAccum(it)
  tasks <- as.list(it)
  seed <- get(".Random.seed", .GlobalEnv, inherits = FALSE)
  metric_loop <- length(expr) >= 2L && identical(expr[[2L]], quote(DT.b <- DT.B[b == j]))
  performance_call <- quote(computePerformance(
    DT = DT.b, N = N.b, NT = NT, NF = NF, models = list(levels = mlevs, labels = mlabels),
    response.type = response.type, times = times, jack = jack, cens.type = cens.type,
    cause = cause, states = states, alpha = alpha, se.fit = FALSE, conservative = TRUE,
    cens.model = cens.model, keep.residuals = FALSE, keep.vcov = FALSE, keep.iid = FALSE,
    dolist = dolist, probs = probs, metrics = metrics, plots = plots, summary = summary,
    ibs = ibs, ipa = ipa, ROC = ROC, MC = Weights$IC, IC.data = Weights$IC.data, breaks = breaks))
  cached <- metric_loop && is.environment(data$cache) &&
    exists("score", data$cache, inherits = FALSE) &&
    identical(expr[[length(expr)]], performance_call)
  performance_args <- NULL
  # Keep Score's native prediction validation and final aggregation, but score
  # each bootcv replicate in the worker that already holds its predictions.
  # Unknown upstream loop shapes retain the ordinary two-pass backend.
  if (!metric_loop && is.environment(data$cache) &&
      identical(parent.env(envir), asNamespace("riskRegression")) &&
      identical(expr[[length(expr)]], quote(DT.b[])) &&
      all(c("getPerformanceData", "trainseeds", "traindata") %in% all.names(expr))) {
    performance_args <- tryCatch({
      if (get("split.method", envir)$internal.name == "BootCv" &&
          !length(get("plots", envir))) {
        args <- as.list(performance_call)[-c(1L, 2L, 3L)]
        args["breaks"] <- list(NULL)
        eval(as.call(c(list(quote(list)), args)), envir)
      }
    }, error = function(e) NULL)
  }
  worker <- function(i) {
    if (!is.null(get_store)) {
      previous <- get_store()
      on.exit(set_store(previous), add = TRUE)
      set_store(vector("list", n_models))
    }
    assign(".Random.seed", seed, .GlobalEnv)
    for (pkg in packages) library(pkg, character.only = TRUE)
    frame <- list2env(tasks[[i]], parent = envir)
    value <- tryCatch(eval(expr, frame), error = function(e) e)
    performance <- if (!is.null(performance_args) && !inherits(value, "error"))
      tryCatch({
        predictions <- data.table::copy(value)
        by <- c("model", if ("times" %in% names(predictions)) "times", "riskRegression_ID")
        data.table::setkeyv(predictions, by)
        do.call(get("computePerformance", asNamespace("riskRegression")),
                c(list(DT = predictions, N = length(unique(predictions[["riskRegression_ID"]]))),
                  performance_args))
      }, error = function(e) e)
    list(value = value, boot = if (is.null(get_store)) vector("list", n_models) else get_store(),
         performance = performance,
         seed = get(".Random.seed", .GlobalEnv, inherits = FALSE))
  }
  # A Score-only task needs neither get_score's frame nor its fit-metric
  # callbacks. Retain those callbacks only when a refit actually writes rows.
  # The verified training expression reads its inputs from these bindings;
  # the ordinary fallback keeps the original evaluation frame.
  worker_frame <- if (!is.null(performance_args)) list2env(
    mget(intersect(all.vars(expr, functions = TRUE), ls(envir)), envir, inherits = FALSE),
    parent = asNamespace("riskRegression")) else envir
  if (!is.null(performance_args)) {
    index <- worker_frame$split.method$index
    bindings <- all.vars(body(index), functions = TRUE)
    # The native index closes over an unused seed promise pointing back to
    # Score's frame. Keep the same function, seeds and RNG calls, but only its
    # referenced bindings. Dynamic lookup in a future version uses the fallback.
    if (!any(c("get", "mget", "eval", "evalq", "environment", "parent.frame") %in% bindings)) {
      source <- environment(index)
      environment(index) <- list2env(mget(intersect(bindings, ls(source)), source,
                                         inherits = FALSE), parent = parent.env(source))
      worker_frame$split.method$index <- index
    }
  }
  capture <- !identical(data$capture, FALSE)
  environment(worker) <- list2env(list(
    seed = seed, packages = obj$packages, tasks = tasks, expr = expr,
    envir = worker_frame, performance_args = performance_args,
    n_models = length(data$get_store()),
    get_store = if (capture) data$get_store, set_store = if (capture) data$set_store),
    parent = baseenv())
  inputs <- seq_along(tasks)
  # Score's bootcv metric loop only needs one replicate's predictions. Keep
  # its native expression, but send each worker that block and the referenced
  # constants rather than the full Score frame and all replicates' DT.B.
  if (!cached && isTRUE(data$partition) && metric_loop &&
      identical(parent.env(envir), asNamespace("riskRegression")) &&
      exists("DT.B", envir, inherits = FALSE)) {
    table <- get("DT.B", envir, inherits = FALSE)
    blocks <- split(table, by = "b", keep.by = TRUE, sorted = TRUE)
    inputs <- lapply(tasks, function(task) {
      list(vars = task, predictions = blocks[[as.character(task$j)]])
    })
    constants <- list2env(mget(setdiff(intersect(all.vars(expr, functions = TRUE),
                                                ls(envir)), "DT.B"),
                               envir, inherits = FALSE),
                          parent = asNamespace("riskRegression"))
    worker <- local(function(task) {
      assign(".Random.seed", seed, .GlobalEnv)
      for (pkg in packages) library(pkg, character.only = TRUE)
      frame <- list2env(task$vars, parent = constants)
      frame$DT.B <- task$predictions
      value <- tryCatch(eval(expr, frame), error = function(e) e)
      list(value = value, boot = vector("list", n_models),
           seed = get(".Random.seed", .GlobalEnv, inherits = FALSE))
    }, envir = list2env(list(seed = seed, packages = obj$packages, expr = expr,
                             constants = constants, n_models = length(data$get_store())),
                        parent = baseenv()))
  }
  results <- if (cached) lapply(data$cache$score, function(value) {
    list(value = value, boot = vector("list", length(data$get_store())), seed = seed)
  }) else oo_pblapply(inputs, worker, min_n = 2L, n_cores = data$cores)
  if (!is.null(performance_args)) data$cache$score <- lapply(results, `[[`, "performance")
  store <- data$get_store()
  for (i in seq_along(results)) {
    for (j in seq_along(store)) {
      rows <- results[[i]]$boot[[j]]
      if (length(rows)) {
        rows <- lapply(rows, function(row) {
          row$replicate <- tasks[[i]]$b
          row
        })
        store[[j]] <- c(store[[j]], rows)
      }
    }
  }
  data$set_store(store)
  if (length(results)) assign(".Random.seed", results[[length(results)]]$seed, .GlobalEnv)
  accumulator(lapply(results, `[[`, "value"), seq_along(results))
  error <- foreach::getErrorValue(it)
  if (identical(obj$errorHandling, "stop") && !is.null(error)) {
    index <- foreach::getErrorIndex(it)
    stop(sprintf("task %d failed - %s", index, conditionMessage(error)), call. = FALSE)
  }
  foreach::getResult(it)
}

# Without resampling, score each model in its own Score() call through
# oo_pblapply() and stack the results. With contrasts and the null model
# disabled, models do not interact, so the stacked object equals one joint call
# (Logistic DeLong SEs within 1e-15); separate calls are also faster than one
# joint call for several models. The worker gets a minimal environment, so
# PSOCK workers receive one fit and these inputs rather than a caller frame.
.score_by_model <- function(fits, data, formula, metrics, plots, times,
                            n_cores, work) {
  score_one <- local(function(obj) riskRegression::Score(
    object = obj, formula = formula, data = data, metrics = metrics,
    plots = plots, null.model = FALSE, contrasts = FALSE, times = times,
    split.method = "none", cl = 10L, progress.bar = NULL),
    envir = list2env(list(formula = formula, data = data, metrics = metrics,
                          plots = plots, times = times), parent = asNamespace("RegR")))
  parts <- oo_pblapply(lapply(names(fits), function(m) fits[m]), score_one,
                       n_cores = n_cores, min_n = 2L, work = work)
  out <- parts[[1L]]
  if (length(parts) == 1L) return(out)
  stack <- function(get) {
    x <- data.table::rbindlist(lapply(parts, get))
    key <- data.table::key(get(out))
    if (length(key)) data.table::setkeyv(x, key)
    x
  }
  for (m in intersect(c("AUC", "Brier"), names(out))) {
    out[[m]]$score <- stack(function(p) p[[m]]$score)
  }
  if (!is.null(out$ROC$plotframe)) out$ROC$plotframe <- stack(function(p) p$ROC$plotframe)
  out$models <- stats::setNames(seq_along(parts), names(fits))
  out
}

#' Internal constant-effect Fine-Gray scoring predictor
#' @exportS3Method riskRegression::predictRisk
#' @noRd
predictRisk.regr_score_fgr <- function(object, newdata, times, ...) {
  native <- function() {
    class(object) <- setdiff(class(object), "regr_score_fgr")
    riskRegression::predictRisk(object, newdata = newdata, times = times, ...)
  }
  cr <- object$crrFit
  if (length(cr$tfs) > 1L || is.null(cr$bfitj) || NROW(newdata) == 0L) return(native())
  # Keep FGR's factor/special design. Only the subject-by-event loop changes:
  # sum_j exp(lp) * baseline_jump_j = exp(lp) * cumulative_baseline.
  rhs <- stats::as.formula(stats::delete.response(object$terms))
  newdata$dummy.time <- 1
  newdata$dummy.event <- 1
  form <- stats::update.formula(rhs, "Hist(dummy.time,dummy.event)~.")
  eh <- prodlim::EventHistory.frame(form, data = newdata,
    specials = c("cov1", "cov2"), stripSpecials = c("cov1", "cov2"),
    stripArguments = list(cov1 = NULL, cov2 = list(tf = NULL)),
    stripUnspecials = "cov1", specialsDesign = TRUE)
  covariates <- cbind(eh$cov1, eh$design)
  if (!is.null(eh$cov2) || NROW(covariates) != NROW(newdata) ||
      NCOL(covariates) != length(cr$coef)) return(native())
  lp <- as.numeric(covariates %*% cr$coef)
  index <- prodlim::sindex(jump.times = cr$uftime, eval.times = times)
  h <- c(0, cumsum(cr$bfitj))[index + 1L]
  out <- matrix(0, nrow = NROW(newdata), ncol = length(times))
  at_event <- index > 0L
  out[, at_event] <- 1 - exp(-outer(exp(lp), h[at_event]))
  out
}

#' Select prediction and likelihood metrics from shared model fits
#'
#' Fits each element of `vars` once. `AUC_score` and `BS_score` come from
#' [riskRegression::Score()]; `AUC`, `BS`, `AIC`, `BIC` and `PVE` are computed
#' from the same fits as in [get_fit_stats()]. `AUC_mlr` and `BS_mlr` are the
#' mlr3 metrics of [get_msr()]. A formatted summary table and plots are also
#' included.
#'
#' Three model modes via `surv`:
#' \describe{
#'   \item{`TRUE`}{Cox via [survival::coxph()] (`Surv(time, DSS)`).}
#'   \item{`FALSE`}{Fine-Gray competing risk via [riskRegression::FGR()]
#'         (`Hist(time, event)`).}
#'   \item{character (e.g. `"DSS"`)}{Logistic via [stats::glm()]
#'         (`outcome ~ vars`).}
#' }
#' Fine-Gray fits use `variance = FALSE`, including bootstrap refits, to
#' skip coefficient variance estimation. Score still computes AUC and
#' Brier standard errors and confidence intervals.
#' Constant-effect Fine-Gray predictions use a vectorized CIF calculation
#' with the native FGR factor/special design and baseline jumps. Time-varying
#' effects use the native predictor. Fitting and likelihood criteria are unchanged.
#'
#' @param data data.frame with `time` / `DSS` / `event` columns + predictors.
#' @param vars Character vector or tidyselect selection for separate models,
#'   or a list of character vectors for joint models. List names label the
#'   models; unnamed elements use predictor names joined by `_`. Names of a
#'   character vector, such as `c("Sex", "Age, years" = "Age")`, likewise label
#'   its separate models, also inside `all_of()` / `any_of()`.
#' @param surv `TRUE` for Cox, `FALSE` for Fine-Gray, or one binary outcome
#'   column name for Logistic regression.
#' @param timepoint Numeric vector of times for time-dependent metrics.
#'   Default `seq(2, 200, 2)`.
#' @param times `NULL` (default) or distinct positive times, such as
#'   `c("5-year" = 60, "10-year" = 120)`, adding one `AUC_score` / `BS_score`
#'   column per time after the selected metric's column
#'   (`AUC_score_60`, ...). Cox and Fine-Gray only; requires `"AUC_score"` or
#'   `"BS_score"` in `metrics`. Score is evaluated at the union of `timepoint`
#'   and `times` (curves include both); time averages use `timepoint` only.
#'   Names label the `ft` headers ("5-year AUC"); unnamed times
#'   show as "AUC (t = 60)". A time after the follow-up, which Score skips,
#'   gives `NA`.
#' @param R Nonnegative integer bootstrap repetitions. `NULL`, 0 or 1 means
#'   no resampling. At least 2 enables out-of-bag `"bootcv"` validation with
#'   `B = R` for `AUC_score`/`BS_score`, and 95% percentile intervals over the
#'   bootstrap samples themselves for `AUC`, `BS` and the likelihood metrics
#'   (see section 'Evaluation data of AUC and Brier metrics'). Use substantially more
#'   repetitions for reported intervals. `c(0, n)` (or `c(1, n)`) with
#'   `n >= 2` runs the `R = n` call and a full-cohort call and returns their
#'   combined two-panel table (see Value).
#' @param metrics Nonempty character vector selecting any of `"AUC_score"`,
#'   `"BS_score"`, `"AUC_mlr"`, `"BS_mlr"`, `"AUC"`, `"BS"`, `"AIC"`, `"BIC"`,
#'   `"PVE"`, without duplicates. Default `c("AUC_score", "BS_score")`.
#'   `"AUC_score"` and `"BS_score"` are Score's `AUC` and `Brier`, out-of-bag
#'   with `R >= 2`, with curves and the Score object; `"AUC_mlr"` and
#'   `"BS_mlr"` are the [get_msr()] discrimination and Brier columns (see
#'   Details); `"AUC"` and `"BS"` are the apparent (in-sample) metrics of
#'   [get_fit_stats()], computed directly from each fit at every `R`. See
#'   section 'Evaluation data of AUC and Brier metrics'.
#'   The selected order is retained in the summary; unselected Score metrics
#'   are not computed.
#' @param score_args Named list controlling optional Score output and bootstrap:
#'   \describe{
#'     \item{plots}{One character string, `"auto"` (default) or `"none"`.
#'       `"auto"` retains the original ROC data for AUC without resampling.
#'       With resampling neither setting computes auxiliary data: riskRegression
#'       fails on its boxplot data in some replicates, and Score then drops
#'       those replicates from every metric. `"none"` skips these
#'       auxiliary data for every model mode, without changing selected
#'       metrics, standard errors or intervals. Survival AUC/BS curves remain
#'       available; Logistic `plt.ROC` is `NULL` without ROC data.
#'       Ignored when neither `"AUC_score"` nor `"BS_score"` is selected.}
#'     \item{n_cores}{`NULL` (default) or one positive integer. `NULL` lets
#'       [oo_pblapply()] choose workers from the workload: serial below its
#'       threshold, otherwise several workers. An integer is an upper bound
#'       and `1L` is serial. Without resampling, `AUC_score`/`BS_score` use
#'       one Score call per model, run in parallel across models once
#'       `nrow(data)` x models x time points reaches about 1e6 on Unix or 1e7
#'       on Windows, where PSOCK start-up costs more; with
#'       `R >= 2` (adaptive from `R >= 4` on Unix), Score's bootstrap
#'       replicates run in parallel and selected AUC/BS/AIC/BIC/PVE share
#'       their training fits. On Windows `NULL` keeps that bootstrap serial,
#'       which measured faster than every parallel split of it; an integer
#'       still runs it on that many PSOCK workers. Capped by the number of models or `R`, available cores and the
#'       `mc.cores` budget; nested RegR workers stay serial. Uses fork on Unix
#'       and PSOCK on Windows. Results do not depend on the worker count.
#'       The bound also applies when only fit metrics are selected; `NULL`
#'       retains the adaptive worker policy of [get_fit_stats()].}
#'   }
#'
#' @section Evaluation data of AUC and Brier metrics:
#' The AUC and Brier metrics differ in which subjects each fitted model
#' predicts, and therefore in what their estimates and intervals mean:
#' \describe{
#'   \item{`AUC_score`, `BS_score` with `R >= 2`}{Out-of-bag validation
#'     (Score `split.method = "bootcv"`). Each replicate refits the model on a
#'     bootstrap sample and predicts only the subjects not drawn into it,
#'     about 36.8% of the sample. The estimate is the mean over replicates and
#'     the range their 2.5% and 97.5% quantiles: performance on new data. Each
#'     model trains on about 63.2% distinct subjects, so the estimate tends to
#'     be slightly pessimistic; no .632 or .632+ correction is applied.}
#'   \item{`AUC`, `BS`}{Apparent (in-sample) performance at every `R`. The
#'     estimate predicts the analysis sample from the model fitted on it. With
#'     `R >= 2` each replicate predicts its own bootstrap sample from the model
#'     fitted on that sample, so the percentile interval describes the
#'     sampling variability of apparent performance. Neither is
#'     optimism-corrected.}
#'   \item{`AUC_score`, `BS_score` with `R` of 0 or 1}{Apparent performance
#'     on the analysis sample, as `AUC` / `BS`, with Wald intervals.}
#'   \item{`AUC_mlr`, `BS_mlr`}{Out-of-bag on mlr3 bootstrap replicates with
#'     `R >= 2`; otherwise apparent on the analysis sample.}
#' }
#' With `R >= 2`, `AUC_score` is therefore usually lower than `AUC`, and
#' `BS_score` higher than `BS`. The difference mainly reflects overfitting,
#' plus the smaller training samples. It is not Harrell's optimism, which
#' evaluates each bootstrap model on the original sample and is not computed
#' here.
#'
#' @details
#' When Score metrics and fit metrics are selected together, each Score
#' bootstrap training fit supplies all selected fit metrics (`AUC`, `BS`,
#' `AIC`, `BIC`, `PVE`) on its own training sample, without additional model
#' fitting. `AUC_score`/`BS_score` evaluate out-of-bag predictions; fit-metric
#' intervals describe the resampled training fits. Without Score metrics,
#' Score is not run and an ordinary paired subject bootstrap uses
#' [oo_pblapply()] with the same worker/seed policy as [get_fit_stats()].
#' Without resampling, each model is scored in its own Score call and the
#' results are stacked into one Score object. With contrasts and the null model
#' disabled this equals a single joint call, and it is faster for several
#' models even without parallel workers.
#' Prediction bootstrap parallelism retains Score's native splits, metric
#' aggregation and confidence intervals. Training seeds, bootstrap order and
#' the caller's final random-number state match serial evaluation. An existing
#' foreach backend is restored after parallel evaluation, including on error.
#'
#' AIC, BIC and Cox-Snell-type PVE follow [get_fit_stats()]:
#' `PVE = 1 - exp(-2 * (LL - LL_null) / n)`. BIC uses subjects for Logistic
#' and target events for Cox/Fine-Gray. Both functions fit Fine-Gray models
#' using FGR with `variance = FALSE` and the same FGR/cmprsk likelihood. PVE is
#' not a Nagelkerke-normalized R-squared. Compare likelihood criteria only
#' across models sharing the same outcome, sample and likelihood convention.
#' `AUC` and `BS` also follow [get_fit_stats()]: apparent metrics with Score's
#' conventions, averaged over `timepoint` for survival models, with
#' influence-function Wald intervals without bootstrap.
#' Only requested direct prediction metrics are computed; `BS` does not require
#' AUC to be defined. Models of the same sample reuse its time ordering and
#' censoring weights, which are re-estimated for every bootstrap sample.
#' Fitting and resampling carry only the selected predictor/outcome columns.
#' Windows bootcv metric workers receive one replicate's prediction block;
#' Score's native metric expressions and interval aggregation are retained.
#'
#' `AUC_mlr` and `BS_mlr` are the [get_msr()] values of the same models:
#' Cox Harrell's C-index (`surv.cindex`) and the integrated Graf (Brier) score
#' over the observed follow-up (`surv.graf`), both independent of
#' `timepoint`; Logistic `classif.auc` and `classif.bbrier`; Fine-Gray
#' cause-1 `cmprsk.auc` and `cmprsk.brier`, averaged over `timepoint`. Unlike
#' [get_msr()], which stops, Fine-Gray time points after the follow-up of an
#' evaluation set, or where either measure is undefined in any model or
#' bootstrap replicate, are dropped with a message, and the common remaining
#' grid is averaged. Both come from get_msr's own mlr3 fits, separate from the
#' Score and fit-metric fits. With `R >= 2` they are evaluated on mlr3
#' bootstrap out-of-bag rows and summarized as the mean with the 2.5% and
#' 97.5% quantiles of the replicate scores. All models share the same
#' replicates, so they are compared on paired samples.
#' `score_args` does not apply to them. They need mlr3 with mlr3proba (Cox),
#' mlr3learners (Logistic) or mlr3cmprsk >= 0.0.6 (Fine-Gray).
#'
#' Selecting a fit metric, `AUC_mlr` or `BS_mlr` uses common complete cases
#' across all model predictors, time and outcome; omissions are recorded in
#' `fit.stats$info` when fit metrics are selected.
#' Survival `AUC_score`/`BS_score` summaries average the requested available
#' times, without interpreting variation across times as a confidence
#' interval. Without resampling they carry the 95% Wald interval of
#' `get_fit_stats()`'s `AUC` / `BS`: the same time average, with Score's
#' influence-function standard error averaged over times, treating the fitted
#' risks as fixed and truncated to \[0, 1\]. With `R >= 2` they add the 2.5%
#' and 97.5% quantiles of each replicate's out-of-bag score averaged over its
#' finite times, as in [get_rpa_mp1()]; these ranges describe resampling-score
#' variability. The point estimate remains the time average of Score's
#' bootstrap means. A replicate that fails inside Score is dropped for every
#' model and metric with a warning; the summaries use the valid replicates,
#' whose number is kept in `attr(AUC.BS.AIC, "valid_reps")`.
#' Pointwise sampling intervals remain in `obj$AUC$score` /
#' `obj$Brier$score` and plots. Logistic summaries use Score's single-point
#' confidence intervals. The `times` columns show those pointwise rows: the
#' Wald confidence interval without resampling and, with `R >= 2`, the mean
#' with the 2.5% and 97.5% quantiles of the replicate scores.
#'
#' With `R = c(0, n)` the bootstrap call runs first, so every field except
#' `AUC.BS.AIC` and `ft` equals `get_score(R = n)` from the same seed. The
#' full-cohort panel keeps the 95% confidence intervals of the `R = 0` call
#' where they exist (Logistic Score columns, survival time averages and
#' `times` columns, `AUC`/`BS`); `AUC_mlr`/`BS_mlr` and likelihood criteria
#' show estimates only.
#'
#' Plot fields use ggplot2, optional UtilsR formatting and, for the combined
#' survival plot, optional patchwork. Missing patchwork leaves `plt.combined`
#' as `NULL`. Times are used unchanged, without rounding or a fixed axis limit.
#'
#' @return With `AUC_score` or `BS_score` selected, the original `Score`
#'   fields and class are retained. Other calls return a list. Both include:
#'   \describe{
#'     \item{obj}{The unaugmented Score object, or `NULL` without Score metrics.}
#'     \item{AUC.BS.AIC}{Formatted table: `model` plus the selected metrics,
#'       each Score metric followed by its `times` columns.
#'       The legacy field name also applies to other selections.}
#'     \item{ft}{`AUC.BS.AIC` as a flextable in the [get_inter()] style: one
#'       header row of readable metric labels (for example "C-index" for Cox
#'       `AUC_mlr`, "5-year AUC" for a named `times` column), three-line
#'       borders and a footer explaining the intervals: "95% confidence
#'       intervals where available" without resampling (no footer when no
#'       cell has one), or the replicate quantiles and number of (valid)
#'       bootstrap replicates. `NULL` when flextable is not installed.}
#'     \item{plt.AUC, plt.BS}{Survival curves of selected `AUC_score` /
#'       `BS_score`, otherwise `NULL`.}
#'     \item{plt.combined}{Two-panel survival plot when both curves and
#'       patchwork are available, otherwise `NULL`.}
#'     \item{plt.ROC}{Logistic ROC plot when Score supplies ROC data,
#'       otherwise `NULL` (including bootstrap calls).}
#'     \item{fit.stats}{Fit-metric results in the [get_fit_stats()] structure
#'       (`obj`, numeric `stats`, paired `boot`, `info`), restricted to selected
#'       `AUC`/`BS`/`AIC`/`BIC`/`PVE`, or `NULL` when none was requested.}
#'   }
#'   With `R = c(0, n)`, `AUC.BS.AIC` holds the full-cohort columns followed
#'   by the `R = n` metric columns suffixed with `"*"`, and `ft` (which then
#'   requires flextable) shows the two panels under an "Entire cohort" /
#'   "Entire cohort with n bootstrap replicates" spanner row, split by a blank
#'   column, with the footers of both panels.
#'
#' @examples
#' \donttest{
#' data(seer_thyroid_mtc_2026, package = "RegR")
#' d <- as.data.frame(seer_thyroid_mtc_2026)
#' d <- d[!is.na(d$DSS) & !is.na(d$time) & d$time > 0, ]
#'
#' res_sur <- run_quiet(get_score(
#'   d, vars = list(c("Age", "Sex")), surv = TRUE, timepoint = c(24, 60),
#'   metrics = c("AUC_score", "BS_score", "AUC", "BS", "AIC", "BIC", "PVE")
#' ))
#' res_sur$AUC.BS.AIC
#' res_sur$ft
#' res_sur$fit.stats$stats
#' res_sur$plt.combined
#'
#' # Full cohort and 20 bootstrap replicates side by side, with 5-year columns
#' if (requireNamespace("flextable", quietly = TRUE)) {
#'   both <- run_quiet(get_score(
#'     d, vars = c("Sex", "Race"), timepoint = c(24, 60),
#'     times = c("5-year" = 60), R = c(0, 20),
#'     metrics = c("AUC_score", "BS_score", "PVE")
#'   ))
#'   both$ft
#' }
#' }
#' @family msr
#' @export
get_score <- function(data, vars, surv = TRUE,
                      timepoint = seq(2, 200, 2), times = NULL,
                      R = 0, metrics = c("AUC_score", "BS_score"),
                      score_args = list(plots = "auto", n_cores = NULL)) {

  score_args <- .merge_named_arg(score_args, list(plots = "auto", n_cores = NULL),
                                 "score_args")
  if (!is.character(score_args$plots) || length(score_args$plots) != 1L ||
      is.na(score_args$plots) || !score_args$plots %in% c("auto", "none")) {
    stop("`score_args$plots` must be \"auto\" or \"none\".", call. = FALSE)
  }
  if (!is.null(score_args$n_cores) &&
      (!is.numeric(score_args$n_cores) || length(score_args$n_cores) != 1L ||
       !is.finite(score_args$n_cores) || score_args$n_cores < 1L ||
       score_args$n_cores != floor(score_args$n_cores) ||
       score_args$n_cores > .Machine$integer.max)) {
    stop("`score_args$n_cores` must be a positive integer or NULL.", call. = FALSE)
  }
  for (pkg in c("riskRegression", "prodlim", "survival")) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      stop(sprintf("Package '%s' is required for get_score().", pkg))
    }
  }

  mode <- if (isTRUE(surv)) "cox" else if (isFALSE(surv)) "crr" else
    if (is.character(surv) && length(surv) == 1L && !is.na(surv) &&
        surv %in% names(data)) "log" else {
    stop("`surv` must be logical (TRUE/FALSE) or a character outcome column name in `data`.")
  }
  requested <- .vars_requested(rlang::enquo(vars), data)
  if (is.list(requested) && !is.data.frame(requested)) {
    model_vars <- lapply(requested, function(x) {
      if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x))) {
        stop("Each element of `vars` must be a nonempty character vector.", call. = FALSE)
      }
      .resolve_vars(data, selected = tidyselect::all_of(x))
      selected
    })
  } else {
    .resolve_vars(data, vars = {{ vars }})
    model_vars <- as.list(vars)
  }
  if (!length(model_vars)) stop("`vars` must select at least one predictor.", call. = FALSE)
  nms <- names(model_vars)
  if (is.null(nms)) nms <- rep("", length(model_vars))
  auto <- vapply(model_vars, paste, collapse = "_", FUN.VALUE = character(1))
  if (anyNA(nms)) stop("Model names cannot be missing.", call. = FALSE)
  nms[!nzchar(nms)] <- auto[!nzchar(nms)]
  if (anyDuplicated(nms)) stop("Model names must be unique.", call. = FALSE)
  names(model_vars) <- nms
  allowed <- c("AUC_score", "BS_score", "AUC_mlr", "BS_mlr",
               "AUC", "BS", "AIC", "BIC", "PVE")
  if (!is.character(metrics) || !length(metrics) || anyNA(metrics) ||
      anyDuplicated(metrics) || any(!metrics %in% allowed)) {
    stop("`metrics` must select AUC_score, BS_score, AUC_mlr, BS_mlr, AUC, BS, ",
         "AIC, BIC or PVE without duplicates.", call. = FALSE)
  }
  if (!is.null(times)) {
    if (mode == "log") stop("`times` applies to Cox and Fine-Gray models only.", call. = FALSE)
    if (!any(c("AUC_score", "BS_score") %in% metrics)) {
      stop("`times` needs \"AUC_score\" or \"BS_score\" in `metrics`.", call. = FALSE)
    }
    if (!is.numeric(times) || !length(times) || any(!is.finite(times)) || any(times <= 0) ||
        anyDuplicated(times) || anyDuplicated(names(times)[nzchar(names(times))])) {
      stop("`times` must be distinct positive finite times with unique names.", call. = FALSE)
    }
  }
  if (is.null(R)) R <- 0L
  if (!is.numeric(R) || !length(R) %in% 1:2 || any(!is.finite(R)) ||
      any(R < 0) || any(R != floor(R)) || any(R > .Machine$integer.max) ||
      (length(R) == 2L && (R[1L] >= 2 || R[2L] < 2))) {
    stop("`R` must be a nonnegative integer, or c(0 or 1, >= 2) for both panels.",
         call. = FALSE)
  }
  if (length(R) == 2L) {
    if (!requireNamespace("flextable", quietly = TRUE)) {
      stop("Package 'flextable' is required for `R = c(0, n)`.", call. = FALSE)
    }
    # Bootstrap first, so its panel and fields equal get_score(R = n) from the
    # same seed; the full-cohort call only supplies the first panel.
    panel <- function(r) get_score(data, vars = !!model_vars, surv = surv,
                                   timepoint = timepoint, times = times, R = r,
                                   metrics = metrics, score_args = score_args)
    out <- panel(R[2L])
    point <- panel(R[1L])$AUC.BS.AIC
    boot <- out$AUC.BS.AIC
    out$AUC.BS.AIC <- cbind(point, stats::setNames(boot[-1L], paste0(names(boot)[-1L], "*")))
    out$ft <- .score_ft(list(point, boot), R, mode, times, attr(boot, "valid_reps"))
    return(out)
  }
  R <- as.integer(R)
  # Score() metrics versus metrics computed from each fit as in get_fit_stats().
  prediction_metrics <- intersect(metrics, c("AUC_score", "BS_score"))
  fit_metrics <- intersect(metrics, c("AUC", "BS", "AIC", "BIC", "PVE"))
  mlr_metrics <- intersect(metrics, c("AUC_mlr", "BS_mlr"))
  outcome <- switch(mode, cox = "DSS", crr = "event", log = surv)
  n_omitted <- 0L
  fit_times <- NULL
  if (length(fit_metrics) || length(mlr_metrics)) {
    required <- unique(c(unlist(model_vars, use.names = FALSE), outcome,
                         if (mode != "log") "time"))
    if (any(!required %in% names(data))) {
      stop("Missing required outcome/time columns.", call. = FALSE)
    }
    keep <- stats::complete.cases(data[, required, drop = FALSE])
    n_omitted <- sum(!keep)
    data <- droplevels(as.data.frame(data[keep, , drop = FALSE]))
    if (nrow(data) < 2L) stop("Fewer than two complete observations.", call. = FALSE)
    if (any(fit_metrics %in% c("AUC", "BS")) && mode != "log") {
      fit_times <- .fit_pred_times(timepoint, data$time)
    }
  }

  # Carry only model/outcome columns through fitting and bootstrap refits.
  needed <- unique(c(unlist(model_vars, use.names = FALSE), outcome,
                     if (mode != "log") "time"))
  data <- as.data.frame(data[, needed, drop = FALSE])

  # Isolate formulas from the result/plot/refit environments, including names
  # with spaces. Score requires bare Surv()/Hist() in its response formula.
  formula_env <- new.env(parent = baseenv())
  formula_env$Surv <- survival::Surv
  formula_env$Hist <- prodlim::Hist
  response <- if (mode == "log") as.name(outcome) else
    call(if (mode == "cox") "Surv" else "Hist", as.name("time"), as.name(outcome))
  formulas <- lapply(model_vars, function(x) {
    rhs <- Reduce(function(a, b) call("+", a, b), lapply(x, as.name))
    stats::as.formula(call("~", response, rhs), env = formula_env)
  })
  form <- stats::as.formula(call("~", response, 1), env = formula_env)
  fit_one <- function(dd, j) {
    formula <- formulas[[j]]
    fit <- switch(mode,
      cox = survival::coxph(formula, data = dd, x = TRUE, y = TRUE),
      crr = riskRegression::FGR(formula, data = dd, cause = 1, variance = FALSE),
      log = stats::glm(formula, data = dd, family = stats::binomial())
    )
    fit$call$formula <- formula
    fit
  }
  fit_lis <- lapply(seq_along(model_vars), function(j) {
    .cat_formula(data, co_var = model_vars[[j]],
                 time = if (mode == "log") NULL else "time", outcome = outcome,
                 type = "info")
    fit_one(data, j)
  })
  names(fit_lis) <- nms
  pred_cache <- new.env(parent = emptyenv())
  fit_stats_of <- function(fit, dd, se = FALSE) {
    .fit_stats_from_fit(fit, dd, mode, outcome, fit_metrics, fit_times, se,
                        pred_cache = pred_cache)
  }
  # Influence-function SEs are only needed without bootstrap percentiles.
  fitted <- if (length(fit_metrics)) lapply(fit_lis, fit_stats_of, dd = data, se = R < 2L)
  if (mode == "crr" && length(prediction_metrics)) {
    fit_lis <- lapply(fit_lis, function(fit) {
      class(fit) <- c("regr_score_fgr", class(fit))
      fit
    })
  }
  boot_store <- vector("list", length(fit_lis))
  if (length(prediction_metrics) && R >= 2L &&
      (length(fit_metrics) || mode == "crr")) {
    fitter <- switch(mode, cox = survival::coxph, crr = riskRegression::FGR,
                     log = stats::glm)
    # Score evaluates each fit's call on the bootstrap training data. A
    # function-valued call head captures criteria after that same native fit.
    capture_refit <- function(j) {
      force(j)
      function(formula, data, ...) {
        fit <- do.call(fitter, c(list(formula = formula, data = data), list(...)))
        if (length(fit_metrics)) {
          z <- tryCatch(fit_stats_of(fit, data)$value, error = function(e) e)
          failed <- inherits(z, "error")
          b <- length(boot_store[[j]]) + 1L
          boot_store[[j]][[b]] <<- data.frame(
            model = nms[j], replicate = b,
            as.list(if (failed) stats::setNames(rep(NA_real_, length(fit_metrics)),
                                                fit_metrics) else z),
            error = if (failed) conditionMessage(z) else NA_character_)
        }
        if (mode == "crr") class(fit) <- c("regr_score_fgr", class(fit))
        fit
      }
    }
    for (j in seq_along(fit_lis)) fit_lis[[j]]$call[[1L]] <- capture_refit(j)
  }
  res.Score <- NULL
  draw_bounds <- list()
  valid_reps <- NULL
  # Per-time columns are read from the same Score call as the time averages.
  score_times <- if (mode != "log") {
    if (is.null(times)) timepoint else sort(unique(c(timepoint, times)))
  }
  n_times <- if (mode == "log") 1L else length(score_times)
  if (length(prediction_metrics) && R < 2L) {
    res.Score <- .score_by_model(
      fit_lis, data, form,
      metrics = ifelse(prediction_metrics == "BS_score", "brier", "auc"),
      plots = if (score_args$plots != "none" && "AUC_score" %in% metrics) "ROC",
      times = score_times, n_cores = score_args$n_cores,
      # Tenths of row x model x time units: measured break-even of per-model
      # Score workers sits near oo_cores()'s work threshold times ten, as PSOCK
      # start-up and returning Score objects (ROC frames) cost seconds.
      work = as.double(nrow(data)) * length(fit_lis) * n_times / 10)
    # Survival time averages take the Wald limits of get_fit_stats()'s AUC / BS:
    # the same estimates, with the influence-function SE averaged over times.
    # A cell keeps its bare estimate where the two averages differ, as with a
    # time 0 that Score scores (Brier 0) but get_fit_stats() does not accept.
    if (mode != "log") {
      ok <- stats::complete.cases(data)
      native <- c(AUC_score = "AUC", BS_score = "Brier")[prediction_metrics]
      fit_name <- c(AUC_score = "AUC", BS_score = "BS")[prediction_metrics]
      pred_data <- data[ok, , drop = FALSE]
      prepared <- NULL
      pred_of <- function(m) tryCatch({
        pred_times <- .fit_pred_times(timepoint[timepoint > 0], pred_data$time)
        # Direct metrics already carry the same time-average influence-function
        # SE. Reuse only that sample/grid, and compute any missing metric once.
        reuse <- if (all(ok) && identical(pred_times, fit_times))
          intersect(m, fit_metrics) else character()
        missing <- setdiff(m, reuse)
        if (length(missing) && is.null(prepared)) {
          prepared <<- if (identical(pred_data, pred_cache$data) &&
                           identical(pred_times, fit_times) && isTRUE(pred_cache$se))
            pred_cache$prepared else .fit_pred_prepare(pred_data, outcome, pred_times, TRUE)
        }
        lapply(seq_along(fit_lis), function(j) {
          old <- if (length(reuse)) fitted[[j]] else list(value = numeric(), se = numeric())
          new <- if (length(missing)) .fit_pred_stats(
            fit_lis[[j]], pred_data, mode, outcome, pred_times, se = TRUE,
            metrics = missing, prepared = prepared) else list(value = numeric(), se = numeric())
          list(value = c(old$value[reuse], new$value), se = c(old$se[reuse], new$se))
        })
      }, error = function(e) NULL)
      # One pass for both; if it fails (AUC undefined at every time), retry
      # each metric alone so BS_score keeps its interval.
      pred <- pred_of(unname(fit_name))
      preds <- if (!is.null(pred) || length(fit_name) < 2L) rep(list(pred), length(fit_name))
               else lapply(unname(fit_name), pred_of)
      crit <- stats::qnorm(0.975)
      for (k in seq_along(native)) {
        pred <- preds[[k]]
        if (is.null(pred)) next
        sc <- res.Score[[native[[k]]]]$score
        shown <- vapply(names(fit_lis), function(label) {
          z <- sc[as.character(sc$model) == label & sc$times %in% timepoint, ]
          mean(z[[native[[k]]]], na.rm = TRUE)
        }, numeric(1))
        est <- vapply(pred, function(p) p$value[[fit_name[[k]]]], numeric(1))
        se <- vapply(pred, function(p) p$se[[fit_name[[k]]]], numeric(1))
        se[!(is.finite(est) & is.finite(shown) & abs(est - shown) <= 1e-8)] <- NA_real_
        draw_bounds[[native[[k]]]] <- matrix(
          c(pmax(0, est - crit * se), pmin(1, est + crit * se)), ncol = 2L,
          dimnames = list(names(fit_lis), NULL))
      }
    }
  } else if (length(prediction_metrics)) {
    requested <- score_args$n_cores
    # PSOCK workers (Windows; .RegR.psock in tests) lose on Score's bootstrap:
    # Cox, 2 models, 100 times, 4 workers took 43 s for n = 4,387 / R = 100
    # (serial 30 s) and 77 s for n = 17,548 / R = 50 (serial 50 s), and
    # parallelizing only the training or only the metric loop lost as well.
    # So the adaptive choice stays serial there; an explicit n_cores is kept.
    psock <- .Platform$OS.type == "windows" || isTRUE(getOption(".RegR.psock"))
    cores <- if (!is.null(requested)) oo_cores(R, n_cores = requested) else if (R >= 4L && !psock)
      min(4L, oo_cores(R, work = as.double(nrow(data)) * R * length(model_vars) * n_times))
      else 1L
    if (cores > 1L) {
      registry <- get(".foreachGlobals", asNamespace("foreach"))
      keys <- c("fun", "data", "info")
      previous <- mget(intersect(keys, ls(registry)), registry, inherits = FALSE)
      on.exit({
        rm(list = intersect(keys, ls(registry)), envir = registry)
        list2env(previous, registry)
      }, add = TRUE)
      foreach::setDoPar(.score_foreach_backend,
        list(cores = cores, partition = psock, cache = new.env(parent = emptyenv()),
             capture = length(fit_metrics) > 0L,
             get_store = function() boot_store,
             set_store = function(x) boot_store <<- x),
        function(data, item) switch(item, workers = data$cores,
          name = "RegR oo_pblapply", version = "1"))
    }
    res.Score <- riskRegression::Score(
      object = fit_lis, formula = form, data = data,
      metrics = ifelse(prediction_metrics == "BS_score", "brier", "auc"),
      # No boxplot data: riskRegression fails on it in some replicates (late
      # time points), and Score then drops those replicates from every metric.
      plots = NULL,
      null.model = FALSE, contrasts = FALSE,
      times = score_times,
      split.method = "bootcv", B = R, keep = "cv",
      parallel = if (cores > 1L) "as.registered" else "no", cl = 10L,
      progress.bar = if (cores > 1L) NULL else 3L
    )
    # keep = "cv" stacks each valid replicate's model x time scores in
    # replicate order; Score drops a failed replicate for every model and
    # metric. Summaries add percentiles of the replicates' time averages.
    for (native in intersect(c("AUC", "Brier"), names(res.Score))) {
      cv <- res.Score[[native]]$cv.score
      res.Score[[native]][c("cv.score", "cv.contrasts")] <- NULL
      per_rep <- nrow(res.Score[[native]]$score)
      if (is.null(cv) || !per_rep || nrow(cv) %% per_rep) next
      valid_reps <- nrow(cv) %/% per_rep
      if (valid_reps < 2L) next
      at_grid <- if (is.null(cv$times)) rep(TRUE, nrow(cv)) else cv$times %in% timepoint
      draws <- tapply(cv[[native]][at_grid],
                      list(as.character(cv$model)[at_grid],
                           rep(seq_len(valid_reps), each = per_rep)[at_grid]),
                      function(v) mean(v[is.finite(v)]))
      draw_bounds[[native]] <- t(apply(draws, 1L, stats::quantile, c(0.025, 0.975),
                                       na.rm = TRUE, names = FALSE))
    }
    if (!is.null(valid_reps) && valid_reps < R) warning(sprintf(
      "%d of %d Score bootstrap replicates failed; AUC_score/BS_score use the %d valid replicates.",
      R - valid_reps, R, valid_reps), call. = FALSE)
  }
  fit_stats <- NULL
  if (length(fit_metrics)) {
    if (length(prediction_metrics) && R >= 2L && any(lengths(boot_store) != R)) {
      stop("Score did not provide the expected bootstrap training fits.", call. = FALSE)
    }
    boot <- if (length(prediction_metrics) && R >= 2L)
      do.call(rbind, unlist(boot_store, recursive = FALSE)) else NULL
    fit_stats <- .fit_stats_result(
      fitted, data, function(dd, j) fit_stats_of(fit_one(dd, j), dd),
      R, n_omitted = n_omitted, boot = boot, n_cores = score_args$n_cores
    )
  }
  # After the Score and fit-metric bootstraps, so their results do not move.
  mlr_table <- if (length(mlr_metrics)) switch(mode,
    cox = .get_msr_sur(data, unname(model_vars), R = R),
    log = .get_msr_log(data, unname(model_vars), outcome = outcome, R = R),
    crr = .get_msr_cmprsk(data, unname(model_vars), R = R, timepoint = timepoint,
                          cause = 1L, drop_times = TRUE)
  )
  format_metric <- function(x, lower = NA_real_, upper = NA_real_, digits = 3L) {
    value <- sprintf(paste0("%.", digits, "f"), x)
    if (is.finite(lower) && is.finite(upper))
      paste0(value, " (", sprintf(paste0("%.", digits, "f"), lower), ", ",
             sprintf(paste0("%.", digits, "f"), upper), ")") else value
  }
  res_table <- data.frame(model = nms)
  for (metric in metrics) {
    if (metric %in% prediction_metrics) {
      native <- if (metric == "BS_score") "Brier" else "AUC"
      scores <- res.Score[[native]]$score
      res_table[[metric]] <- vapply(nms, function(label) {
        z <- scores[as.character(scores$model) == label, ]
        if ("times" %in% names(z)) {
          b <- if (is.null(draw_bounds[[native]])) c(NA_real_, NA_real_) else
            draw_bounds[[native]][label, ]
          format_metric(mean(z[[native]][z$times %in% timepoint], na.rm = TRUE), b[1L], b[2L])
        } else format_metric(z[[native]], z$lower, z$upper)
      }, character(1))
      # Score's pointwise rows: Wald intervals, or replicate quantiles with bootcv.
      for (t in times) res_table[[paste0(metric, "_", t)]] <- vapply(nms, function(label) {
        z <- scores[as.character(scores$model) == label & scores$times == t, ]
        if (nrow(z)) format_metric(z[[native]], z$lower, z$upper) else NA_character_
      }, character(1))
    } else if (metric %in% mlr_metrics) {
      column <- switch(mode, cox = c(AUC_mlr = "surv.cindex", BS_mlr = "surv.graf"),
                       log = c(AUC_mlr = "classif.auc", BS_mlr = "classif.bbrier"),
                       crr = c(AUC_mlr = "cmprsk.auc", BS_mlr = "cmprsk.brier"))[[metric]]
      x <- mlr_table[[column]]
      res_table[[metric]] <- if (is.numeric(x)) format_metric(x) else x
    } else {
      res_table[[metric]] <- vapply(nms, function(label) {
        z <- fit_stats$stats[fit_stats$stats$model == label &
                              fit_stats$stats$metric == metric, ]
        format_metric(z$estimate, z$lower, z$upper, if (metric %in% c("AIC", "BIC")) 2L else 3L)
      }, character(1))
    }
  }
  if (!is.null(valid_reps)) attr(res_table, "valid_reps") <- valid_reps

  plt_AUC <- plt_BS <- plt_combined <- plt_ROC <- NULL
  if (length(prediction_metrics)) {
    has_utils <- requireNamespace("UtilsR", quietly = TRUE)
    palette <- if (has_utils) rep_len(UtilsR::pal_lancet, length(nms)) else
      grDevices::hcl.colors(length(nms), "Dark 3")
    thm <- if (has_utils) UtilsR::theme_my(base_rect_size = 1.5, base_size = 12L) else
      ggplot2::theme_bw(base_size = 12L)
    build_curve <- function(native, label, template = NULL) {
      if (!is.null(template)) {
        return(template + res.Score[[native]]$score +
                 ggplot2::aes(x = .data$times, y = .data[[native]],
                              color = .data$model, fill = .data$model) +
                 ggplot2::labs(title = paste("Time-dependent", label, "curve"),
                               x = "Times", y = label))
      }
      ggplot2::ggplot(res.Score[[native]]$score,
                     ggplot2::aes(x = .data$times, y = .data[[native]],
                                  color = .data$model, fill = .data$model)) +
        ggplot2::geom_line() +
        ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$lower, ymax = .data$upper),
                             alpha = 0.3, color = NA) +
        ggplot2::scale_color_manual(values = palette) +
        ggplot2::scale_fill_manual(values = palette) +
        ggplot2::labs(title = paste("Time-dependent", label, "curve"),
                      x = "Times", y = label) + thm
    }
    if (mode != "log") {
      if ("AUC_score" %in% metrics) plt_AUC <- build_curve("AUC", "AUC")
      if ("BS_score" %in% metrics) plt_BS <- build_curve("Brier", "Brier score", plt_AUC)
      if (!is.null(plt_AUC) && !is.null(plt_BS) &&
          requireNamespace("patchwork", quietly = TRUE)) {
        plt_combined <- patchwork::wrap_plots(
          plt_AUC + ggplot2::labs(title = NULL),
          plt_BS + ggplot2::labs(title = NULL), ncol = 1
        )
        if (has_utils) plt_combined <- UtilsR::fmt_plot(
          plt_combined,
          fmt_strip_list = list(label = c("Time-dependent AUC curve",
                                           "Time-dependent Brier score curve"),
                                label_color = "white", label_fill = palette),
          fmt_axis_list = list(x.axis = c(1)),
          fmt_legend_list = list(legend.position = c(0.8, 0.2))
        )
      }
    } else if (!is.null(res.Score$ROC$plotframe)) {
      plt_ROC <- ggplot2::ggplot(res.Score$ROC$plotframe,
                                ggplot2::aes(x = .data$FPR, y = .data$TPR,
                                             color = .data$model)) +
        ggplot2::geom_line(linewidth = 1) +
        ggplot2::geom_abline(intercept = 0, slope = 1,
                             linetype = "dashed", color = "gray50") +
        ggplot2::scale_color_manual(values = palette) +
        ggplot2::labs(x = "False Positive Rate (1 - Specificity)",
                      y = "True Positive Rate (Sensitivity)") + thm
      if (has_utils) plt_ROC <- UtilsR::fmt_legend(
        UtilsR::fmt_strip(plt_ROC, label = "ROC curves"), legend.position = c(0.8, 0.2))
    }
  }
  ft <- if (requireNamespace("flextable", quietly = TRUE))
    .score_ft(list(res_table), R, mode, times, valid_reps)
  result <- c(res.Score, list(obj = res.Score, AUC.BS.AIC = res_table, ft = ft,
                             plt.AUC = plt_AUC, plt.BS = plt_BS,
                             plt.combined = plt_combined, plt.ROC = plt_ROC,
                             fit.stats = fit_stats))
  if (!is.null(res.Score)) class(result) <- class(res.Score)
  result
}

# get_score()'s AUC.BS.AIC as a get_inter()-style flextable: one panel per
# table in `tables` (same metric columns, R as in the call). Two panels get an
# "Entire cohort" spanner row and a blank separator column between them.
.score_ft <- function(tables, R, mode, times, reps) {
  keys <- names(tables[[1L]])[-1L]
  # Readable labels; the same quantity from two engines keeps its key.
  labels <- c(
    AUC_mlr = switch(mode, cox = "C-index", log = "AUC", crr = "Mean time-dependent AUC"),
    BS_mlr = switch(mode, cox = "Integrated Brier", log = "Brier",
                    crr = "Mean time-dependent Brier"),
    AUC_score = if (mode == "log") "AUC" else "Mean time-dependent AUC",
    BS_score = if (mode == "log") "Brier" else "Mean time-dependent Brier",
    AUC = if (mode == "log") "Apparent AUC" else "Apparent mean time-dependent AUC",
    BS = if (mode == "log") "Apparent Brier" else "Apparent mean time-dependent Brier",
    AIC = "AIC", BIC = "BIC", PVE = "PVE")
  if (!is.null(times)) {
    at <- names(times)
    if (is.null(at)) at <- character(length(times))
    for (m in c("AUC_score", "BS_score")) {
      what <- if (m == "AUC_score") "AUC" else "Brier"
      labels[paste0(m, "_", times)] <- ifelse(nzchar(at), paste(at, what),
                                              sprintf("%s (t = %s)", what, times))
    }
  }
  labels <- labels[keys]
  dup <- labels %in% labels[duplicated(labels)]
  labels[dup] <- sprintf("%s (%s)", labels[dup], keys[dup])
  two <- length(tables) == 2L
  n <- R[length(R)]
  failed <- if (n >= 2L && !is.null(reps) && reps < n) sprintf(
    "; %s use %d valid replicates", sub(", ([^,]*)$", " and \\1",
    paste(labels[grepl("^(AUC|BS)_score", keys)], collapse = ", ")), reps) else ""
  has_ci <- R[1L] < 2L && any(grepl(" (", unlist(tables[[1L]][-1L]), fixed = TRUE))
  note <- paste(c(
    if (has_ci) paste0(if (two) "Entire cohort panel: ", "95% confidence intervals where available."),
    if (two) sprintf("Bootstrap panel: mean (2.5%%, 97.5%% quantiles) over %d replicates%s.", n, failed)
    else if (n >= 2L) sprintf("Mean (2.5%%, 97.5%% quantiles) over %d bootstrap replicates%s.", n, failed)
  ), collapse = " ")
  k <- length(keys) + 1L
  # get_inter() layout: a blank separator column (non-breaking spaces keep its
  # width under autofit) splits the panel rules, APA three-line borders.
  shown <- if (two) cbind(tables[[1L]], sep = strrep(intToUtf8(160L), 3L),
                          stats::setNames(tables[[2L]][-1L], paste0(keys, "*"))) else tables[[1L]]
  thick <- officer::fp_border(width = 1.5)
  ft <- flextable::flextable(shown) %>%
    flextable::set_header_labels(values = stats::setNames(
      as.list(c("Model", labels, if (two) c("", labels))), names(shown)))
  if (two) ft <- flextable::add_header_row(ft,
    values = c("", "Entire cohort", "", sprintf("Entire cohort with %d bootstrap replicates", n)),
    colwidths = c(1L, k - 1L, 1L, k - 1L))
  if (nzchar(note)) ft <- flextable::add_footer_lines(ft, note)
  ft <- ft %>%
    .fmt_inter_ft_apa() %>%
    flextable::align(align = "center", part = "all") %>%
    flextable::align(align = "left", part = "footer") %>%
    flextable::bold(j = 1L, part = "body") %>%
    flextable::bold(part = "header") %>%
    flextable::bg(bg = "#F2F2F2", part = "header") %>%
    flextable::border_remove() %>%
    flextable::hline_top(border = thick, part = "header") %>%
    flextable::hline_bottom(border = thick, part = "header") %>%
    flextable::hline_bottom(border = thick, part = "body") %>%
    flextable::set_table_properties(layout = "autofit", width = 1)
  if (!two) return(ft)
  panels <- seq_len(k - 1L)
  rule <- officer::fp_border(width = 0.75, color = "black")
  ft %>%
    flextable::bg(i = 1L, bg = "#D9D9D9", part = "header") %>%
    flextable::hline(i = 1L, j = 1L + panels, border = rule, part = "header") %>%
    flextable::hline(i = 1L, j = k + 1L + panels, border = rule, part = "header") %>%
    flextable::padding(j = k + 1L, padding.left = 6, padding.right = 6, part = "all")
}


#' Summarize riskRegression::Score output as a 3-column table
#'
#' Aggregates time-dependent C-index / Brier into a single CI string per
#' model. For survival (when `times` column is present), averages over
#' time grid with normal-approximation CI; for logistic (single point),
#' formats the existing CI bounds. Source-faithful port of
#' `.get.score.summary`.
#'
#' @param res.Score Output of [get_score()] (i.e. a `Score` object from
#'   `riskRegression::Score()`).
#' @return data.frame with columns `model`, `C.index`, `Brier.score`.
#'   With a nondefault metric selection, returns the selected-metric
#'   `AUC.BS.AIC` table from [get_score()] instead. The legacy `C.index`
#'   column represents mean time-dependent AUC, not Harrell's C-index.
#' @examplesIf requireNamespace("UtilsR", quietly = TRUE)
#' \donttest{
#' data(seer_thyroid_mtc_2026, package = "RegR")
#' d <- seer_thyroid_mtc_2026
#'
#' # R = 0 skips the bootstrap so the example stays quick.
#' score <- get_score(d, vars = c("Sex", "Race"), surv = TRUE, R = 0)
#' get_score_summary(score)
#' }
#' @family msr
#' @export
get_score_summary <- function(res.Score) {
  if (!is.null(res.Score$AUC.BS.AIC) &&
      !identical(names(res.Score$AUC.BS.AIC), c("model", "AUC_score", "BS_score"))) {
    return(res.Score$AUC.BS.AIC)
  }

  conf_level <- 0.95

  ## for sur (cox/crr) model
  if ("times" %in% names(res.Score[["AUC"]][["score"]])) {
    z_score <- stats::qnorm(1 - (1 - conf_level) / 2)

    dat.AUC <-
      res.Score[["AUC"]][["score"]] %>%
      dplyr::group_by(.data$model) %>%
      dplyr::filter(!is.na(.data$AUC)) %>%
      dplyr::summarise(
        yhat  = sum(.data$AUC) / dplyr::n(),
        lower = .data$yhat - z_score * stats::sd(.data$AUC) / sqrt(dplyr::n()),
        upper = .data$yhat + z_score * stats::sd(.data$AUC) / sqrt(dplyr::n())
      ) %>%
      dplyr::mutate(`C-index` = sprintf("%.3f (%.3f, %.3f)",
                                        .data$yhat, .data$lower, .data$upper))

    dat.Brier <-
      res.Score[["Brier"]][["score"]] %>%
      dplyr::group_by(.data$model) %>%
      dplyr::summarise(
        yhat  = sum(.data$Brier) / dplyr::n(),
        lower = .data$yhat - z_score * stats::sd(.data$Brier) / sqrt(dplyr::n()),
        upper = .data$yhat + z_score * stats::sd(.data$Brier) / sqrt(dplyr::n())
      ) %>%
      dplyr::mutate(`Brier score` = sprintf("%.4f (%.4f, %.4f)",
                                            .data$yhat, .data$lower, .data$upper))

    data.frame(model         = dat.AUC$model,
               `C-index`     = dat.AUC$`C-index`,
               `Brier score` = dat.Brier$`Brier score`)

  } else {
    ## for log model
    dat.AUC <- res.Score[["AUC"]][["score"]] %>%
      dplyr::mutate(`C-index` = sprintf("%.3f (%.3f, %.3f)",
                                        .data$AUC, .data$lower, .data$upper))
    dat.Brier <- res.Score[["Brier"]][["score"]] %>%
      dplyr::mutate(`Brier score` = sprintf("%.3f (%.3f, %.3f)",
                                            .data$Brier, .data$lower, .data$upper))

    data.frame(model         = dat.AUC$model,
               `C-index`     = dat.AUC$`C-index`,
               `Brier score` = dat.Brier$`Brier score`)
  }
}


#' Visualize riskRegression::Score output (time-curves or ROC)
#'
#' Source-faithful port of `.plt.score`. For survival Score (with `times`
#' column), draws 2-panel patchwork: time-dependent AUC + Brier curves
#' with ribbon CIs. For logistic Score (no `times`), draws a single ROC
#' curve from `res.Score$ROC$plotframe`.
#'
#' @param res.Score Output of [get_score()].
#' @return A `ggplot` (logistic or one selected survival metric) or
#'   `patchwork` (both survival metrics). Returns `NULL` when [get_score()]
#'   has no applicable plot, including likelihood-only calls.
#' @examplesIf requireNamespace("patchwork", quietly = TRUE) && requireNamespace("UtilsR", quietly = TRUE)
#' \donttest{
#' data(seer_thyroid_mtc_2026, package = "RegR")
#' d <- seer_thyroid_mtc_2026
#'
#' score <- get_score(d, vars = c("Sex", "Race"), surv = TRUE, R = 0)
#' plt_score(score)
#' }
#' @family msr
#' @export
plt_score <- function(res.Score) {
  if (!all(c("AUC", "Brier") %in% names(res.Score)) &&
      "plt.AUC" %in% names(res.Score)) {
    for (field in c("plt.combined", "plt.AUC", "plt.BS", "plt.ROC")) {
      if (!is.null(res.Score[[field]])) return(res.Score[[field]])
    }
    return(NULL)
  }

  for (pkg in c("ggplot2", "patchwork")) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      stop(sprintf("Package '%s' is required for plt_score().", pkg))
    }
  }

  base_size <- 16L
  km_theme <- ggplot2::`%+replace%`(
    UtilsR::theme_my(base_rect_size = 1.5, base_size = base_size),
    ggplot2::theme(panel.grid.minor = ggplot2::element_blank(),
                   legend.title = ggplot2::element_text(hjust = 0),
                   legend.text  = ggplot2::element_text(hjust = 0,
                                                        face = "bold")))

  if ("times" %in% names(res.Score[["AUC"]][["score"]])) {
    # set par
    xlim <- NULL; xbre <- NULL
    ylim <- NULL; ybre <- NULL
    xexp <- 0.02; yexp <- 0.02

    ## nested helper (source-faithful: axis + CI clip)
    .fmt.plot <- function(p,
                          xlim = NULL, xbre = NULL, xexp = 0.02,
                          ylim = NULL, ybre = NULL, yexp = 0.02,
                          conf_int_bound = TRUE) {

      if (!is.null(xlim)) {
        p <- p + ggplot2::scale_x_continuous(
          limits = xlim, breaks = xbre,
          expand = ggplot2::expansion(mult = c(xexp, xexp)))
      }
      if (!is.null(ylim)) {
        p <- p + ggplot2::scale_y_continuous(
          limits = ylim, breaks = ybre,
          expand = ggplot2::expansion(mult = c(yexp, yexp)))
      }
      if (!is.null(ylim) && isTRUE(conf_int_bound) &&
          ("ci_lower" %in% names(p$data))) {
        p$data <-
          p$data %>%
          dplyr::mutate(
            ci_lower = dplyr::if_else(.data$ci_lower < ylim[1],
                                      ylim[1], .data$ci_lower),
            ci_upper = dplyr::if_else(.data$ci_upper > ylim[2],
                                      ylim[2], .data$ci_upper))
      }
      p
    }

    p1 <-
      res.Score[["AUC"]][["score"]] %>%
      dplyr::mutate(yhat = .data[["AUC"]]) %>%
      ggplot2::ggplot(ggplot2::aes(x = .data$times, y = .data$yhat,
                                   color = .data$model, fill = .data$model)) +
      ggplot2::geom_line() +
      ggplot2::geom_ribbon(ggplot2::aes(.data$times,
                                        ymin = .data$lower, ymax = .data$upper),
                           alpha = 0.3, color = NA) +
      ggplot2::scale_color_manual(values = UtilsR::pal_lancet) +
      ggplot2::scale_fill_manual(values = UtilsR::pal_lancet) +
      ggplot2::labs(x = "Times", y = "AUC") +
      km_theme

    p2 <-
      res.Score[["Brier"]][["score"]] %>%
      dplyr::mutate(yhat = .data[["Brier"]]) %>%
      ggplot2::ggplot(ggplot2::aes(x = .data$times, y = .data$yhat,
                                   color = .data$model, fill = .data$model)) +
      ggplot2::geom_line() +
      ggplot2::geom_ribbon(ggplot2::aes(.data$times,
                                        ymin = .data$lower, ymax = .data$upper),
                           alpha = 0.3, color = NA) +
      ggplot2::scale_color_manual(values = UtilsR::pal_lancet) +
      ggplot2::scale_fill_manual(values = UtilsR::pal_lancet) +
      ggplot2::labs(x = "Times", y = "Brier score") +
      km_theme

    p1 <- .fmt.plot(p1)
    p2 <- .fmt.plot(p2)

    (p1 / p2) %>%
      UtilsR::fmt_plot(
        fmt_strip_list = list(
          label = c("Time-dependent AUC curve",
                    "Time-dependent Brier score curve"),
          label_color = "white",
          label_fill  = UtilsR::pal_lancet),
        fmt_axis_list = list(x.axis = c(1)),
        fmt_legend_list = list(legend.position = c(0.8, 0.2),
                               merge_legends = FALSE)
      )

  } else {
    ## ROC curve for log
    roc_data <- res.Score$ROC$plotframe

    p_roc <-
      roc_data %>%
      ggplot2::ggplot(ggplot2::aes(x = .data$FPR, y = .data$TPR,
                                   color = .data$model)) +
      ggplot2::geom_line(size = 1) +
      ggplot2::geom_abline(intercept = 0, slope = 1,
                           linetype = "dashed", color = "gray50") +
      ggplot2::scale_color_manual(values = UtilsR::pal_lancet) +
      ggplot2::labs(x = "False Positive Rate (1 - Specificity)",
                    y = "True Positive Rate (Sensitivity)") +
      km_theme

    UtilsR::fmt_strip(p_roc, label = "ROC curves") %>%
      UtilsR::fmt_legend(legend.position = c(0.8, 0.2))
  }
}
