#' Compute likelihood and prediction metrics from one fit per model
#'
#' Fits each requested model once and extracts the selected statistics: AIC,
#' BIC, likelihood-based PVE, and apparent AUC and Brier score (BS). Logistic
#' models use [stats::glm()], Cox models use [survival::coxph()], and Fine-Gray
#' models use [riskRegression::FGR()] with `variance = FALSE`. Bootstrap
#' replicates also share one fit across the selected statistics, and all models
#' share the same resampled row indices.
#'
#' @param data A data.frame. Survival modes require positive finite `time` and
#'   numeric 0/1 `DSS` (Cox), or numeric `event` coded 0 = censored, 1 = target
#'   event, 2 = competing event (Fine-Gray). Times are used unchanged.
#' @param vars Predictor selection, as in [get_score()]: a character vector
#'   fits one model per column; a list of character vectors fits one model per
#'   list element. Use `list(c("Age", "Sex"))` for a single joint model.
#'   List names label the models; otherwise predictor names are joined by `_`.
#'   Names of a character vector, such as `c("Sex", "Age, years" = "Age")`,
#'   likewise label its separate models, also inside `all_of()` / `any_of()`.
#'   A bare/tidyselect selection is also accepted for separate-column models.
#' @param surv `TRUE` (default) for Cox, `FALSE` for Fine-Gray, or one outcome
#'   column name for binary Logistic regression. Logistic outcomes must be
#'   0/1, logical, or a two-level factor (second level is the event).
#' @param timepoint Numeric vector of positive times for survival AUC/BS,
#'   default `seq(2, 200, 2)` as in [get_score()]. Times are sorted and
#'   deduplicated; times after the last follow-up are dropped, as in
#'   [riskRegression::Score()]. Ignored for Logistic models and when neither
#'   `"AUC"` nor `"BS"` is selected.
#' @param R Nonnegative integer bootstrap repetitions. `NULL`, 0 or 1 means
#'   no resampling; at least 2 enables ordinary subject bootstrap.
#'   This is not the `bootcv` prediction validation used by [get_score()].
#'   Use many more than 2 repetitions for reported confidence intervals.
#' @param metrics Nonempty character vector selecting any of `"AUC"`, `"BS"`,
#'   `"AIC"`, `"BIC"`, `"PVE"`, without duplicates. Default
#'   `c("AIC", "BIC", "PVE")`. The selected order is kept in `stats` and `boot`.
#' @param conf_level Confidence level strictly between 0 and 1, default 0.95.
#'   With bootstrap, intervals are percentile intervals and SE is the bootstrap
#'   standard deviation. Without bootstrap, AUC/BS use influence-function Wald
#'   intervals (see Details) and AIC/BIC/PVE have none. Point estimates always
#'   come from the original analysis sample.
#' @param save Optional named list forwarded to [save_tb()]. `NULL` or
#'   `list()` does not save. A nonempty list saves `stats` to Word without
#'   changing the return value. Supported fields are:
#'   \describe{
#'     \item{path}{Character output directory; default `NULL` (current directory).}
#'     \item{title}{Character title and filename; default
#'       `"Table 1 baseline characteristics"`; `.docx` is appended if absent.}
#'     \item{note}{Optional character footnote; default `NULL`.}
#'     \item{header_value}{Optional character vector of extra header labels;
#'       default `NULL` (no extra header).}
#'     \item{header_colwidths}{Positive integer spans for `header_value`,
#'       default `c(4, 2)`; when used, spans must cover the table columns.}
#'     \item{line_spacing}{Positive numeric multiple of single line spacing,
#'       default 0.8.}
#'   }
#'
#' @details
#' `AIC = -2 * LL + 2 * k`; `BIC = -2 * LL + log(bic_n) * k`.
#' The parameter count `k` includes the Logistic intercept and excludes the
#' unspecified survival baseline. `bic_n` is the subject count for Logistic
#' and the target-event count for Cox and Fine-Gray. Cox therefore agrees with
#' `stats::BIC(coxph_fit)`; the Fine-Gray event-count penalty is an explicit
#' convention, reported in `info`.
#'
#' `PVE = 1 - exp(-2 * (LL - LL_null) / n)` is Cox-Snell-type likelihood
#' pseudo-R-squared, not a Nagelkerke-normalized R-squared or a literal fraction
#' of outcome variance. `n` is the number of subjects used, in every mode.
#' Logistic null likelihood comes from `null.deviance`, and Cox retains it in
#' the fit. Fine-Gray uses `crrFit$loglik` and `crrFit$loglik.null` from the
#' fitted FGR object; there is no second model optimization.
#'
#' Cox uses partial likelihood and Fine-Gray uses the FGR/cmprsk
#' pseudo-partial likelihood, as in [get_score()]. These are descriptive
#' likelihood-based criteria. Disabling coefficient variance does not change
#' these likelihoods. FGR objects omit usable coefficient variances and
#' residuals; use `variance = TRUE` in a separate fit for coefficient inference.
#' Compare models only for the same outcome, sample and likelihood convention;
#' do not compare their absolute AIC/BIC across the three model families.
#'
#' AUC and BS are apparent (in-sample) metrics of each fitted model, computed
#' directly with the conventions of [riskRegression::Score()]. Cox and
#' Fine-Gray models use time-dependent cumulative/dynamic AUC and Brier score
#' with reverse Kaplan-Meier censoring weights; competing events count as
#' controls and tied risks count one half. Survival values are averaged over
#' `timepoint` (AUC over the times where it is defined), as in the
#' `AUC.BS.AIC` table of [get_score()]. Without bootstrap, SE is Score's
#' influence-function standard error including the Kaplan-Meier censoring
#' term (DeLong for Logistic AUC), averaged over times before taking the SD,
#' and limits are Wald intervals truncated to \[0, 1\]. They treat the fitted
#' risks as fixed. With bootstrap, each replicate computes AUC/BS on its own
#' resample with re-estimated censoring weights, without influence functions.
#' Neither interval is optimism-corrected; use [get_score()] for out-of-bag
#' `bootcv` validation.
#' Only requested prediction metrics are evaluated; `BS` is available even
#' when no target event has occurred by the selected time. Models of the same
#' sample share time ordering and censoring weights, with fresh weights for
#' every bootstrap sample.
#'
#' A common complete-case sample over all requested predictors and the outcome
#' is used for model comparisons. Missing rows are recorded in `info`.
#' Bootstrap failures (including model-fitting warnings) are retained in
#' `boot$error`, summarized by a warning, and excluded jointly from all
#' intervals. Fewer than two successful replicates yields missing SE/limits.
#' Intervals describe resampling variability of the criteria; they are not
#' pairwise model-comparison tests or optimism-corrected performance estimates.
#'
#' Bootstrap work uses [oo_pblapply()] when there are at
#' least four repetitions and `n * R * number_of_models` reaches 100,000 on
#' Unix or 1,000,000 on Windows. At most four available cores are used, capped
#' by `getOption("mc.cores", 4L)`. Set `options(mc.cores = 1L)` for serial work.
#' Calls inside a RegR worker remain serial. Per-replicate seeds give identical
#' draws, results and parent RNG state regardless of worker count.
#'
#' @return A list with `obj` (named fitted models; Fine-Gray models are FGR
#'   objects fitted with `variance = FALSE`), `stats` (numeric long table:
#'   `model`, `metric`, `estimate`, `SE`, `lower`, `upper`; one row per model
#'   and selected metric), `boot` (one row per model/replicate with the
#'   selected metrics and `error`), and `info` (model
#'   family, sample/event/parameter counts, full/null log-likelihood, BIC sample
#'   size, omitted-row count, requested/successful bootstrap repetitions,
#'   confidence level and statistical conventions).
#'
#' @examples
#' data(seer_thyroid_mtc_2026, package = "RegR")
#' d <- as.data.frame(seer_thyroid_mtc_2026)
#' d <- d[!is.na(d$time) & d$time > 0, ]
#' models <- list(age = "Age", age_sex = c("Age", "Sex"))
#' res <- get_fit_stats(d, models, surv = TRUE)
#' res$stats
#' \donttest{
#' get_fit_stats(d, models, surv = "DSS")$stats
#' get_fit_stats(d, models, surv = FALSE)$stats
#' set.seed(42)
#' get_fit_stats(d, models, surv = FALSE, R = 200)$stats
#' get_fit_stats(d, models, surv = TRUE, timepoint = c(36, 60),
#'               metrics = c("AUC", "BS", "AIC"))$stats
#' }
#' @seealso [get_score()], [stats::AIC()], [survival::logLik.coxph()]
#' @export
get_fit_stats <- function(data, vars, surv = TRUE, timepoint = seq(2, 200, 2), R = 0,
                          metrics = c("AIC", "BIC", "PVE"),
                          conf_level = 0.95, save = list()) {
  if (!is.data.frame(data) || anyDuplicated(names(data))) {
    stop("`data` must be a data.frame with unique column names.", call. = FALSE)
  }
  requested <- .vars_requested(rlang::enquo(vars), data)
  if (is.list(requested) && !is.data.frame(requested)) {
    model_vars <- lapply(requested, function(x) {
      if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x))) {
        stop("Each element of `vars` must be a nonempty character vector.", call. = FALSE)
      }
      .resolve_vars(data, selected = tidyselect::all_of(x))
      selected
    })
  } else {
    .resolve_vars(data, vars = {{ vars }})
    model_vars <- as.list(vars)
  }
  if (!length(model_vars)) stop("`vars` must select at least one predictor.", call. = FALSE)
  labels <- names(model_vars)
  if (is.null(labels)) labels <- rep("", length(model_vars))
  if (anyNA(labels)) stop("Model names in `vars` cannot be missing.", call. = FALSE)
  auto <- vapply(model_vars, paste, collapse = "_", FUN.VALUE = character(1))
  labels[!nzchar(labels)] <- auto[!nzchar(labels)]
  if (anyDuplicated(labels)) stop("Model names in `vars` must be unique.", call. = FALSE)
  names(model_vars) <- labels

  mode <- if (isTRUE(surv)) "cox" else if (isFALSE(surv)) "crr" else
    if (is.character(surv) && length(surv) == 1L && !is.na(surv) &&
        surv %in% names(data)) "log" else
          stop("`surv` must be TRUE, FALSE or one outcome column name.", call. = FALSE)
  if (is.null(R)) R <- 0L
  if (!is.numeric(R) || length(R) != 1L || !is.finite(R) ||
      R < 0 || R != floor(R) || R > .Machine$integer.max) {
    stop("`R` must be a nonnegative integer.", call. = FALSE)
  }
  R <- as.integer(R)
  if (!is.character(metrics) || !length(metrics) || anyNA(metrics) ||
      anyDuplicated(metrics) || any(!metrics %in% c("AUC", "BS", "AIC", "BIC", "PVE"))) {
    stop("`metrics` must select AUC, BS, AIC, BIC or PVE without duplicates.", call. = FALSE)
  }
  pred <- any(metrics %in% c("AUC", "BS"))
  if (!is.numeric(conf_level) || length(conf_level) != 1L ||
      !is.finite(conf_level) || conf_level <= 0 || conf_level >= 1) {
    stop("`conf_level` must be strictly between 0 and 1.", call. = FALSE)
  }
  allowed <- setdiff(names(formals(save_tb)), "data")
  if (!is.null(save) && (!is.list(save) || (length(save) &&
      (is.null(names(save)) || anyNA(names(save)) || any(!nzchar(names(save))) ||
       anyDuplicated(names(save)) || any(!names(save) %in% allowed))))) {
    stop("`save` must be NULL or a uniquely named list of save_tb fields.", call. = FALSE)
  }
  outcome <- switch(mode, log = surv, cox = "DSS", crr = "event")
  required <- unique(c(unlist(model_vars, use.names = FALSE), outcome,
                       if (mode != "log") "time"))
  if (any(!required %in% names(data))) {
    stop("Missing required columns: ", paste(setdiff(required, names(data)), collapse = ", "),
         call. = FALSE)
  }
  if (outcome %in% unlist(model_vars) || (mode != "log" && "time" %in% unlist(model_vars))) {
    stop("`vars` cannot contain the outcome or survival time.", call. = FALSE)
  }
  d <- as.data.frame(data[, required, drop = FALSE])
  keep <- stats::complete.cases(d)
  n_omitted <- sum(!keep)
  d <- droplevels(d[keep, , drop = FALSE])
  n <- nrow(d)
  if (n < 2L) stop("Fewer than two complete observations.", call. = FALSE)
  if (mode != "log" && (!is.numeric(d$time) || any(!is.finite(d$time) | d$time <= 0))) {
    stop("`time` must contain positive finite numbers.", call. = FALSE)
  }
  y <- d[[outcome]]
  if (mode == "log" && is.factor(y)) {
    if (nlevels(y) != 2L) stop("Logistic outcome must have two levels.", call. = FALSE)
  } else if (!(is.numeric(y) || is.logical(y)) ||
             any(!y %in% if (mode == "crr") 0:2 else 0:1)) {
    stop("Outcome must be coded 0/1 (Cox/Logistic) or 0/1/2 (`event`).", call. = FALSE)
  }
  times <- if (pred && mode != "log") .fit_pred_times(timepoint, d$time)

  # Build formula language from column names, including non-syntactic names.
  formula_env <- new.env(parent = baseenv())
  formula_env$Surv <- survival::Surv
  formula_env$Hist <- prodlim::Hist
  response <- if (mode == "log") as.name(outcome) else
    call(if (mode == "cox") "Surv" else "Hist", as.name("time"), as.name(outcome))
  formulas <- lapply(model_vars, function(x) {
    rhs <- Reduce(function(a, b) call("+", a, b), lapply(x, as.name))
    stats::as.formula(call("~", response, rhs), env = formula_env)
  })
  pred_cache <- new.env(parent = emptyenv())
  fit_one <- function(dd, formula, se = FALSE) {
    yy <- dd[[outcome]]
    if (mode == "log" && length(unique(yy)) != 2L) {
      stop("Logistic outcome must contain both classes.", call. = FALSE)
    }
    if (mode != "log" && !any(yy == 1)) {
      stop("No target event in the analysis sample.", call. = FALSE)
    }
    fit <- withCallingHandlers(switch(mode,
      log = stats::glm(formula, data = dd, family = stats::binomial()),
      cox = survival::coxph(formula, data = dd, x = TRUE, y = TRUE),
      crr = riskRegression::FGR(formula, data = dd, cause = 1, variance = FALSE)
    ), warning = function(w) stop(conditionMessage(w), call. = FALSE))
    .fit_stats_from_fit(fit, dd, mode, outcome, metrics, times, se,
                        pred_cache = pred_cache)
  }
  # Influence-function SEs are only needed without bootstrap percentiles.
  fitted <- lapply(formulas, function(f) fit_one(d, f, se = R < 2L))
  result <- .fit_stats_result(
    fitted, d, function(dd, j) fit_one(dd, formulas[[j]]), R,
    conf_level = conf_level, n_omitted = n_omitted
  )
  if (length(save)) do.call(save_tb, c(list(data = result$stats), save))
  result
}

# Shared extraction for get_fit_stats() and get_score(); never refits a model.
# Returns the selected `metrics`; AUC/BS need `times` for survival models and
# carry influence-function SEs when `se = TRUE`.
.fit_stats_from_fit <- function(fit, data, mode, outcome,
                                metrics = c("AIC", "BIC", "PVE"),
                                times = NULL, se = FALSE, pred_cache = NULL) {
  if (mode == "crr") {
    native <- fit$crrFit
    ll <- native$loglik
    ll0 <- native$loglik.null
    k <- length(native$coef)
    events <- sum(data[[outcome]] == 1)
    # With variance disabled, crr can report convergence for a constant column.
    design <- stats::model.matrix(stats::delete.response(fit$terms), data)
    if (!isTRUE(native$converged) || any(!is.finite(native$coef)) ||
        qr(design)$rank < ncol(design)) {
      stop("Fine-Gray fit is singular or did not converge.", call. = FALSE)
    }
  } else {
    lk <- stats::logLik(fit)
    ll <- as.numeric(lk)
    k <- attr(lk, "df")
    ll0 <- if (mode == "cox") fit$loglik[1L] else
      ll - (fit$null.deviance - fit$deviance) / 2
    events <- if (mode == "cox") fit$nevent else sum(fit$y == 1)
    if (mode == "log" && !isTRUE(fit$converged)) {
      stop("Logistic fit did not converge.", call. = FALSE)
    }
  }
  bic_n <- if (mode == "log") nrow(data) else events
  gain <- ll - ll0
  if (length(ll) != 1L || !all(is.finite(c(ll, ll0, gain))) ||
      gain < -1e-7 * (1 + abs(ll0))) {
    stop("Invalid full/null log-likelihood from the fitted model.", call. = FALSE)
  }
  value <- c(AIC = -2 * ll + 2 * k, BIC = -2 * ll + log(bic_n) * k,
             PVE = -expm1(-2 * max(0, gain) / nrow(data)))
  out <- list(obj = fit, value = value,
              info = data.frame(family = mode, n = nrow(data), events = events, df = k,
                                logLik = ll, logLik_null = ll0, bic_n = bic_n))
  if (any(metrics %in% c("AUC", "BS"))) {
    prepared <- NULL
    if (mode != "log" && !is.null(pred_cache)) {
      # This cache belongs to one public call. A new resample or SE requirement
      # prepares its own censoring weights; models of that sample reuse them.
      if (!identical(pred_cache$data, data) || !identical(pred_cache$se, se)) {
        prepared <- .fit_pred_prepare(data, outcome, times, se)
        pred_cache$data <- data
        pred_cache$se <- se
        pred_cache$prepared <- prepared
      } else prepared <- pred_cache$prepared
    }
    z <- .fit_pred_stats(fit, data, mode, outcome, times, se = se,
                         metrics = intersect(metrics, c("AUC", "BS")),
                         prepared = prepared)
    out$value <- c(value, z$value)
    out$se <- z$se[intersect(names(z$se), metrics)]
  }
  out$value <- out$value[metrics]
  out
}

# Survival AUC/BS evaluation times: sorted, deduplicated and, as in
# riskRegression::Score(), restricted to the observed follow-up.
.fit_pred_times <- function(timepoint, time) {
  if (!is.numeric(timepoint) || !length(timepoint) ||
      any(!is.finite(timepoint) | timepoint <= 0)) {
    stop("`timepoint` must contain positive finite times.", call. = FALSE)
  }
  times <- sort(unique(timepoint))
  times <- times[times <= max(time)]
  if (!length(times)) stop("No `timepoint` within the follow-up.", call. = FALSE)
  times
}

# Shared, model-independent survival preparation for one analysis/resample.
.fit_pred_prepare <- function(data, outcome, times, se) {
  o <- order(data$time)
  tt <- data$time[o]
  ev <- data[[outcome]][o]
  st <- as.numeric(ev != 0)
  km_env <- list2env(list(Hist = prodlim::Hist), parent = baseenv())
  cens <- prodlim::prodlim(stats::as.formula("Hist(time, status) ~ 1", env = km_env),
                           data = data.frame(time = tt, status = st), reverse = TRUE)
  g_minus <- prodlim::predictSurvIndividual(cens, lag = 1)
  g_tau <- as.numeric(stats::predict(cens, times = times, level.chaos = 1,
                                     mode = "matrix", type = "surv"))
  u <- g <- at_risk <- lam <- NULL
  if (se) {
    u <- unique(tt)
    g <- match(tt, u)
    K <- length(u)
    at_risk <- length(tt) - c(0, cumsum(tabulate(g, K)))[seq_len(K)]
    lam <- cumsum(length(tt) * tabulate(g[st == 0], K) / at_risk^2)
  }
  list(order = o, time = tt, event = ev, status = st,
       g_minus = g_minus, g_tau = g_tau, u = u, g = g,
       at_risk = at_risk, lam = lam)
}

# Apparent AUC and Brier score of one fit on its own sample, computed as in
# riskRegression::Score(): reverse Kaplan-Meier IPCW, competing events count as
# controls and tied risks count one half. Survival values average `times`.
# `se = TRUE` adds Score's influence-function SEs (KM censoring term included;
# DeLong for Logistic AUC); survival SEs use the time-averaged influence function.
.fit_pred_stats <- function(fit, data, mode, outcome, times, se = FALSE,
                            metrics = c("AUC", "BS"), prepared = NULL) {
  n <- nrow(data)
  want_auc <- "AUC" %in% metrics
  want_bs <- "BS" %in% metrics
  # sum(w[ref < x]) + sum(w[ref == x]) / 2 for each x
  below <- function(x, ref, w) {
    o <- order(ref)
    ref <- ref[o]
    cw <- c(0, cumsum(w[o]))
    lo <- findInterval(x, ref, left.open = TRUE)
    hi <- findInterval(x, ref)
    cw[lo + 1L] + 0.5 * (cw[hi + 1L] - cw[lo + 1L])
  }
  if (mode == "log") {
    y <- fit$y
    p <- riskRegression::predictRisk(fit, newdata = data)
    value <- se_value <- numeric()
    if (want_auc) {
      cs <- y == 1
      v10 <- below(p[cs], p[!cs], rep(1, sum(!cs))) / sum(!cs)
      value["AUC"] <- mean(v10)
    }
    if (want_bs) {
      res <- (y - p)^2
      value["BS"] <- mean(res)
    }
    if (!se) return(list(value = value))
    if (want_auc) {
      v01 <- 1 - below(p[!cs], p[cs], rep(1, sum(cs))) / sum(cs)
      se_value["AUC"] <- sqrt(stats::var(v10) / sum(cs) + stats::var(v01) / sum(!cs))
    }
    if (want_bs) se_value["BS"] <- stats::sd(res) / sqrt(n)
    return(list(value = value, se = se_value))
  }
  if (is.null(prepared)) prepared <- .fit_pred_prepare(data, outcome, times, se)
  data <- data[prepared$order, , drop = FALSE]
  tt <- prepared$time
  ev <- prepared$event
  st <- prepared$status
  risk <- if (mode == "crr") predictRisk.regr_score_fgr(fit, data, times) else
    riskRegression::predictRisk(fit, newdata = data, times = times)
  g_minus <- prepared$g_minus
  g_tau <- prepared$g_tau
  # Kaplan-Meier censoring martingale terms, following riskRegression's C++.
  u <- prepared$u
  g <- prepared$g
  K <- length(u)
  at_risk <- prepared$at_risk
  lam <- prepared$lam
  km_term <- function(v, before, after, f) {
    a <- rowsum(v * before, g, reorder = TRUE)[, 1]
    -cumsum(a * c(0, lam[-K]))[g] + f * (sum(a) - cumsum(a)[g]) + f * sum(v[after])
  }
  auc <- bs <- rep(NA_real_, length(times))
  if_auc <- if_bs <- numeric(n)
  for (k in seq_along(times)) {
    tau <- times[k]
    r <- risk[, k]
    case <- tt <= tau & ev == 1
    before <- tt <= tau & st == 1
    after <- tt > tau
    w <- numeric(n)
    w[before] <- 1 / g_minus[before]
    w[after] <- 1 / g_tau[k]
    if (want_bs) {
      res <- w * (case - r)^2
      bs[k] <- mean(res)
    }
    if (want_auc) {
      ctrl <- tt > tau | (tt <= tau & ev == 2)
      v <- numeric(n)
      v[case] <- w[case] * below(r[case], r[ctrl], w[ctrl])
      mu_case <- sum(w[case])
      mu_ctrl <- sum(w[ctrl])
      auc[k] <- sum(v[case]) / (mu_case * mu_ctrl)
    }
    if (!se) next
    # Control-side rank sums enter only the influence function.
    if (want_auc) v[ctrl] <- w[ctrl] * (mu_case - below(r[ctrl], r[case], w[case]))
    h <- findInterval(tau, u)
    f <- ifelse(tt <= tau, n * (st == 0) / at_risk[g] - lam[g],
                -if (h == 0L) 0 else lam[h])
    if (want_bs) if_bs <- if_bs + res - bs[k] + km_term(res, before, after, f) / n
    if (want_auc && is.finite(auc[k])) {
      mu <- mu_case * mu_ctrl / n^2
      nu <- auc[k] * mu
      dv <- ifelse(case, w * mu_ctrl, ifelse(ctrl, w * mu_case, 0))
      ic <- v / n * mu - dv / n * nu
      # Score treats the censoring weights as known at the last follow-up time.
      if (tau < max(tt)) {
        ic <- ic + (km_term(v, before, after, f) * mu - km_term(dv, before, after, f) * nu) / n^2
      }
      if_auc <- if_auc + ic / mu^2
    }
  }
  ok <- is.finite(auc)
  if (want_auc && !any(ok)) stop("AUC is undefined at every `timepoint`.", call. = FALSE)
  value <- se_value <- numeric()
  if (want_auc) value["AUC"] <- mean(auc[ok])
  if (want_bs) value["BS"] <- mean(bs)
  if (!se) return(list(value = value))
  if (want_auc) se_value["AUC"] <- stats::sd(if_auc / sum(ok)) / sqrt(n)
  if (want_bs) se_value["BS"] <- stats::sd(if_bs / length(times)) / sqrt(n)
  list(value = value, se = se_value)
}

# Assemble paired intervals either from supplied Score refits or one bootstrap.
# Without resampling, metrics with an influence-function SE get Wald limits.
.fit_stats_result <- function(fitted, data, fit_one, R, conf_level = 0.95,
                              n_omitted = 0L, boot = NULL, n_cores = NULL) {
  labels <- names(fitted)
  metrics <- names(fitted[[1]]$value)
  n <- nrow(data)
  supplied_boot <- !is.null(boot)
  if (is.null(boot)) {
    boot <- data.frame(model = character(), replicate = integer(),
                       stats::setNames(rep(list(numeric()), length(metrics)), metrics),
                       error = character())
  }
  if (R >= 2L && !supplied_boot) {
    boot_one <- function(b) {
      dd <- data[sample.int(n, n, replace = TRUE), , drop = FALSE]
      rows <- lapply(seq_along(fitted), function(j) {
        z <- tryCatch(fit_one(dd, j)$value, error = function(e) e)
        failed <- inherits(z, "error")
        data.frame(
          model = labels[j], replicate = b,
          as.list(if (failed) stats::setNames(rep(NA_real_, length(metrics)), metrics) else z),
          error = if (failed) conditionMessage(z) else NA_character_)
      })
      do.call(rbind, rows)
    }
    cores <- if (is.null(n_cores))
      min(4L, oo_cores(R, work = as.double(n) * R * length(fitted))) else
      oo_cores(R, n_cores = n_cores)
    boot_rows <- oo_pblapply(seq_len(R), boot_one, n_cores = cores, seed = TRUE)
    boot <- do.call(rbind, boot_rows)
  }
  if (any(!is.na(boot$error))) {
    warning(sum(!is.na(boot$error)), " bootstrap model fits failed; see `boot$error`.",
            call. = FALSE)
  }
  crit <- stats::qnorm((1 + conf_level) / 2)
  tables <- lapply(seq_along(fitted), function(j) {
    est <- fitted[[j]]$value
    draws <- boot[boot$model == labels[j] & is.na(boot$error), metrics, drop = FALSE]
    se <- lower <- upper <- stats::setNames(rep(NA_real_, length(metrics)), metrics)
    for (m in metrics) {
      x <- draws[[m]][is.finite(draws[[m]])]
      if (length(x) >= 2L) {
        se[m] <- stats::sd(x)
        ci <- stats::quantile(x, c((1 - conf_level) / 2, (1 + conf_level) / 2), names = FALSE)
        lower[m] <- ci[1]
        upper[m] <- ci[2]
      }
    }
    k <- names(fitted[[j]]$se)
    if (R < 2L && length(k)) {
      se[k] <- fitted[[j]]$se
      lower[k] <- pmax(0, est[k] - crit * se[k])
      upper[k] <- pmin(1, est[k] + crit * se[k])
    }
    data.frame(model = labels[j], metric = metrics,
                estimate = unname(est), SE = unname(se),
                lower = unname(lower), upper = unname(upper))
  })
  info <- do.call(rbind, lapply(seq_along(fitted), function(j) {
    cbind(model = labels[j], fitted[[j]]$info, n_omitted = n_omitted,
          R = R, R_success = sum(boot$model == labels[j] & is.na(boot$error)),
          conf_level = conf_level, PVE_method = "Cox-Snell",
          BIC_basis = if (fitted[[j]]$info$family == "log") "subjects" else "target events")
  }))
  list(obj = lapply(fitted, `[[`, "obj"), stats = do.call(rbind, tables),
       boot = boot, info = info)
}
