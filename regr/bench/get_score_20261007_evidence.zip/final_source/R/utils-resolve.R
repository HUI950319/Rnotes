# =============================================================================
# utils-resolve.R -- Shared input-resolution helpers
# =============================================================================
#
# Internal helpers that normalise flexible user input into concrete objects,
# shared across the plot functions (cat-plt.R, facet-get.R, rcs-all.R, ...).
# UtilsR carries a mirrored copy of the first two so it can use them without
# depending on RegR.
#
# Architecture (1 layer, no public API):
#
#   L2  .resolve_theme(theme_use)        NULL | name | function | theme
#                                        -> ggplot2 theme
#       .resolve_color(palette, n, ...)  NULL | name | colour(s)
#                                        -> hex colour vector
#       .resolve_vars(data, ..., .env)   NSE tidyselect -> character
#                                        vectors, assigned into the caller
#       .resolve_adj_var(data, adj_var)  drop covariates with missing values
#                                        or a single unique value
#       .merge_named_arg(x, defaults)    named list -> unknown and duplicate
#                                        fields rejected, then merged over
#                                        the documented defaults
#
# .resolve_theme / .resolve_color were merged from the former utils-theme.R
# and utils-color.R; .resolve_vars / .resolve_adj_var were added later in
# the same style. .merge_named_arg moved in from cat-plt.R, which defines
# only the `*_arg` wrappers that sit on top of it.
# =============================================================================

# ---- .resolve_theme --------------------------------------------------------

#' Resolve `theme_use` input to a ggplot2 theme object
#'
#' Mirrors the `scMMR::DimPlot2` / `RegR::get_rcs` `theme_use` design.
#' Accepts:
#' \itemize{
#'   \item `NULL` (default) -- uses [UtilsR::theme_km] when available; else
#'         [ggplot2::theme_bw()].
#'   \item character -- function name resolved by [match.fun()] /
#'         `utils::getFromNamespace(., "UtilsR")` (e.g. `"theme_my"`).
#'   \item function returning a theme -- called with no arguments.
#'   \item theme object -- used directly.
#' }
#'
#' @param theme_use NULL / character / function / theme object.
#' @return A `ggplot2::theme` object.
#' @keywords internal
#' @noRd
.resolve_theme <- function(theme_use) {
  if (is.null(theme_use)) {
    if (requireNamespace("UtilsR", quietly = TRUE)) {
      thm <- tryCatch(UtilsR::theme_km, error = function(e) NULL)
      if (!is.null(thm)) {
        if (inherits(thm, "theme")) return(thm)
        if (is.function(thm))       return(thm())
      }
    }
    return(ggplot2::theme_bw())
  }
  if (is.character(theme_use)) {
    fn <- tryCatch(match.fun(theme_use), error = function(e) NULL)
    if (is.null(fn) && requireNamespace("UtilsR", quietly = TRUE))
      fn <- tryCatch(utils::getFromNamespace(theme_use, "UtilsR"),
                     error = function(e) NULL)
    if (is.null(fn))
      stop(sprintf("Theme '%s' not found", theme_use), call. = FALSE)
    if (inherits(fn, "theme")) return(fn)
    return(fn())
  }
  if (inherits(theme_use, "theme")) return(theme_use)
  if (is.function(theme_use))       return(theme_use())
  stop("'theme_use' must be NULL, character, function, or theme object",
       call. = FALSE)
}


# ---- .resolve_color --------------------------------------------------------
#
# Centralises the "palette name OR colour vector" resolution used by plot
# functions, so callers can interchangeably pass:
#
#   palette = NULL                          # default
#   palette = "lancet"                      # registered name -> pal_get
#   palette = "Reds"                        # registered name -> pal_get
#   palette = "red"                         # literal single colour -> recycled
#   palette = c("#ff0000", "#0000ff", ...)  # literal colour vector  -> as-is
#
# Built on top of `UtilsR::pal_get()` (256-palette registry) with literal
# colour fallback when `pal_get` errors (unknown name -> treated as a
# literal colour, e.g. "red", "#ABC123").

#' Resolve a colour specification to a hex colour vector
#'
#' @param palette NULL, a registered palette name (resolved via
#'   [UtilsR::pal_get()]), a single literal colour, or a character vector of
#'   colours. Unknown single-string inputs are treated as literal colours and
#'   recycled.
#' @param n Optional integer. If supplied, the returned vector is sized to
#'   exactly `n` colours: for registered palettes `pal_get(palette, n = n)`
#'   handles recycling / interpolation; for literal vectors `rep_len()` is
#'   used. `NULL` (default) returns the palette at its natural length.
#' @param default Fallback colour vector when `palette = NULL`. Defaults to
#'   [UtilsR::pal_lancet].
#'
#' @return A character vector of hex colours.
#' @keywords internal
#' @noRd
.resolve_color <- function(palette = NULL, n = NULL,
                            default = UtilsR::pal_lancet) {

  # NULL -> default (optionally sized to n)
  if (is.null(palette)) {
    out <- as.character(default)
    if (!is.null(n)) out <- rep_len(out, n)
    return(out)
  }

  # Single string: try registered palette, fall back to literal colour.
  # `pal_get` emits its own "Did you mean…" cli message; suppress that and
  # emit our own consolidated hint instead -- but only when the input doesn't
  # already look like a literal colour (hex / named R colour), so callers
  # passing `"red"` / `"#FF0000"` stay silent.
  if (length(palette) == 1L && is.character(palette)) {
    return(tryCatch(
      suppressMessages(as.character(UtilsR::pal_get(palette, n = n))),
      error = function(e) {
        is_hex   <- grepl("^#", palette)
        is_named <- tolower(palette) %in% tolower(grDevices::colors())
        if (!is_hex && !is_named) {
          pl_names <- tryCatch(
            names(getExportedValue("UtilsR", "palette_list")),
            error = function(e2) character(0)
          )
          if (length(pl_names) > 0L) {
            cli::cli_inform(c(
              "i" = "Palette {.val {palette}} not in registry; using as literal colour.",
              "*" = "{length(pl_names)} palettes available. Examples: {.val {head(pl_names, 8)}}",
              "*" = "Browse with {.code UtilsR::pal_list()} or visualise with {.code UtilsR::pal_show()}."
            ))
          }
        }
        v <- as.character(palette)
        if (!is.null(n)) rep_len(v, n) else v
      }
    ))
  }

  # Multi-element vector: use as-is (sized to n if requested)
  out <- as.character(palette)
  if (!is.null(n)) out <- rep_len(out, n)
  out
}


.is_selection_expr <- function(expr, columns = character()) {
  if (rlang::is_symbol(expr)) return(rlang::as_name(expr) %in% columns)
  if (!is.call(expr)) return(FALSE)
  if (isTRUE(rlang::call_name(expr) %in% c("all_of", "any_of"))) return(TRUE)
  any(vapply(as.list(expr)[-1L], .is_selection_expr, logical(1L), columns = columns))
}

# The models a `vars` argument asks for (get_fit_stats() / get_score()): a
# list of column selections, or NULL for one selection that the caller
# resolves itself. A top-level `list()` resolves each model's selector in its
# own selection context, so `list(Base = all_of(a))` stays inside tidyselect.
# A named character vector becomes one single-predictor model per element,
# its names labelling the models (tidyselect would read them as renames),
# also inside all_of() / any_of().
.vars_requested <- function(vars_quo, data) {
  expr <- rlang::quo_get_expr(vars_quo)
  if (rlang::is_call(expr, "list")) {
    env <- rlang::quo_get_env(vars_quo)
    return(lapply(rlang::call_args(expr), function(e) {
      .resolve_vars(data, selected = !!rlang::new_quosure(e, env))
      selected
    }))
  }
  if (.is_selection_expr(expr)) {
    pos <- tryCatch(tidyselect::eval_select(vars_quo, data), error = function(e) NULL)
    if (is.null(pos) || identical(names(pos), names(data)[pos])) return(NULL)
    return(as.list(stats::setNames(names(data)[pos], names(pos))))
  }
  val <- tryCatch(rlang::eval_tidy(vars_quo), error = function(e) NULL)
  if (is.character(val) && !is.null(names(val))) as.list(val) else val
}

# ---- .resolve_vars ---------------------------------------------------------
#
# Thin wrapper over `cards::process_selectors()`: resolve one or more NSE
# tidyselect expressions to character column vectors and assign them back into
# the CALLER's environment (side-effect API, matching the existing
# process_selectors idiom in compare-gtsummary.R / facet-get.R /
# get-psm-iptw.R). The only nuance over calling process_selectors directly is
# `env`: process_selectors assigns into *its* caller, which would be this
# wrapper's own frame -- so we forward `.env = caller_env()` to target the real
# caller (e.g. get_rcs). A selector that already evaluates to a character
# vector (the common `adj_var = <vector>` case) is pre-wrapped in `all_of()`
# so it does not trip tidyselect's "external vector" deprecation while staying
# strict; a bare symbol naming a column is left untouched so tidyselect's
# column-first semantics win over a same-named object in scope, while other
# bare names / helpers (starts_with / where / c(Age, Sex)) are not
# standalone-evaluable and pass through untouched. Unknown columns raise
# tidyselect's strict cli error. An empty selection (NULL input, or a helper
# that matched nothing) is normalised back to NULL -- NOT character(0) -- so
# downstream `is.null(adj_var)` / `is.null(sub_var)` branches keep working.

#' Resolve NSE selectors to column names, assigning into the caller's env
#'
#' @param data A data.frame.
#' @param ... Named tidyselect expressions (forward function args with `{{ }}`).
#'   Each name becomes a character vector assigned into `.env`. Supports bare
#'   names, strings, `c()`, and helpers (`starts_with()`, `where()`, `!`, `:`).
#'   An empty result (including `NULL` input) is assigned as `NULL`, not
#'   `character(0)`, so downstream `is.null()` checks behave. Selectors must be
#'   named, and the names `data` / `env` are reserved (they collide with
#'   `cards::process_selectors()` formals), so do not use them as selector
#'   names.
#' @param .env Environment to assign the resolved vectors into. Defaults to the
#'   caller of `.resolve_vars()`.
#' @return Invisibly `NULL`; called for its side effect.
#' @keywords internal
#' @noRd
.resolve_vars <- function(data, ..., .env = rlang::caller_env()) {
  if (!is.data.frame(data))
    cli::cli_abort("{.arg data} 必须是 data.frame。")

  quos <- rlang::enquos(...)

  # 0.selector 必须具名，且名字不能与 process_selectors 形参（data / env）冲突：
  #   未具名会 assign 到空名；data/env 冲突则 inject() 会抛出难懂的
  #   "matched by multiple actual arguments"，而非可操作的报错。
  nms <- names(quos)
  if (length(quos) && (is.null(nms) || any(!nzchar(nms))))
    cli::cli_abort(c(
      "传给 {.fn .resolve_vars} 的每个 selector 都必须具名。",
      "i" = "例如写 {.code adj_var = Age}，而不是裸的 {.code Age}。"
    ))
  reserved <- intersect(nms, c("data", "env"))
  if (length(reserved))
    cli::cli_abort(c(
      "selector 名 {.val {reserved}} 为保留名。",
      "i" = "它与 {.fn cards::process_selectors} 形参冲突，请改名后再传入 {.fn .resolve_vars}。"
    ))

  # 1.提前包裹字符向量到 all_of，兼容 select-helper 与裸名；
  #   裸符号若正好是 data 的列名则原样保留，让 tidyselect 的“列优先”语义
  #   胜过作用域里的同名对象（避免环境变量遮蔽列名）。
  quos <- lapply(quos, function(q) {
    expr <- rlang::quo_get_expr(q)
    if (.is_selection_expr(expr, names(data))) return(q)
    val <- tryCatch(rlang::eval_tidy(q), error = function(e) NULL)
    if (is.character(val)) rlang::quo(tidyselect::all_of(!!val)) else q
  })
  # 2.将解析结果 assign 到调用 .resolve_vars 的环境
  rlang::inject(cards::process_selectors(data, !!!quos, env = .env))
  # 3.将 character(0)（即没有选中任何变量的selector）标准化为NULL
  for (nm in nms) {
    if (rlang::env_has(.env, nm) && length(rlang::env_get(.env, nm)) == 0L)
      rlang::env_poke(.env, nm, NULL)
  }
  invisible(NULL)
}


# ---- .resolve_adj_var ------------------------------------------------------
#
# Prune an adjustment-variable vector down to the covariates a regression can
# actually use: drop any variable that (a) contains missing values, or (b) has
# a single unique value (a constant -- no variation, which a model would drop
# or choke on as a singularity). Names absent from `data` are dropped too.
# Unlike `check_adj()` (which coerces char -> factor, drops unused factor
# levels, and returns the *modified data* plus a detailed `removed` list), this
# is a lightweight NAME filter: it takes an already-resolved character vector
# and returns the usable subset, leaving `data` untouched. Typically used right
# after `.resolve_vars()` when only the adj list needs cleaning, not the data.

#' Drop unusable adjustment variables (missing values / single unique value)
#'
#' Returns the subset of `adj_var` usable as model covariates, dropping any
#' variable that:
#' \itemize{
#'   \item is not a column of `data`,
#'   \item contains missing values (`anyNA()` is `TRUE`), or
#'   \item has a single unique value (constant; `<= 1` distinct non-NA value).
#' }
#' NA-bearing variables are reported under "missing values" even when they are
#' also constant (an all-`NA` column is both), so each dropped variable appears
#' once.
#'
#' @param data A data.frame.
#' @param adj_var Character vector of adjustment-variable names, or `NULL`.
#' @param verbose Logical. Emit a styled `.cat_message()` summary of what was
#'   dropped (only when something is dropped). Default `TRUE`.
#'
#' @return A character vector of retained variable names, or `NULL` when
#'   `adj_var` is `NULL` / empty or nothing survives -- so downstream
#'   `is.null(adj_var)` branches keep working.
#' @keywords internal
#' @noRd
.resolve_adj_var <- function(data, adj_var, verbose = TRUE) {
  if (!is.data.frame(data))
    cli::cli_abort("{.arg data} must be a data frame.")
  if (is.null(adj_var) || length(adj_var) == 0L) return(NULL)
  if (!is.character(adj_var))
    cli::cli_abort("{.arg adj_var} must be a character vector or {.code NULL}.")

  # Names absent from `data` cannot be evaluated -> drop.
  not_in_data <- adj_var[!adj_var %in% names(data)]
  cand        <- adj_var[adj_var %in% names(data)]

  # (a) any missing value -> drop. Classify NA-bearing vars here first so an
  # all-NA column is not also reported as "constant".
  has_na  <- vapply(cand, function(v) anyNA(data[[v]]), logical(1))
  drop_na <- cand[has_na]

  # (b) among the NA-free columns, a single unique value -> drop (constant).
  rest       <- cand[!has_na]
  n_uniq     <- vapply(rest, function(v) length(unique(data[[v]])), integer(1))
  drop_const <- rest[n_uniq <= 1L]
  keep       <- rest[n_uniq >  1L]

  if (verbose && length(c(not_in_data, drop_na, drop_const))) {
    msg <- c(
      sprintf("adj_var: %d input -> %d retained (%d dropped)",
              length(adj_var), length(keep), length(adj_var) - length(keep)),
      if (length(not_in_data)) sprintf("not in data: %s", toString(not_in_data)),
      if (length(drop_na))     sprintf("missing values: %s", toString(drop_na)),
      if (length(drop_const))  sprintf("single unique value: %s", toString(drop_const))
    )
    .cat_message(paste(msg, collapse = "\n"), type = "info")
  }

  if (length(keep) == 0L) NULL else keep
}

# ---- .merge_named_arg ------------------------------------------------------

# Validate a fully named list argument and merge it over `defaults`. Unnamed,
# duplicated and unknown fields are rejected before the merge, mirroring the
# `com.args` / `abs_args` handling elsewhere in the package. `allowed` widens
# the accepted field set beyond `names(defaults)` for lists that also forward
# undefaulted fields to another package (see `plt_cat3(risk_table_args = )`).
#' @keywords internal
.merge_named_arg <- function(x, defaults, arg_name,
                             allowed = names(defaults)) {
  if (is.null(x) || (is.list(x) && length(x) == 0L)) return(defaults)
  if (!is.list(x) || is.data.frame(x))
    stop(sprintf("`%s` must be `NULL` or a named list.", arg_name),
         call. = FALSE)
  nms <- names(x)
  if (is.null(nms) || anyNA(nms) || any(!nzchar(nms)))
    stop(sprintf("`%s` must be a fully named list.", arg_name), call. = FALSE)
  dups <- unique(nms[duplicated(nms)])
  if (length(dups))
    stop(sprintf("`%s` contains duplicated field(s): %s.", arg_name,
                 paste0("`", dups, "`", collapse = ", ")), call. = FALSE)
  unknown <- setdiff(nms, allowed)
  if (length(unknown))
    stop(sprintf(
      "`%s` contains unknown field(s): %s. Allowed fields are: %s.",
      arg_name, paste0("`", unknown, "`", collapse = ", "),
      paste0("`", allowed, "`", collapse = ", ")), call. = FALSE)
  utils::modifyList(defaults, x, keep.null = TRUE)
}
