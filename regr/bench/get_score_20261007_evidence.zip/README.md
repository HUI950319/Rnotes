# get_score 2026-10-07 evidence

The cross_platform directory is the matched-source OS benchmark before these optimizations.
The optimizations directory keeps each three-pair comparison separate, with source snapshots,
input/source hashes and sessionInfo. The mixed-model chunk timings and iid/scaling probes
are rejected-candidate evidence, not final implementation results.

No row-level input or prediction results are distributed here. Generate the fixed input with
cross_platform/prepare.R from RegR's built-in seer_thyroid_mtc_2026 data; expected input MD5:
8fe0d0d78cc916d25aafd83bb5ece091. Run prepare.R with the output directory as its first argument.
Place compare-step.R and the step*-before-*.R files in that output directory. Example:
Rscript compare-step.R <outdir> step3 cox 10000 0 1 plain full
Rscript compare-step.R <outdir> step5 cox 1000 100 4 plain full

Scripts retain E:/Rpackage/RegR or /mnt/e/Rpackage/RegR as root; adjust that constant elsewhere.
Use final_source/R for the optimized revision and the saved snapshots for the relevant baseline;
do not silently compare with a later installed/source version. BLAS/OpenMP/data.table threads
are one, mc.cores is four. Each timed call has a 180-second limit; use terminable child processes.
Rendering this web page does not rerun benchmarks. optimization-results.md documents warmup,
return/RNG agreement, unchanged full-suite baseline failures, and scope limits.
