args <- commandArgs(TRUE)
outdir <- args[[1L]]
x <- read.csv(file.path(outdir, "comparison.csv"), stringsAsFactors = FALSE)
v <- read.csv(file.path(outdir, "validation.csv"), stringsAsFactors = FALSE)
r <- read.csv(file.path(outdir, "timings.csv"), stringsAsFactors = FALSE)
label <- c(logistic = "Logistic", cox = "Cox", finegray = "Fine–Gray")
fmt <- function(z) sprintf("%.3f", z)
table_rows <- function(d, show_cores = FALSE) {
 d <- d[order(match(d[["mode"]], names(label)), d[["cores"]]), ]
 vapply(seq_len(nrow(d)), function(i) {
  z <- d[i, ]
  paste0("| ", label[[z[["mode"]]]], if (show_cores) paste0(" | ", z[["cores"]]) else "", " | ",
   fmt(z[["wsl_median_s"]]), " [", fmt(z[["wsl_min_s"]]), "–", fmt(z[["wsl_max_s"]]), "] | ",
   fmt(z[["windows_median_s"]]), " [", fmt(z[["windows_min_s"]]), "–", fmt(z[["windows_max_s"]]), "] | ",
   sprintf("%.2f×", z[["windows_over_wsl"]]), " |")
 }, character(1))
}
a <- x[x[["R"]] == 0L, ]
b <- x[x[["R"]] == 100L, ]
core_gain <- do.call(rbind, lapply(names(label), function(m) {
 s <- b[b[["mode"]] == m & b[["cores"]] == 1L, ]
 p <- b[b[["mode"]] == m & b[["cores"]] == 4L, ]
 data.frame(mode = m, wsl_4_over_1 = p[["wsl_median_s"]]/s[["wsl_median_s"]], windows_4_over_1 = p[["windows_median_s"]]/s[["windows_median_s"]])
}))
write.csv(core_gain, file.path(outdir, "parallel-comparison.csv"), row.names = FALSE)
lines <- c(
 "# get_score() 在 WSL 与 Windows 的性能评估", "", "实测日期：2026-10-07。",
 "", "本轮覆盖当前 `RegR::get_score()` 的 Logistic、Cox、Fine–Gray 三个分支。计时包括拟合、评分、置信区间、汇总表、flextable 和绘图对象构造；排除主进程读取数据、加载包、预热、计时前 GC、保存结果和实际图形渲染。",
 "", "所有表格是三次交替运行的**中位数 [最小–最大]，单位秒**。Windows/WSL 是两个中位数之比，大于1表示 Windows 更慢；耗时范围不是统计置信区间。",
 "", "## 无 bootstrap：1万行，单进程", "",
 "| 模型 | WSL | Windows | Windows/WSL |", "|:--|--:|--:|--:|", table_rows(a),
 "", "## 100次 bootstrap：1000行", "",
 "| 模型 | 进程数 | WSL | Windows | Windows/WSL |", "|:--|--:|--:|--:|--:|", table_rows(b, TRUE),
 "", "## 并行的实际收益", "",
 "下表是同一系统内4进程耗时 / 1进程耗时；小于1表示4进程更快。进程启动、包加载、传输和收集均属于函数调用耗时，完整保留在计时中。",
 "", "| 模型 | WSL：4/1进程 | Windows：4/1进程 |", "|:--|--:|--:|",
 vapply(seq_len(nrow(core_gain)), function(i) paste0("| ", label[[core_gain[["mode"]][i]]], " | ", sprintf("%.2f×", core_gain[["wsl_4_over_1"]][i]), " | ", sprintf("%.2f×", core_gain[["windows_4_over_1"]][i]), " |"), character(1)),
 "", "当前源码使用 Unix fork 和 Windows PSOCK 后端。上述 Windows 强制并行的额外耗时与其新建进程、加载命名空间和序列化传输的执行方式相符；本轮未单独分解这些开销，不能给每项分配精确占比。",
 "", "默认 AUC_score/BS_score 的 bootstrap 路径中，`score_args$n_cores = NULL` 在 Windows 保持单进程，在本轮 WSL 工作量下选择最多4进程。正式表格分别显式指定 `1L` 和 `4L`，便于把并行配置与环境差异区分开。一万个观察、一个联合模型、R=0 时没有模型间并行。",
 "", "这些结果支持本轮小至中等规模下 Windows 使用默认自适应设置或显式 `n_cores = 1L`。WSL 的生存 bootstrap 是否采用4进程，应参考上表；Logistic 的轻量任务没有相同的并行收益。结果不外推到更多模型、其他样本量、更多预测变量、不同时间网格或其他机器。",
 "", "## 复现条件", "",
 "| 项目 | 设置 |", "|:--|:--|",
 "| 源码 | RegR 0.1.3；提交 `0af26ef88b916a51ea25f304453e5eaa227bb0af`；工作树起始检查干净 |",
 "| 硬件 | 同一台 Intel Core Ultra 9 275HX，24个逻辑CPU；保留已有 RStudio/MCP 会话；本轮重型计时之间串行调度 |",
 "| 系统/R | WSL2 Ubuntu 22.04、Linux 6.6.87.2；Windows 11 build 26200；均为 R 4.4.3 |",
 "| 相同主要依赖 | riskRegression 2026.3.11、survival 3.8.12、prodlim 2026.3.11、cmprsk 2.2.12、mets 1.3.13、ggplot2 4.0.3、UtilsR 0.6.8 |",
 "| 仍有差异的依赖 | WSL/Windows：data.table 1.17.8/1.18.2.1；parallelly 1.38.0/1.47.0；flextable 0.9.10/0.9.9；其余完整版本见环境记录 |",
 "| BLAS | WSL 为 OpenBLAS pthread；Windows 为该 R 发行版的 BLAS。运行前默认 BLAS 线程分别为24/1；**主表全部限制为1线程** |",
 "| 线程/进程 | BLAS、OpenMP、MKL、data.table 均1线程；`mc.cores = 4L`；指定1或4个进程，避免嵌套线程争抢 |",
 "| 数据 | RegR 自带 `seer_thyroid_mtc_2026`；time/DSS/event/Age/Sex/Race 共同完整且 time>0 的4387行 |",
 "| 抽样 | 种子20261007，有放回扩展为1万行；1000行是同一输入的前1000行；两个系统读取同一 `input.rds` |",
 "| 模型 | `vars = list(full = c(\"Age\", \"Sex\", \"Race\"))`，一个联合模型 |",
 "| 分支 | Logistic：surv=\"DSS\"；Cox：surv=TRUE；Fine–Gray：surv=FALSE，cause=1，沿用源码 variance=FALSE |",
 "| 指标/网格 | 默认 AUC_score/BS_score；timepoint=seq(2,200,2)，100个时点；score_args$plots=\"auto\" |",
 "| 重采样 | R=0 或100；每次正式调用前设种子20261008 |",
 "| 预热/顺序 | 各独立子进程用300行预热；每格重复3次，系统顺序 WSL→Windows、Windows→WSL、WSL→Windows |",
 "| 超时 | 计时调用180秒上限；可终止子进程，另设加载/清理的总保护上限；正式条件均完成 |",
 "", "这是当前两套实际环境的比较，BLAS 实现和少量依赖版本不同，不能把全部耗时差异归因于操作系统。原始默认24线程/默认data.table线程的组合未另外计时，因此表内绝对时间对应明确限定的线程条件。",
 "", "扩展行数只用于计算性能测试，不代表新增独立患者；这些结果不用于扩大队列后的统计推断。",
 "", "## 一致性与状态", "",
 paste0("正式调用 ", nrow(r), " 次全部成功，无评分警告；所有 R=100 条件保留100个有效 bootstrap replicate。"),
 paste0("完成 ", nrow(v), " 组比较：27组跨系统、18组同系统1/4进程。评分表中的 AUC/Brier、标准误与区间在1e-8容差内一致，最大绝对差为 ", format(max(v[["max_abs_diff"]]), digits = 8, scientific = TRUE), "；格式化汇总、返回字段/类别和最终随机数状态均一致。"),
 "", "两边加载路径、主要依赖版本和已安装函数 body/formals 已检查；目标源码及数据哈希固定。主计时没有修改 RegR 源码或安装包。图形/flextable 对象的实际渲染和字体差异未纳入数值比较。",
 "", "脚本准备阶段遇到的记录/字符编码错误已修正，失败调用未纳入正式统计；两个有效 WSL Logistic bootstrap 计时按原输入、源码、种子和线程条件保留。",
 "", "## 结果与复现文件", "",
 "- [完整逐次耗时](timings.csv)、[中位数与范围](summary.csv)、[跨系统比较](comparison.csv)、[并行收益](parallel-comparison.csv)。",
 "- [数值与随机数一致性](validation.csv)、[固定输入与参数](metadata.R)。",
 "- [WSL 环境](env-wsl.txt)、[Windows 环境](env-windows.txt)、[源码 SHA-256](source-sha256.csv)、[驱动 SHA-256](driver-sha256.csv)。",
 "- `prepare.R` 生成固定输入；`benchmark-cell.R` 执行一个条件；`run-benchmark.ps1` 用 PowerShell 7 串行安排三轮；`analyze.R` 校验及汇总；`write-report.R` 生成此报告。",
 "", "主驱动复用已完成且有效的单格 CSV，不覆盖已验证计时。重新复现可在新的系统临时目录放置相同脚本、修改驱动的目录常量，再执行 prepare.R 与主驱动。"
)
writeLines(enc2utf8(lines), file.path(outdir, "report.md"), useBytes = TRUE)
cat("REPORT_WRITTEN\n")


