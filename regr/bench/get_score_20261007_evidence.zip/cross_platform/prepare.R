args <- commandArgs(TRUE)
outdir <- args[[1L]]
root <- if (.Platform$OS.type == "windows") "E:/Rpackage/RegR" else "/mnt/e/Rpackage/RegR"
e <- new.env()
load(file.path(root, "data/seer_thyroid_mtc_2026.rda"), e)
raw <- as.data.frame(e[["seer_thyroid_mtc_2026"]])
required <- c("time", "DSS", "event", "Age", "Sex", "Race")
d <- droplevels(raw[complete.cases(raw[required]) & raw[["time"]] > 0, required])
set.seed(20261007)
bench <- d[sample.int(nrow(d), 10000L, replace = TRUE), , drop = FALSE]
rownames(bench) <- NULL
saveRDS(bench, file.path(outdir, "input.rds"), version = 3L)
metadata <- list(seed = 20261007L, source_n = nrow(raw), complete_n = nrow(d),
 model = "one joint Age + Sex + Race model", metrics = c("AUC_score", "BS_score"),
 timepoint = seq(2, 200, 2), plots = "auto", timing = "full get_score, excluding package/data loading, warmup, prior gc, rendering and result saving",
 source_hashes = tools::md5sum(file.path(root, c("R/msr-riskRegression.R", "R/msr-fit-stats.R", "R/utils-parallel.R", "R/utils-resolve.R", "data/seer_thyroid_mtc_2026.rda"))),
 input_md5 = unname(tools::md5sum(file.path(outdir, "input.rds"))),
 bootstrap_seed = 20261008L, threads = 1L, repeats = 3L,
 per_call_timeout_s = 180L, child_timeout_s = 240L)
dput(metadata, file.path(outdir, "metadata.R"))
for (n in c(300L, 1000L, 10000L)) {
 x <- bench[seq_len(n), , drop = FALSE]
 cat("DATA", n, "DSS", sum(x[["DSS"]] == 1), "CR_EVENT", sum(x[["event"]] == 1), "COMPETING", sum(x[["event"]] == 2), "ATRISK200", sum(x[["time"]] >= 200), "\n")
}
