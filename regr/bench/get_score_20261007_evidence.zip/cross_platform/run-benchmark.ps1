$ErrorActionPreference = 'Stop'
$taskDir = 'C:\Users\ouyan\AppData\Local\Temp\get-score-os-20261007-af1a05ac'
$taskWslDir = '/mnt/c/Users/ouyan/AppData/Local/Temp/get-score-os-20261007-af1a05ac'
$taskFailed = [System.Collections.Generic.HashSet[string]]::new()
$taskStatuses = [System.Collections.Generic.List[object]]::new()
$taskConditions = @()
foreach ($taskMode in @('logistic','cox','finegray')) {
  $taskConditions += [pscustomobject]@{ Mode=$taskMode; N=10000; R=0; Cores=1 }
  $taskConditions += [pscustomobject]@{ Mode=$taskMode; N=1000; R=100; Cores=1 }
  $taskConditions += [pscustomobject]@{ Mode=$taskMode; N=1000; R=100; Cores=4 }
}
foreach ($taskRep in 1..3) {
  $taskOrder = if ($taskRep % 2) { @('wsl','windows') } else { @('windows','wsl') }
  foreach ($taskCondition in $taskConditions) {
    foreach ($taskOs in $taskOrder) {
      $taskConfigKey = '{0}-{1}-{2}-{3}-{4}' -f $taskOs,$taskCondition.Mode,$taskCondition.N,$taskCondition.R,$taskCondition.Cores
      $taskKey = '{0}-{1}' -f $taskConfigKey,$taskRep
      if (Test-Path -LiteralPath (Join-Path $taskDir ($taskKey + '-timing.csv'))) { Write-Output ('REUSE ' + $taskKey); continue }
      if ($taskFailed.Contains($taskConfigKey)) {
        $taskStatuses.Add([pscustomobject]@{ Key=$taskKey; Status='not_run_after_failure'; ExitCode=$null; WallSeconds=$null })
        continue
      }
      $taskStartInfo = [System.Diagnostics.ProcessStartInfo]::new()
      $taskStartInfo.UseShellExecute = $false
      $taskStartInfo.CreateNoWindow = $true
      $taskStartInfo.RedirectStandardOutput = $true
      $taskStartInfo.RedirectStandardError = $true
      $taskStartInfo.WorkingDirectory = $taskDir
      foreach ($taskEnvName in @('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','R_DATATABLE_NUM_THREADS')) { $taskStartInfo.Environment[$taskEnvName]='1' }
      if ($taskOs -eq 'windows') {
        $taskStartInfo.FileName = 'D:\software\R\R-4.4.3\bin\x64\Rscript.exe'
        $taskStartInfo.Environment['LC_ALL']='English_United States.utf8'
        $taskArgs = @('--vanilla', (Join-Path $taskDir 'benchmark-cell.R'), $taskDir)
      } else {
        $taskStartInfo.FileName = 'C:\Windows\System32\wsl.exe'
        $taskArgs = @('-d','Ubuntu-22.04','--exec','env','OPENBLAS_NUM_THREADS=1','OMP_NUM_THREADS=1','MKL_NUM_THREADS=1','R_DATATABLE_NUM_THREADS=1','timeout','-k','5s','240s','Rscript','--vanilla', "$taskWslDir/benchmark-cell.R", $taskWslDir)
      }
      $taskArgs += @($taskCondition.Mode,[string]$taskCondition.N,[string]$taskCondition.R,[string]$taskCondition.Cores,[string]$taskRep)
      foreach ($taskArg in $taskArgs) { $taskStartInfo.ArgumentList.Add($taskArg) }
      $taskProcess = [System.Diagnostics.Process]::new()
      $taskProcess.StartInfo = $taskStartInfo
      $taskClock = [System.Diagnostics.Stopwatch]::StartNew()
      Write-Output ('START ' + $taskKey)
      [void]$taskProcess.Start()
      $taskOutputRead = $taskProcess.StandardOutput.ReadToEndAsync()
      $taskErrorRead = $taskProcess.StandardError.ReadToEndAsync()
      $taskTimeout = $false
      while (-not $taskProcess.WaitForExit(1000)) {
        $taskMarker = Join-Path $taskDir ($taskKey + '.started')
        if ($taskOs -eq 'windows' -and (Test-Path -LiteralPath $taskMarker)) {
          $taskCallStart = [double](Get-Content -LiteralPath $taskMarker -Raw)
          $taskNow = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0
          if ($taskNow - $taskCallStart -gt 185) { $taskTimeout = $true; $taskProcess.Kill($true); break }
        }
        if ($taskClock.Elapsed.TotalSeconds -gt 280) { $taskTimeout = $true; $taskProcess.Kill($true); break }
      }
      $taskProcess.WaitForExit()
      $taskClock.Stop()
      $taskOutput = $taskOutputRead.GetAwaiter().GetResult()
      $taskError = $taskErrorRead.GetAwaiter().GetResult()
      Set-Content -LiteralPath (Join-Path $taskDir ($taskKey + '-stdout.txt')) -Value $taskOutput -Encoding utf8
      Set-Content -LiteralPath (Join-Path $taskDir ($taskKey + '-stderr.txt')) -Value $taskError -Encoding utf8
      $taskExitCode = $taskProcess.ExitCode
      $taskStatus = if ($taskTimeout -or $taskExitCode -eq 124) { 'timeout' } elseif ($taskExitCode -eq 0) { 'ok' } else { 'error' }
      $taskStatuses.Add([pscustomobject]@{ Key=$taskKey; Status=$taskStatus; ExitCode=$taskExitCode; WallSeconds=[math]::Round($taskClock.Elapsed.TotalSeconds,3) })
      $taskStatuses | Export-Csv -LiteralPath (Join-Path $taskDir 'run-status.csv') -NoTypeInformation -Encoding utf8
      if ($taskStatus -ne 'ok') {
        [void]$taskFailed.Add($taskConfigKey)
        Write-Output ('FAILED ' + $taskKey + ' ' + $taskStatus + ' ' + $taskError)
      } else {
        ($taskOutput -split '\r?\n' | Where-Object { $_ -like 'DONE *' }) | Write-Output
      }
      $taskProcess.Dispose()
    }
  }
}
Write-Output ('FINISHED ' + $taskStatuses.Count + ' executions')


