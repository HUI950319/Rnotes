args <- commandArgs(TRUE)
outdir <- args[[1L]]
files <- list.files(outdir, pattern = "-timing[.]csv$", full.names = TRUE)
rows <- do.call(rbind, lapply(files, read.csv, stringsAsFactors = FALSE))
rows <- rows[rows[["iteration"]] %in% 1:3, ]
stopifnot(nrow(rows) == 54L, all(rows[["status"]] == "ok"), all(rows[["warning_count"]] == 0L),
 all(rows[["blas_threads"]] == 1L), all(rows[["omp_threads"]] == 1L), all(rows[["dt_threads"]] == 1L),
 all(rows[["valid_reps"]][rows[["R"]] == 100L] == 100L))
rows <- rows[order(rows[["R"]], rows[["mode"]], rows[["cores"]], rows[["iteration"]], rows[["os"]]), ]
write.csv(rows, file.path(outdir, "timings.csv"), row.names = FALSE)
groups <- split(rows, interaction(rows[["os"]], rows[["mode"]], rows[["n"]], rows[["R"]], rows[["cores"]], drop = TRUE))
summary <- do.call(rbind, lapply(groups, function(x) {
 stopifnot(nrow(x) == 3L)
 cbind(x[1L, c("os", "mode", "n", "R", "cores")], repeats = nrow(x),
  median_s = median(x[["elapsed_s"]]), min_s = min(x[["elapsed_s"]]), max_s = max(x[["elapsed_s"]]))
}))
rownames(summary) <- NULL
write.csv(summary, file.path(outdir, "summary.csv"), row.names = FALSE)
keys <- unique(rows[c("mode", "n", "R", "cores")])
comparison <- do.call(rbind, lapply(seq_len(nrow(keys)), function(i) {
 key <- keys[i, ]
 x <- subset(summary, mode == key[["mode"]] & n == key[["n"]] & R == key[["R"]] & cores == key[["cores"]])
 wsl <- x[x[["os"]] == "wsl", ]
 windows <- x[x[["os"]] == "windows", ]
 cbind(key, wsl_median_s = wsl[["median_s"]], wsl_min_s = wsl[["min_s"]], wsl_max_s = wsl[["max_s"]],
 windows_median_s = windows[["median_s"]], windows_min_s = windows[["min_s"]], windows_max_s = windows[["max_s"]],
 windows_over_wsl = windows[["median_s"]]/wsl[["median_s"]])
}))
write.csv(comparison, file.path(outdir, "comparison.csv"), row.names = FALSE)
value_path <- function(os, key, rep) file.path(outdir, paste0(paste(os, key[["mode"]], key[["n"]], key[["R"]], key[["cores"]], rep, sep = "-"), "-values.rds"))
compare_values <- function(a, b) {
 structure_ok <- identical(a[["fields"]], b[["fields"]]) && identical(a[["class"]], b[["class"]])
 diffs <- c()
 for (m in c("AUC", "Brier")) {
  x <- a[["scores"]][[m]]; y <- b[["scores"]][[m]]
  stopifnot(identical(names(x), names(y)), identical(x[["model"]], y[["model"]]), identical(x[["times"]], y[["times"]]))
  for (col in names(x)[vapply(x, is.numeric, logical(1))]) {
   stopifnot(identical(is.na(x[[col]]), is.na(y[[col]])), identical(is.finite(x[[col]]), is.finite(y[[col]])))
   dx <- abs(x[[col]] - y[[col]])
   diffs[paste(m, col, sep = "_")] <- if (any(is.finite(dx))) max(dx[is.finite(dx)]) else 0
  }
 }
 list(max_abs_diff = max(diffs), numeric_ok = all(diffs < 1e-8), structure_ok = structure_ok,
  formatted_summary_equal = identical(a[["summary"]], b[["summary"]]),
  rng_equal = identical(a[["rng"]], b[["rng"]]), details = diffs)
}
validation <- list()
for (i in seq_len(nrow(keys))) for (rep in 1:3) {
 key <- keys[i, ]
 a <- readRDS(value_path("wsl", key, rep))
 b <- readRDS(value_path("windows", key, rep))
 z <- compare_values(a, b)
 validation[[length(validation) + 1L]] <- cbind(key, replicate = rep, kind = "cross_os", data.frame(z[setdiff(names(z), "details")]))
 if (key[["R"]] == 100L && key[["cores"]] == 4L) for (os in c("wsl", "windows")) {
  serial_key <- key; serial_key[["cores"]] <- 1L
  z <- compare_values(readRDS(value_path(os, serial_key, rep)), readRDS(value_path(os, key, rep)))
  validation[[length(validation) + 1L]] <- cbind(key, replicate = rep, kind = paste0(os, "_serial_vs_4"), data.frame(z[setdiff(names(z), "details")]))
 }
}
validation <- do.call(rbind, validation)
write.csv(validation, file.path(outdir, "validation.csv"), row.names = FALSE)
stopifnot(all(validation[["numeric_ok"]]), all(validation[["structure_ok"]]), all(validation[["formatted_summary_equal"]]), all(validation[["rng_equal"]]))
cat("COMPARISON\n"); print(comparison, row.names = FALSE)
cat("VALIDATION comparisons=", nrow(validation), " max_abs=", format(max(validation[["max_abs_diff"]]), digits = 6), " all_passed\n", sep = "")
