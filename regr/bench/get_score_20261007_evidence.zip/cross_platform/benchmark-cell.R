args <- commandArgs(TRUE)
outdir <- args[[1L]]
mode <- args[[2L]]
n <- as.integer(args[[3L]])
reps <- as.integer(args[[4L]])
cores <- as.integer(args[[5L]])
iteration <- as.integer(args[[6L]])
os <- if (.Platform$OS.type == "windows") "windows" else "wsl"
root <- if (os == "windows") "E:/Rpackage/RegR" else "/mnt/e/Rpackage/RegR"
setwd(outdir)
if (os == "windows") { Sys.setenv(LC_ALL = "English_United States.utf8"); invisible(Sys.setlocale("LC_CTYPE", "English_United States.utf8")) }
options(warn = 1, mc.cores = 4L)
Sys.setenv(OPENBLAS_NUM_THREADS = "1", OMP_NUM_THREADS = "1", MKL_NUM_THREADS = "1", R_DATATABLE_NUM_THREADS = "1")
suppressPackageStartupMessages(library(RegR))
RhpcBLASctl::blas_set_num_threads(1L)
RhpcBLASctl::omp_set_num_threads(1L)
data.table::setDTthreads(1L)
pbapply::pboptions(type = "none")
expected <- dget(file.path(outdir, "metadata.R"))
source_hashes <- unname(tools::md5sum(file.path(root, c("R/msr-riskRegression.R", "R/msr-fit-stats.R", "R/utils-parallel.R", "R/utils-resolve.R", "data/seer_thyroid_mtc_2026.rda"))))
stopifnot(identical(source_hashes, unname(expected[["source_hashes"]])))
stopifnot(identical(unname(tools::md5sum(file.path(outdir, "input.rds"))), expected[["input_md5"]]))
e <- new.env(parent = asNamespace("RegR"))
for (f in c("msr-riskRegression.R", "msr-fit-stats.R", "utils-parallel.R", "utils-resolve.R")) sys.source(file.path(root, "R", f), e)
for (f in c("get_score", ".score_foreach_backend", ".score_by_model", "predictRisk.regr_score_fgr", ".score_ft", ".fit_pred_stats", "oo_cores", "oo_pblapply", ".resolve_vars", ".vars_requested", ".merge_named_arg")) {
 stopifnot(identical(body(get(f, e)), body(get(f, asNamespace("RegR")))), identical(formals(get(f, e)), formals(get(f, asNamespace("RegR")))))
}
x <- readRDS(file.path(outdir, "input.rds"))[seq_len(n), , drop = FALSE]
surv_arg <- switch(mode, logistic = "DSS", cox = TRUE, finegray = FALSE)
run <- function(d, r, c) {
  warnings <- character()
  con <- file(nullfile(), "wt")
  sink(con)
  on.exit({sink(); close(con)})
  value <- suppressMessages(withCallingHandlers(RegR::get_score(d,
    vars = list(full = c("Age", "Sex", "Race")), surv = surv_arg,
    timepoint = seq(2, 200, 2), R = r,
    score_args = list(plots = "auto", n_cores = c)),
    warning = function(w) {warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")}))
  list(result = value, warnings = warnings)
}
set.seed(20261008)
invisible(run(x[seq_len(min(300L, n)), , drop = FALSE], if (reps >= 2L) 3L else 0L, 1L))
invisible(gc())
set.seed(20261008)
key <- paste(os, mode, n, reps, cores, iteration, sep = "-")
writeLines(as.character(Sys.getpid()), file.path(outdir, paste0(key, ".pid")))
writeLines(sprintf("%.6f", as.numeric(Sys.time())), file.path(outdir, paste0(key, ".started")))
setTimeLimit(elapsed = 180, transient = TRUE)
elapsed <- system.time(z <- run(x, reps, cores))
setTimeLimit(cpu = Inf, elapsed = Inf, transient = FALSE)
unlink(file.path(outdir, paste0(key, ".started")))
result <- z[["result"]]
scores <- lapply(c("AUC", "Brier"), function(m) {
  tab <- as.data.frame(result[[m]][["score"]])
  keep <- intersect(c("model", "times", m, "se", "lower", "upper"), names(tab))
  tab <- tab[keep]
  stopifnot(nrow(tab) > 0L, all(is.finite(tab[[m]])))
  tab[["model"]] <- as.character(tab[["model"]])
  if ("times" %in% names(tab)) tab <- tab[order(tab[["model"]], tab[["times"]]), , drop = FALSE]
  rownames(tab) <- NULL
  tab
})
names(scores) <- c("AUC", "Brier")
values <- list(scores = scores, summary = result[["AUC.BS.AIC"]],
 valid_reps = attr(result[["AUC.BS.AIC"]], "valid_reps"), rng = get(".Random.seed", .GlobalEnv),
 fields = names(result), class = class(result), warnings = z[["warnings"]])
saveRDS(values, file.path(outdir, paste0(key, "-values.rds")))
row <- data.frame(os = os, mode = mode, n = n, R = reps, cores = cores,
 iteration = iteration, elapsed_s = elapsed[["elapsed"]], user_s = elapsed[["user.self"]],
 system_s = elapsed[["sys.self"]], child_user_s = elapsed[["user.child"]],
 child_system_s = elapsed[["sys.child"]], warning_count = length(z[["warnings"]]),
 warnings = paste(unique(z[["warnings"]]), collapse = " | "),
 valid_reps = if (is.null(values[["valid_reps"]])) NA_integer_ else values[["valid_reps"]],
 blas_threads = RhpcBLASctl::blas_get_num_procs(), omp_threads = RhpcBLASctl::omp_get_max_threads(), dt_threads = data.table::getDTthreads(),
 input_md5 = expected[["input_md5"]], status = "ok")
write.csv(row, file.path(outdir, paste0(key, "-timing.csv")), row.names = FALSE)
cat(sprintf("DONE %s n=%d R=%d cores=%d rep=%d %.3fs warnings=%d valid=%s\n", os, n, reps, cores, iteration, row[["elapsed_s"]], row[["warning_count"]], if (is.null(values[["valid_reps"]])) "NA" else values[["valid_reps"]]))
print(scores[["AUC"]][seq_len(min(2L, nrow(scores[["AUC"]]))), ])
print(scores[["Brier"]][seq_len(min(2L, nrow(scores[["Brier"]]))), ])



